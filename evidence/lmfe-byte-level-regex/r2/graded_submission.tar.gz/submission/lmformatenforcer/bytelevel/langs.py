"""Character level languages used by the byte level token mask computation.

A :class:`Lang` is an immutable state of a language over Unicode scalar values.
``allowed()`` returns every scalar value that may come next *and* keeps the
output completable, so that a token is admissible exactly when every character
it contributes is allowed along the way.
"""
from typing import Dict, Hashable, Iterable, List, Optional, Tuple

from . import ranges
from .ranges import RangeSet
from .regexdfa import DEAD_STATE, RegexProgram


class Lang:
    """One state of a language over Unicode scalar values."""

    __slots__ = ()

    def allowed(self) -> RangeSet:
        raise NotImplementedError()

    def can_end(self) -> bool:
        raise NotImplementedError()

    def advance(self, code_point: int) -> Optional['Lang']:
        raise NotImplementedError()

    def key(self) -> Hashable:
        raise NotImplementedError()


class DoneLang(Lang):
    """A language that accepts only the empty string."""

    __slots__ = ()

    def allowed(self) -> RangeSet:
        return ranges.EMPTY

    def can_end(self) -> bool:
        return True

    def advance(self, code_point: int) -> Optional[Lang]:
        return None

    def key(self) -> Hashable:
        return ('done',)


DONE = DoneLang()


class RegexLang(Lang):
    __slots__ = ('program', 'state')

    def __init__(self, program: RegexProgram, state: int):
        self.program = program
        self.state = state

    @staticmethod
    def create(program: RegexProgram, state: int) -> Optional[Lang]:
        if state == DEAD_STATE:
            return None
        return RegexLang(program, state)

    @staticmethod
    def from_pattern(program: RegexProgram) -> Optional[Lang]:
        return RegexLang.create(program, program.initial)

    def allowed(self) -> RangeSet:
        return self.program.allowed[self.state]

    def can_end(self) -> bool:
        return self.state in self.program.finals

    def advance(self, code_point: int) -> Optional[Lang]:
        return RegexLang.create(self.program, self.program.step(self.state, code_point))

    def key(self) -> Hashable:
        return ('re', id(self.program), self.state)


class LiteralLang(Lang):
    """Accepts exactly one fixed string."""

    __slots__ = ('remaining',)

    def __init__(self, remaining: str):
        self.remaining = remaining

    def allowed(self) -> RangeSet:
        if not self.remaining:
            return ranges.EMPTY
        return ranges.single(ord(self.remaining[0]))

    def can_end(self) -> bool:
        return not self.remaining

    def advance(self, code_point: int) -> Optional[Lang]:
        if self.remaining and ord(self.remaining[0]) == code_point:
            return LiteralLang(self.remaining[1:])
        return None

    def key(self) -> Hashable:
        return ('lit', self.remaining)


class ChoiceLang(Lang):
    """Accepts exactly one of a set of fixed strings (``enum`` and ``const``)."""

    __slots__ = ('options', '_allowed')

    def __init__(self, options: Tuple[str, ...]):
        self.options = options
        self._allowed: Optional[RangeSet] = None

    @staticmethod
    def create(options: Iterable[str]) -> Optional[Lang]:
        unique = tuple(sorted(set(options)))
        if not unique:
            return None
        return ChoiceLang(unique)

    def allowed(self) -> RangeSet:
        if self._allowed is None:
            self._allowed = ranges.from_code_points(
                ord(option[0]) for option in self.options if option)
        return self._allowed

    def can_end(self) -> bool:
        return '' in self.options

    def advance(self, code_point: int) -> Optional[Lang]:
        char = chr(code_point)
        return ChoiceLang.create(option[1:] for option in self.options
                                 if option and option[0] == char)

    def key(self) -> Hashable:
        return ('choice', self.options)


class CountLang(Lang):
    """Free text of between ``minimum`` and ``maximum`` scalar values."""

    __slots__ = ('length', 'minimum', 'maximum', 'members')

    def __init__(self, length: int, minimum: int, maximum: Optional[int], members: RangeSet):
        if maximum is None and length > minimum:
            # Without an upper bound every further character behaves the same,
            # so states beyond the lower bound are all one state.
            length = minimum
        self.length = length
        self.minimum = minimum
        self.maximum = maximum
        self.members = members

    def allowed(self) -> RangeSet:
        if self.maximum is not None and self.length >= self.maximum:
            return ranges.EMPTY
        return self.members

    def can_end(self) -> bool:
        return self.length >= self.minimum

    def advance(self, code_point: int) -> Optional[Lang]:
        if self.maximum is not None and self.length >= self.maximum:
            return None
        if not ranges.contains(self.members, code_point):
            return None
        return CountLang(self.length + 1, self.minimum, self.maximum, self.members)

    def key(self) -> Hashable:
        return ('count', self.length, self.minimum, self.maximum, self.members)


class UnionLang(Lang):
    __slots__ = ('children', '_allowed', '_key')

    def __init__(self, children: Tuple[Lang, ...]):
        self.children = children
        self._allowed: Optional[RangeSet] = None
        self._key: Optional[Hashable] = None

    def allowed(self) -> RangeSet:
        if self._allowed is None:
            self._allowed = ranges.union_all(child.allowed() for child in self.children)
        return self._allowed

    def can_end(self) -> bool:
        return any(child.can_end() for child in self.children)

    def advance(self, code_point: int) -> Optional[Lang]:
        results: List[Lang] = []
        for child in self.children:
            if ranges.contains(child.allowed(), code_point):
                moved = child.advance(code_point)
                if moved is not None:
                    results.append(moved)
        return make_union(results)

    def key(self) -> Hashable:
        if self._key is None:
            self._key = ('union', frozenset(child.key() for child in self.children))
        return self._key


def make_union(children: Iterable[Lang]) -> Optional[Lang]:
    flattened: List[Lang] = []
    for child in children:
        if isinstance(child, UnionLang):
            flattened.extend(child.children)
        else:
            flattened.append(child)
    unique: Dict[Hashable, Lang] = {}
    for child in flattened:
        child_key = child.key()
        if child_key not in unique:
            unique[child_key] = child
    members = list(unique.values())
    if not members:
        return None
    if len(members) == 1:
        return members[0]
    return UnionLang(tuple(members))


class SequenceLang(Lang):
    __slots__ = ('children', '_allowed', '_key')

    def __init__(self, children: Tuple[Lang, ...]):
        self.children = children
        self._allowed: Optional[RangeSet] = None
        self._key: Optional[Hashable] = None

    def allowed(self) -> RangeSet:
        if self._allowed is None:
            parts: List[RangeSet] = []
            for child in self.children:
                parts.append(child.allowed())
                if not child.can_end():
                    break
            self._allowed = ranges.union_all(parts)
        return self._allowed

    def can_end(self) -> bool:
        return all(child.can_end() for child in self.children)

    def advance(self, code_point: int) -> Optional[Lang]:
        results: List[Lang] = []
        for index, child in enumerate(self.children):
            if ranges.contains(child.allowed(), code_point):
                moved = child.advance(code_point)
                if moved is not None:
                    rest = make_sequence((moved,) + self.children[index + 1:])
                    if rest is not None:
                        results.append(rest)
            if not child.can_end():
                break
        return make_union(results)

    def key(self) -> Hashable:
        if self._key is None:
            self._key = ('seq', tuple(child.key() for child in self.children))
        return self._key


def make_sequence(children: Iterable[Lang]) -> Optional[Lang]:
    flattened: List[Lang] = []
    for child in children:
        if isinstance(child, SequenceLang):
            flattened.extend(child.children)
        else:
            flattened.append(child)
    kept: List[Lang] = []
    for child in flattened:
        if not child.allowed():
            if not child.can_end():
                return None  # this part can never be completed
            continue  # a finished part contributes nothing
        kept.append(child)
    if not kept:
        return DONE
    if len(kept) == 1:
        return kept[0]
    return SequenceLang(tuple(kept))
