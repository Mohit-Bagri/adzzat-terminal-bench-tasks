"""Turn a ``CharacterLevelParser`` into the language it describes."""
from typing import Optional

from ..characterlevelparser import (CharacterLevelParser, ForceStopParser, SequenceParser,
                                    StringParser, UnionParser)
from ..consts import WHITESPACE_CHARACTERS
from ..jsonschemaparser import JsonSchemaParser
from ..regexparser import RegexParser
from . import ranges
from .jsonlang import json_lang_for
from .langs import (CountLang, DONE, Lang, LiteralLang, RegexLang, make_sequence, make_union)
from .regexdfa import compile_pattern

_WHITESPACE_RANGES = ranges.from_chars(WHITESPACE_CHARACTERS)


class UnsupportedParser(Exception):
    """Raised when a parser has no byte level equivalent."""


def lang_for_parser(parser: CharacterLevelParser) -> Optional[Lang]:
    """The language of ``parser``, with every scalar value as its alphabet.

    Returns ``None`` when the parser accepts nothing at all.
    """
    if isinstance(parser, RegexParser):
        pattern = getattr(parser.context, 'pattern_string', None)
        if pattern is None:
            raise UnsupportedParser("RegexParser was built without its pattern text")
        if parser.current_state != parser.context.pattern.initial:
            raise UnsupportedParser("RegexParser has already consumed characters")
        return RegexLang.from_pattern(compile_pattern(pattern))
    if isinstance(parser, JsonSchemaParser):
        return json_lang_for(parser)
    if isinstance(parser, StringParser):
        return LiteralLang(parser.target_str)
    if isinstance(parser, ForceStopParser):
        if parser.allow_whitespace:
            return CountLang(0, 0, None, _WHITESPACE_RANGES)
        return DONE
    if isinstance(parser, UnionParser):
        children = []
        for child in parser.parsers:
            built = lang_for_parser(child)
            if built is not None:
                children.append(built)
        return make_union(children)
    if isinstance(parser, SequenceParser):
        children = []
        for child in parser.parsers:
            built = lang_for_parser(child)
            if built is None:
                return None
            children.append(built)
        return make_sequence(children)
    raise UnsupportedParser(f"No byte level support for {type(parser).__name__}")
