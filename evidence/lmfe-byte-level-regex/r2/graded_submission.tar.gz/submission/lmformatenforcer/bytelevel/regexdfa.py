"""A small regular expression engine over Unicode scalar values.

It supports the subset of the syntax that lm-format-enforcer constraints use:
literal characters, ``.``, bracket classes with ranges and leading ``^``
negation, groups, alternation and the greedy quantifiers ``?``, ``*``, ``+``,
``{m}``, ``{m,}`` and ``{m,n}``. Patterns are compiled to a deterministic
automaton whose transitions are keyed by ranges of scalar values, so that a
class such as ``[^,]`` describes every scalar value it admits rather than only
the ones that happen to exist as whole tokens.
"""
from bisect import bisect_right
from typing import Dict, FrozenSet, List, Optional, Sequence, Set, Tuple

from . import ranges
from .ranges import RangeSet

_NEWLINE = ord('\n')

DOT = ranges.subtract(ranges.FULL, ranges.single(_NEWLINE))

_DIGIT = ranges.normalize([(ord('0'), ord('9'))])
_WORD = ranges.normalize([(ord('0'), ord('9')), (ord('A'), ord('Z')),
                          (ord('a'), ord('z')), (ord('_'), ord('_'))])
_SPACE = ranges.from_chars(' \t\n\r\f\v')

_CLASS_ESCAPES: Dict[str, RangeSet] = {
    'd': _DIGIT,
    'D': ranges.subtract(ranges.FULL, _DIGIT),
    'w': _WORD,
    'W': ranges.subtract(ranges.FULL, _WORD),
    's': _SPACE,
    'S': ranges.subtract(ranges.FULL, _SPACE),
}

_CHAR_ESCAPES: Dict[str, int] = {
    'n': 0x0A, 't': 0x09, 'r': 0x0D, 'f': 0x0C, 'v': 0x0B, 'a': 0x07,
    'b': 0x08, '0': 0x00, 'e': 0x1B,
}


class RegexSyntaxError(ValueError):
    pass


# --- Syntax tree -------------------------------------------------------------

class _Node:
    __slots__ = ()


class _Set(_Node):
    __slots__ = ('range_set',)

    def __init__(self, range_set: RangeSet):
        self.range_set = range_set


class _Concat(_Node):
    __slots__ = ('parts',)

    def __init__(self, parts: List[_Node]):
        self.parts = parts


class _Alt(_Node):
    __slots__ = ('options',)

    def __init__(self, options: List[_Node]):
        self.options = options


class _Repeat(_Node):
    __slots__ = ('child', 'minimum', 'maximum')

    def __init__(self, child: _Node, minimum: int, maximum: Optional[int]):
        self.child = child
        self.minimum = minimum
        self.maximum = maximum


# --- Parser ------------------------------------------------------------------

class _Parser:
    def __init__(self, pattern: str):
        self.pattern = pattern
        self.position = 0

    def at_end(self) -> bool:
        return self.position >= len(self.pattern)

    def peek(self) -> str:
        return self.pattern[self.position]

    def parse(self) -> _Node:
        node = self.parse_alternation()
        if not self.at_end():
            raise RegexSyntaxError(f"Unexpected '{self.peek()}' at {self.position} in {self.pattern!r}")
        return node

    def parse_alternation(self) -> _Node:
        options = [self.parse_concat()]
        while not self.at_end() and self.peek() == '|':
            self.position += 1
            options.append(self.parse_concat())
        if len(options) == 1:
            return options[0]
        return _Alt(options)

    def parse_concat(self) -> _Node:
        parts: List[_Node] = []
        while not self.at_end() and self.peek() not in '|)':
            parts.append(self.parse_quantified())
        if len(parts) == 1:
            return parts[0]
        return _Concat(parts)

    def parse_quantified(self) -> _Node:
        atom = self.parse_atom()
        while not self.at_end():
            char = self.peek()
            if char == '?':
                self.position += 1
                atom = _Repeat(atom, 0, 1)
            elif char == '*':
                self.position += 1
                atom = _Repeat(atom, 0, None)
            elif char == '+':
                self.position += 1
                atom = _Repeat(atom, 1, None)
            elif char == '{':
                bounds = self.try_parse_bounds()
                if bounds is None:
                    break
                atom = _Repeat(atom, bounds[0], bounds[1])
            else:
                break
            # A lazy or possessive marker is not part of the supported subset,
            # but tolerate it so that patterns stay parseable.
            if not self.at_end() and self.peek() in '?+':
                if self.peek() == '?':
                    self.position += 1
                break
        return atom

    def try_parse_bounds(self) -> Optional[Tuple[int, Optional[int]]]:
        start = self.position
        self.position += 1  # consume '{'
        digits = ''
        while not self.at_end() and self.peek().isdigit():
            digits += self.peek()
            self.position += 1
        if not digits:
            self.position = start
            return None
        minimum = int(digits)
        if not self.at_end() and self.peek() == '}':
            self.position += 1
            return minimum, minimum
        if self.at_end() or self.peek() != ',':
            self.position = start
            return None
        self.position += 1
        digits = ''
        while not self.at_end() and self.peek().isdigit():
            digits += self.peek()
            self.position += 1
        if self.at_end() or self.peek() != '}':
            self.position = start
            return None
        self.position += 1
        if not digits:
            return minimum, None
        maximum = int(digits)
        if maximum < minimum:
            raise RegexSyntaxError(f"Invalid repetition bounds in {self.pattern!r}")
        return minimum, maximum

    def parse_atom(self) -> _Node:
        char = self.peek()
        if char == '(':
            self.position += 1
            if self.pattern.startswith('?:', self.position):
                self.position += 2
            elif self.pattern.startswith('?', self.position):
                raise RegexSyntaxError(f"Unsupported group extension in {self.pattern!r}")
            node = self.parse_alternation()
            if self.at_end() or self.peek() != ')':
                raise RegexSyntaxError(f"Unbalanced '(' in {self.pattern!r}")
            self.position += 1
            return node
        if char == '[':
            return _Set(self.parse_class())
        if char == '.':
            self.position += 1
            return _Set(DOT)
        if char == '\\':
            return self.parse_escape()
        if char in '*+?':
            raise RegexSyntaxError(f"Nothing to repeat at {self.position} in {self.pattern!r}")
        self.position += 1
        return _Set(ranges.single(ord(char)))

    def parse_escape(self) -> _Node:
        self.position += 1
        if self.at_end():
            raise RegexSyntaxError(f"Trailing backslash in {self.pattern!r}")
        char = self.peek()
        if char in _CLASS_ESCAPES:
            self.position += 1
            return _Set(_CLASS_ESCAPES[char])
        return _Set(ranges.single(self.parse_escaped_code_point()))

    def parse_escaped_code_point(self) -> int:
        """Read the escaped character after a backslash that was consumed."""
        char = self.peek()
        self.position += 1
        if char == 'x':
            return self.read_hex(2)
        if char == 'u':
            return self.read_hex(4)
        if char == 'U':
            return self.read_hex(8)
        if char.isalnum():
            if char in _CHAR_ESCAPES:
                return _CHAR_ESCAPES[char]
            raise RegexSyntaxError(f"Unsupported escape '\\{char}' in {self.pattern!r}")
        return ord(char)

    def read_hex(self, count: int) -> int:
        digits = self.pattern[self.position:self.position + count]
        if len(digits) != count or any(digit not in '0123456789abcdefABCDEF' for digit in digits):
            raise RegexSyntaxError(f"Bad hexadecimal escape in {self.pattern!r}")
        self.position += count
        return int(digits, 16)

    def parse_class(self) -> RangeSet:
        self.position += 1  # consume '['
        negated = False
        if not self.at_end() and self.peek() == '^':
            negated = True
            self.position += 1
        pairs: List[Tuple[int, int]] = []
        extra: List[RangeSet] = []
        first = True
        while True:
            if self.at_end():
                raise RegexSyntaxError(f"Unterminated character class in {self.pattern!r}")
            char = self.peek()
            if char == ']' and not first:
                self.position += 1
                break
            first = False
            if char == '\\':
                self.position += 1
                if self.at_end():
                    raise RegexSyntaxError(f"Trailing backslash in {self.pattern!r}")
                escaped = self.peek()
                if escaped in _CLASS_ESCAPES:
                    self.position += 1
                    extra.append(_CLASS_ESCAPES[escaped])
                    continue
                low = self.parse_escaped_code_point()
            else:
                self.position += 1
                low = ord(char)
            if (not self.at_end() and self.peek() == '-'
                    and self.position + 1 < len(self.pattern)
                    and self.pattern[self.position + 1] != ']'):
                self.position += 1
                char = self.peek()
                if char == '\\':
                    self.position += 1
                    if self.at_end():
                        raise RegexSyntaxError(f"Trailing backslash in {self.pattern!r}")
                    if self.peek() in _CLASS_ESCAPES:
                        raise RegexSyntaxError(f"Bad character range in {self.pattern!r}")
                    high = self.parse_escaped_code_point()
                else:
                    self.position += 1
                    high = ord(char)
                if high < low:
                    raise RegexSyntaxError(f"Bad character range in {self.pattern!r}")
                pairs.append((low, high))
            else:
                pairs.append((low, low))
        members = ranges.union(ranges.normalize(pairs), ranges.union_all(extra))
        if negated:
            return ranges.subtract(ranges.FULL, members)
        return members


def strip_anchors(pattern: str) -> str:
    """Remove a leading ``^`` and a trailing unescaped ``$``.

    Constraints are always matched against the whole output, so the anchors
    that schema patterns are sometimes written with are redundant.
    """
    if pattern.startswith('^'):
        pattern = pattern[1:]
    if pattern.endswith('$'):
        backslashes = 0
        index = len(pattern) - 2
        while index >= 0 and pattern[index] == '\\':
            backslashes += 1
            index -= 1
        if backslashes % 2 == 0:
            pattern = pattern[:-1]
    return pattern


# --- Compilation -------------------------------------------------------------

class _Fragment:
    __slots__ = ('start', 'end')

    def __init__(self, start: int, end: int):
        self.start = start
        self.end = end


class _NFA:
    def __init__(self) -> None:
        self.epsilon: List[List[int]] = []
        self.moves: List[List[Tuple[RangeSet, int]]] = []

    def new_state(self) -> int:
        self.epsilon.append([])
        self.moves.append([])
        return len(self.epsilon) - 1

    def build(self, node: _Node) -> _Fragment:
        if isinstance(node, _Set):
            start = self.new_state()
            end = self.new_state()
            if node.range_set:
                self.moves[start].append((node.range_set, end))
            return _Fragment(start, end)
        if isinstance(node, _Concat):
            if not node.parts:
                state = self.new_state()
                return _Fragment(state, state)
            fragments = [self.build(part) for part in node.parts]
            for left, right in zip(fragments, fragments[1:]):
                self.epsilon[left.end].append(right.start)
            return _Fragment(fragments[0].start, fragments[-1].end)
        if isinstance(node, _Alt):
            start = self.new_state()
            end = self.new_state()
            for option in node.options:
                fragment = self.build(option)
                self.epsilon[start].append(fragment.start)
                self.epsilon[fragment.end].append(end)
            return _Fragment(start, end)
        if isinstance(node, _Repeat):
            return self.build_repeat(node)
        raise RegexSyntaxError(f"Unsupported node {node!r}")

    def build_repeat(self, node: _Repeat) -> _Fragment:
        start = self.new_state()
        current = start
        for _ in range(node.minimum):
            fragment = self.build(node.child)
            self.epsilon[current].append(fragment.start)
            current = fragment.end
        end = self.new_state()
        if node.maximum is None:
            loop = self.build(node.child)
            self.epsilon[current].append(loop.start)
            self.epsilon[loop.end].append(loop.start)
            self.epsilon[loop.end].append(end)
            self.epsilon[current].append(end)
        else:
            optional = node.maximum - node.minimum
            for _ in range(optional):
                fragment = self.build(node.child)
                self.epsilon[current].append(fragment.start)
                self.epsilon[current].append(end)
                current = fragment.end
            self.epsilon[current].append(end)
        return _Fragment(start, end)

    def closure(self, states: Sequence[int]) -> FrozenSet[int]:
        stack = list(states)
        seen: Set[int] = set(states)
        while stack:
            state = stack.pop()
            for target in self.epsilon[state]:
                if target not in seen:
                    seen.add(target)
                    stack.append(target)
        return frozenset(seen)


DEAD_STATE = -1


class RegexProgram:
    """A deterministic automaton for one pattern, over scalar value ranges."""

    def __init__(self, pattern: str):
        self.pattern = pattern
        node = _Parser(strip_anchors(pattern)).parse()
        nfa = _NFA()
        fragment = nfa.build(node)
        boundaries: Set[int] = {0, ranges.MAX_CODE_POINT + 1}
        for moves in nfa.moves:
            for range_set, _ in moves:
                for low, high in range_set:
                    boundaries.add(low)
                    boundaries.add(high + 1)
        points = sorted(boundaries)
        self.interval_starts: List[int] = points[:-1]
        intervals: List[Tuple[int, int]] = [
            (points[index], points[index + 1] - 1) for index in range(len(points) - 1)
        ]
        self.intervals = intervals
        move_intervals: List[List[Tuple[int, int]]] = []
        for moves in nfa.moves:
            entries: List[Tuple[int, int]] = []
            for range_set, target in moves:
                for low, high in range_set:
                    first = bisect_right(self.interval_starts, low) - 1
                    index = first
                    while index < len(intervals) and intervals[index][0] <= high:
                        entries.append((index, target))
                        index += 1
            move_intervals.append(entries)

        initial_set = nfa.closure([fragment.start])
        self.transitions: List[Dict[int, int]] = []
        self.finals: Set[int] = set()
        state_ids: Dict[FrozenSet[int], int] = {initial_set: 0}
        state_sets: List[FrozenSet[int]] = [initial_set]
        self.transitions.append({})
        queue = [0]
        while queue:
            state_id = queue.pop()
            members = state_sets[state_id]
            if fragment.end in members:
                self.finals.add(state_id)
            grouped: Dict[int, Set[int]] = {}
            for member in members:
                for interval_index, target in move_intervals[member]:
                    grouped.setdefault(interval_index, set()).add(target)
            row: Dict[int, int] = {}
            for interval_index, targets in grouped.items():
                target_set = nfa.closure(sorted(targets))
                target_id = state_ids.get(target_set)
                if target_id is None:
                    target_id = len(state_sets)
                    state_ids[target_set] = target_id
                    state_sets.append(target_set)
                    self.transitions.append({})
                    queue.append(target_id)
                row[interval_index] = target_id
            self.transitions[state_id] = row

        self._prune_dead_states()
        self.initial: int = 0 if 0 in self.live else DEAD_STATE
        self.allowed: List[RangeSet] = []
        for state_id, row in enumerate(self.transitions):
            pairs: List[Tuple[int, int]] = []
            for interval_index, target in row.items():
                if target in self.live:
                    pairs.append(intervals[interval_index])
            self.allowed.append(ranges.normalize(pairs))

    def _prune_dead_states(self) -> None:
        incoming: Dict[int, Set[int]] = {}
        for state_id, row in enumerate(self.transitions):
            for target in row.values():
                incoming.setdefault(target, set()).add(state_id)
        self.live: Set[int] = set(self.finals)
        stack = list(self.finals)
        while stack:
            state_id = stack.pop()
            for source in incoming.get(state_id, ()):
                if source not in self.live:
                    self.live.add(source)
                    stack.append(source)

    def step(self, state: int, code_point: int) -> int:
        if state == DEAD_STATE:
            return DEAD_STATE
        interval_index = bisect_right(self.interval_starts, code_point) - 1
        target = self.transitions[state].get(interval_index, DEAD_STATE)
        if target == DEAD_STATE or target not in self.live:
            return DEAD_STATE
        return target

    def is_final(self, state: int) -> bool:
        return state in self.finals

    def fullmatch(self, text: str) -> bool:
        state = self.initial
        for char in text:
            state = self.step(state, ord(char))
            if state == DEAD_STATE:
                return False
        return state in self.finals

    def allowed_ranges(self, state: int) -> RangeSet:
        if state == DEAD_STATE:
            return ranges.EMPTY
        return self.allowed[state]


_program_cache: Dict[str, RegexProgram] = {}


def compile_pattern(pattern: str) -> RegexProgram:
    program = _program_cache.get(pattern)
    if program is None:
        program = RegexProgram(pattern)
        _program_cache[pattern] = program
    return program
