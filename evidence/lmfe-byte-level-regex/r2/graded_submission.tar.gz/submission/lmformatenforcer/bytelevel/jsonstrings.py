"""State machines for the contents of JSON strings.

Two flavours are needed.

``ValueStringMachine`` implements the JSON string grammar of RFC 8259 for a
string *value*: raw characters, the short escapes, ``\\uXXXX`` escapes and
surrogate pairs. The schema constraints of the value (``enum``, ``const``,
``pattern``, ``minLength``, ``maxLength``) apply to the decoded value, which is
tracked by an inner :class:`~lmformatenforcer.bytelevel.langs.Lang`.

``KeyStringMachine`` implements what the unmodified character level parser does
for a property name: characters are taken literally, and a backslash starts an
escape whose body is consumed by a separate parser and therefore does not become
part of the parsed name.
"""
from typing import Hashable, List, Optional, Tuple

from . import ranges
from .langs import Lang
from .ranges import RangeSet

QUOTE = 0x22
BACKSLASH = 0x5C

#: Characters that may appear unescaped between the quotes of a JSON string.
RAW_ALLOWED: RangeSet = ranges.subtract(
    ranges.FULL,
    ranges.normalize([(0x00, 0x1F), (QUOTE, QUOTE), (BACKSLASH, BACKSLASH)]))

SHORT_ESCAPES = {
    ord('"'): 0x22,
    ord('\\'): 0x5C,
    ord('/'): 0x2F,
    ord('b'): 0x08,
    ord('f'): 0x0C,
    ord('n'): 0x0A,
    ord('r'): 0x0D,
    ord('t'): 0x09,
}

_HEX_VALUES = {}
for _digit in range(10):
    _HEX_VALUES[ord('0') + _digit] = _digit
for _digit in range(6):
    _HEX_VALUES[ord('a') + _digit] = 10 + _digit
    _HEX_VALUES[ord('A') + _digit] = 10 + _digit

_HEX_RANGES = ranges.normalize([(ord('0'), ord('9')), (ord('A'), ord('F')), (ord('a'), ord('f'))])

HIGH_SURROGATE_LOW = 0xD800
HIGH_SURROGATE_HIGH = 0xDBFF
LOW_SURROGATE_LOW = 0xDC00
LOW_SURROGATE_HIGH = 0xDFFF

#: Returned by ``advance`` when the character closes the string.
CLOSE = object()

# Escape modes.
_NONE = 0
_AFTER_BACKSLASH = 1
_IN_HEX = 2
_PAIR_BACKSLASH = 3
_PAIR_U = 4
_PAIR_HEX = 5


def _escape_value_code_points(low: int, high: int) -> RangeSet:
    """Code points encoded by the ``\\uXXXX`` escapes with a value in ``[low, high]``.

    Values in the high surrogate area stand for the first half of a surrogate
    pair, so they describe the supplementary characters such a pair can encode.
    Unpaired low surrogates encode nothing.
    """
    pairs: List[Tuple[int, int]] = []
    if low <= min(high, HIGH_SURROGATE_LOW - 1):
        pairs.append((low, min(high, HIGH_SURROGATE_LOW - 1)))
    if max(low, LOW_SURROGATE_HIGH + 1) <= high:
        pairs.append((max(low, LOW_SURROGATE_HIGH + 1), high))
    first = max(low, HIGH_SURROGATE_LOW)
    last = min(high, HIGH_SURROGATE_HIGH)
    if first <= last:
        pairs.append((0x10000 + ((first - HIGH_SURROGATE_LOW) << 10),
                      0x10000 + ((last - HIGH_SURROGATE_LOW) << 10) + 0x3FF))
    return ranges.normalize(pairs)


def _prefix_bounds(prefix: int, digits: int) -> Tuple[int, int]:
    """Bounds of the four digit value that starts with ``digits`` digits ``prefix``."""
    shift = 4 * (4 - digits)
    low = prefix << shift
    return low, low | ((1 << shift) - 1)


class ValueStringMachine:
    """The contents of a JSON string value, with its constraints decoded."""

    __slots__ = ('inner', 'mode', 'prefix', 'digits', 'high', '_allowed')

    def __init__(self, inner: Lang, mode: int = _NONE, prefix: int = 0,
                 digits: int = 0, high: int = 0):
        self.inner = inner
        self.mode = mode
        self.prefix = prefix
        self.digits = digits
        self.high = high
        self._allowed: Optional[RangeSet] = None

    # -- queries --------------------------------------------------------

    def allowed(self) -> RangeSet:
        if self._allowed is None:
            self._allowed = self._compute_allowed()
        return self._allowed

    def _compute_allowed(self) -> RangeSet:
        decodable = self.inner.allowed()
        if self.mode == _NONE:
            pairs: List[RangeSet] = [ranges.intersect(decodable, RAW_ALLOWED)]
            if decodable:
                pairs.append(ranges.single(BACKSLASH))
            if self.inner.can_end():
                pairs.append(ranges.single(QUOTE))
            return ranges.union_all(pairs)
        if self.mode == _AFTER_BACKSLASH:
            code_points = [char for char, decoded in SHORT_ESCAPES.items()
                           if ranges.contains(decodable, decoded)]
            if decodable:
                code_points.append(ord('u'))
            return ranges.from_code_points(code_points)
        if self.mode == _IN_HEX:
            allowed_digits = [char for char, value in _HEX_VALUES.items()
                              if self._hex_digit_possible(value)]
            return ranges.from_code_points(allowed_digits)
        if self.mode == _PAIR_BACKSLASH:
            return ranges.single(BACKSLASH)
        if self.mode == _PAIR_U:
            return ranges.single(ord('u'))
        allowed_digits = [char for char, value in _HEX_VALUES.items()
                          if self._pair_digit_possible(value)]
        return ranges.from_code_points(allowed_digits)

    def _hex_digit_possible(self, value: int) -> bool:
        prefix = (self.prefix << 4) | value
        digits = self.digits + 1
        low, high = _prefix_bounds(prefix, digits)
        return ranges.intersects(self.inner.allowed(), _escape_value_code_points(low, high))

    def _pair_digit_possible(self, value: int) -> bool:
        prefix = (self.prefix << 4) | value
        digits = self.digits + 1
        low, high = _prefix_bounds(prefix, digits)
        low = max(low, LOW_SURROGATE_LOW)
        high = min(high, LOW_SURROGATE_HIGH)
        if low > high:
            return False
        base = 0x10000 + ((self.high - HIGH_SURROGATE_LOW) << 10)
        return ranges.intersects(self.inner.allowed(),
                                 ((base + low - LOW_SURROGATE_LOW,
                                   base + high - LOW_SURROGATE_LOW),))

    def can_close(self) -> bool:
        return self.mode == _NONE and self.inner.can_end()

    def key(self) -> Hashable:
        return (self.inner.key(), self.mode, self.prefix, self.digits, self.high)

    # -- transitions ----------------------------------------------------

    def advance(self, code_point: int):
        mode = self.mode
        if mode == _NONE:
            if code_point == QUOTE:
                return CLOSE if self.inner.can_end() else None
            if code_point == BACKSLASH:
                if not self.inner.allowed():
                    return None
                return ValueStringMachine(self.inner, _AFTER_BACKSLASH)
            if not ranges.contains(RAW_ALLOWED, code_point):
                return None
            return self._with_decoded(code_point)
        if mode == _AFTER_BACKSLASH:
            decoded = SHORT_ESCAPES.get(code_point)
            if decoded is not None:
                return self._with_decoded(decoded)
            if code_point == ord('u') and self.inner.allowed():
                return ValueStringMachine(self.inner, _IN_HEX, 0, 0)
            return None
        if mode == _IN_HEX:
            value = _HEX_VALUES.get(code_point)
            if value is None:
                return None
            prefix = (self.prefix << 4) | value
            digits = self.digits + 1
            if digits < 4:
                if not self._hex_digit_possible(value):
                    return None
                return ValueStringMachine(self.inner, _IN_HEX, prefix, digits)
            if HIGH_SURROGATE_LOW <= prefix <= HIGH_SURROGATE_HIGH:
                base = 0x10000 + ((prefix - HIGH_SURROGATE_LOW) << 10)
                if not ranges.intersects(self.inner.allowed(), ((base, base + 0x3FF),)):
                    return None
                return ValueStringMachine(self.inner, _PAIR_BACKSLASH, 0, 0, prefix)
            if LOW_SURROGATE_LOW <= prefix <= LOW_SURROGATE_HIGH:
                return None
            return self._with_decoded(prefix)
        if mode == _PAIR_BACKSLASH:
            if code_point != BACKSLASH:
                return None
            return ValueStringMachine(self.inner, _PAIR_U, 0, 0, self.high)
        if mode == _PAIR_U:
            if code_point != ord('u'):
                return None
            return ValueStringMachine(self.inner, _PAIR_HEX, 0, 0, self.high)
        value = _HEX_VALUES.get(code_point)
        if value is None or not self._pair_digit_possible(value):
            return None
        prefix = (self.prefix << 4) | value
        digits = self.digits + 1
        if digits < 4:
            return ValueStringMachine(self.inner, _PAIR_HEX, prefix, digits, self.high)
        decoded = 0x10000 + ((self.high - HIGH_SURROGATE_LOW) << 10) + (prefix - LOW_SURROGATE_LOW)
        return self._with_decoded(decoded)

    def _with_decoded(self, code_point: int) -> Optional['ValueStringMachine']:
        moved = self.inner.advance(code_point)
        if moved is None:
            return None
        return ValueStringMachine(moved)

    def resume_value(self) -> str:
        """The text to hand back to the character level parser when the string closes."""
        return 'x'


class KeyStringMachine:
    """The contents of a JSON property name, with character level semantics."""

    __slots__ = ('inner', 'parsed', 'escape', 'digits', 'track_parsed', '_allowed')

    def __init__(self, inner: Lang, parsed: str, escape: int = _NONE, digits: int = 0,
                 track_parsed: bool = True):
        self.inner = inner
        # Only names that are matched against a list need to be remembered; for a
        # free name the text is never looked at again, and keeping it would make
        # every position of the name a separate state.
        self.parsed = parsed if track_parsed else ''
        self.escape = escape
        self.digits = digits
        self.track_parsed = track_parsed
        self._allowed: Optional[RangeSet] = None

    def allowed(self) -> RangeSet:
        if self._allowed is None:
            if self.escape == _NONE:
                allowed = self.inner.allowed()
                if self.inner.can_end():
                    allowed = ranges.union(allowed, ranges.single(QUOTE))
                self._allowed = allowed
            elif self.escape == _AFTER_BACKSLASH:
                self._allowed = ranges.from_code_points(
                    list(SHORT_ESCAPES.keys()) + [ord('u')])
            else:
                self._allowed = _HEX_RANGES
        return self._allowed

    def can_close(self) -> bool:
        # A quote always ends a property name for the character level parser, so
        # it closes whenever the name is allowed to contain one here.
        return self.escape == _NONE and ranges.contains(self.allowed(), QUOTE)

    def key(self) -> Hashable:
        return (self.inner.key(), self.parsed, self.escape, self.digits)

    def advance(self, code_point: int):
        if self.escape == _NONE:
            if code_point == QUOTE:
                return CLOSE if self.can_close() else None
            moved = self.inner.advance(code_point)
            if moved is None:
                return None
            parsed = self.parsed + chr(code_point)
            if code_point == BACKSLASH:
                return KeyStringMachine(moved, parsed, _AFTER_BACKSLASH, 0, self.track_parsed)
            return KeyStringMachine(moved, parsed, _NONE, 0, self.track_parsed)
        if self.escape == _AFTER_BACKSLASH:
            if code_point in SHORT_ESCAPES:
                return KeyStringMachine(self.inner, self.parsed, _NONE, 0, self.track_parsed)
            if code_point == ord('u'):
                return KeyStringMachine(self.inner, self.parsed, _IN_HEX, 0, self.track_parsed)
            return None
        if code_point not in _HEX_VALUES:
            return None
        digits = self.digits + 1
        if digits == 4:
            return KeyStringMachine(self.inner, self.parsed, _NONE, 0, self.track_parsed)
        return KeyStringMachine(self.inner, self.parsed, _IN_HEX, digits, self.track_parsed)

    def resume_value(self) -> str:
        return self.parsed
