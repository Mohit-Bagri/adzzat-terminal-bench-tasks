"""Byte level token mask computation for lm-format-enforcer.

This package is only used when the caller supplies ``token_bytes`` to
:class:`lmformatenforcer.tokenenforcer.TokenEnforcerTokenizerData`. It computes
token masks directly over the bytes that each token contributes, so that tokens
holding only part of a UTF-8 character are handled exactly.
"""
