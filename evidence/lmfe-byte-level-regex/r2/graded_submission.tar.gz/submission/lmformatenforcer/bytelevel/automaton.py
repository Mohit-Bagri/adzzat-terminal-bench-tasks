"""Walking a vocabulary of byte strings against a character level language."""
from typing import Dict, Hashable, List, Optional, Tuple

from . import ranges
from .langs import Lang

DEAD = -1
_UNKNOWN = -2


class ByteAutomaton:
    """States of ``(language state, bytes of a partial character)`` pairs.

    Transitions are computed on demand and shared between every walk, so the
    cost of deciding what a byte does is paid once per state and byte.
    """

    def __init__(self, root: Optional[Lang]):
        self.langs: List[Lang] = []
        self.pendings: List[bytes] = []
        self.allowed: List[ranges.RangeSet] = []
        self.transitions: List[Dict[int, int]] = []
        self.complete: List[bool] = []
        self.index: Dict[Hashable, int] = {}
        self.root = DEAD if root is None else self.intern(root, b'')

    def intern(self, lang: Lang, pending: bytes) -> int:
        key = (lang.key(), pending)
        state = self.index.get(key)
        if state is None:
            state = len(self.langs)
            self.index[key] = state
            self.langs.append(lang)
            self.pendings.append(pending)
            self.allowed.append(lang.allowed())
            self.transitions.append({})
            self.complete.append(not pending and lang.can_end())
        return state

    def can_end(self, state: int) -> bool:
        return state >= 0 and self.complete[state]

    def compute(self, state: int, byte: int) -> int:
        lang = self.langs[state]
        pending = self.pendings[state]
        allowed = self.allowed[state]
        if pending:
            if byte < 0x80 or byte > 0xBF:
                return DEAD
            candidate = pending + bytes((byte,))
            if len(candidate) == ranges.sequence_length(candidate[0]):
                code_point = ranges.decode_sequence(candidate)
                if code_point < 0 or not ranges.contains(allowed, code_point):
                    return DEAD
                moved = lang.advance(code_point)
                if moved is None:
                    return DEAD
                return self.intern(moved, b'')
            low, high = ranges.prefix_code_point_bounds(candidate)
            if low > high or not ranges.contains_range(allowed, low, high):
                return DEAD
            return self.intern(lang, candidate)
        if byte < 0x80:
            if not ranges.contains(allowed, byte):
                return DEAD
            moved = lang.advance(byte)
            if moved is None:
                return DEAD
            return self.intern(moved, b'')
        if ranges.sequence_length(byte) == 0:
            return DEAD
        candidate = bytes((byte,))
        low, high = ranges.prefix_code_point_bounds(candidate)
        if low > high or not ranges.contains_range(allowed, low, high):
            return DEAD
        return self.intern(lang, candidate)

    def step(self, state: int, byte: int) -> int:
        if state < 0:
            return DEAD
        row = self.transitions[state]
        target = row.get(byte, _UNKNOWN)
        if target == _UNKNOWN:
            target = self.compute(state, byte)
            row[byte] = target
        return target

    def walk(self, state: int, data: bytes) -> int:
        for byte in data:
            state = self.step(state, byte)
            if state == DEAD:
                return DEAD
        return state


class ByteVocabulary:
    """A trie over the bytes that each token contributes."""

    def __init__(self, token_bytes: Dict[int, bytes]):
        self.children: List[Dict[int, int]] = [{}]
        self.tokens: Dict[int, List[int]] = {}
        self.token_bytes = token_bytes
        for token_id in sorted(token_bytes):
            node = 0
            for byte in token_bytes[token_id]:
                children = self.children[node]
                target = children.get(byte)
                if target is None:
                    target = len(self.children)
                    self.children.append({})
                    children[byte] = target
                node = target
            self.tokens.setdefault(node, []).append(token_id)

    def collect(self, automaton: ByteAutomaton, state: int) -> List[int]:
        """Every token whose bytes keep the output a prefix of an accepted string."""
        if state < 0:
            return []
        result: List[int] = []
        children = self.children
        tokens = self.tokens
        transitions = automaton.transitions
        compute = automaton.compute
        stack: List[Tuple[int, int]] = [(0, state)]
        while stack:
            node, current = stack.pop()
            found = tokens.get(node)
            if found is not None:
                result.extend(found)
            row = transitions[current]
            for byte, child in children[node].items():
                target = row.get(byte, _UNKNOWN)
                if target == _UNKNOWN:
                    target = compute(current, byte)
                    row[byte] = target
                if target >= 0:
                    stack.append((child, target))
        return result
