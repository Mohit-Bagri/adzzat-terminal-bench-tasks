"""A :class:`~lmformatenforcer.bytelevel.langs.Lang` built on ``JsonSchemaParser``.

The structure of the document - objects, arrays, numbers, booleans, whitespace -
is driven by the unmodified character level parser, so the accepted language is
exactly the one its interface describes. The contents of JSON strings are taken
over by the machines in :mod:`lmformatenforcer.bytelevel.jsonstrings`, because a
string value follows the JSON string grammar with its constraints applied to the
decoded value.
"""
import itertools
from dataclasses import replace
from typing import Dict, Hashable, List, Optional, Tuple

from ..characterlevelparser import (CharacterLevelParser, ForceStopParser, SequenceParser,
                                    StringParser, UnionParser)
from ..consts import COMPLETE_ALPHABET, WHITESPACE_CHARACTERS
from ..jsonschemaparser import (JsonSchemaParser, ListParsingState, NumberParsingState,
                                ObjectParsingState, StringParsingState)
from . import ranges
from .jsonstrings import CLOSE, KeyStringMachine, ValueStringMachine
from .langs import ChoiceLang, CountLang, Lang, RegexLang
from .ranges import RangeSet
from .regexdfa import compile_pattern, strip_anchors

#: Stands for "every scalar value that the parser does not name explicitly".
SENTINEL = chr(0xE000)

_UNSET = object()

#: Keeps the cache keys of one schema apart from those of another, so that two
#: schema parsers inside the same composite are never taken for one state.
_environment_numbers = itertools.count()


def _is_open_string(parser: CharacterLevelParser) -> bool:
    return (isinstance(parser, StringParsingState)
            and parser.require_opening_quote
            and parser.seen_opening_quote
            and not parser.seen_closing_quote)


def _holds_open_string(parser: CharacterLevelParser) -> bool:
    """Whether a parser is, or contains, a string whose quote is open.

    Nested ``anyOf`` schemas produce unions of unions, so the search has to go
    all the way down before the contents of the string are taken over.
    """
    if _is_open_string(parser):
        return True
    if isinstance(parser, UnionParser):
        return any(_holds_open_string(option) for option in parser.parsers)
    return False


def _schema_pattern(state: StringParsingState) -> str:
    """The pattern of a string value, with only redundant anchors removed.

    The character level parser drops a trailing ``$`` even when it is escaped,
    so the pattern as the schema wrote it is used here instead.
    """
    original = getattr(state, 'original_pattern', None)
    return strip_anchors(original if original is not None else state.pattern)


def _inner_language(state: StringParsingState) -> Optional[Lang]:
    """The language of the decoded contents of a string, from its constraints."""
    if state.allowed_strings:
        options = [option for option in state.allowed_strings if isinstance(option, str)]
        minimum = state.min_length or 0
        maximum = state.max_length
        if minimum or maximum is not None:
            options = [option for option in options if len(option) >= minimum
                       and (maximum is None or len(option) <= maximum)]
        if state.pattern:
            program = compile_pattern(_schema_pattern(state))
            options = [option for option in options if program.fullmatch(option)]
        return ChoiceLang.create(options)
    if state.pattern:
        return RegexLang.from_pattern(compile_pattern(_schema_pattern(state)))
    minimum = state.min_length or 0
    if state.max_length is not None and minimum > state.max_length:
        return None  # no string can satisfy both bounds
    return CountLang(0, minimum, state.max_length, ranges.FULL)


def _key_language(state: StringParsingState) -> Optional[Lang]:
    """The language of a property name, with character level semantics."""
    if state.allowed_strings:
        return ChoiceLang.create(state.allowed_strings)
    return CountLang(0, state.min_length or 0, state.max_length, ranges.FULL)


class _Atom:
    __slots__ = ()

    def allowed(self) -> RangeSet:
        raise NotImplementedError()

    def can_end(self) -> bool:
        raise NotImplementedError()

    def advance(self, code_point: int) -> List['_Atom']:
        raise NotImplementedError()

    def key(self) -> Hashable:
        raise NotImplementedError()


class JsonEnvironment:
    """Shared state for every atom derived from one root ``JsonSchemaParser``."""

    def __init__(self, explicit_alphabet: str):
        self.number = next(_environment_numbers)
        self.explicit_chars = set(explicit_alphabet)
        self.explicit_ranges = ranges.from_chars(self.explicit_chars)
        self.other_ranges = ranges.subtract(ranges.FULL, self.explicit_ranges)
        self._identity_tokens: Dict[int, int] = {}
        self._kept_alive: List[object] = []

    # -- building atoms -------------------------------------------------

    def atoms_for(self, parser: CharacterLevelParser) -> List['_Atom']:
        atoms: List[_Atom] = []
        for json_parser in self._flatten(parser):
            atoms.extend(self._atoms_for_json_parser(json_parser))
        return atoms

    def _flatten(self, parser: CharacterLevelParser) -> List[JsonSchemaParser]:
        if isinstance(parser, JsonSchemaParser):
            return [parser]
        if isinstance(parser, UnionParser):
            result: List[JsonSchemaParser] = []
            for child in parser.parsers:
                result.extend(self._flatten(child))
            return result
        raise TypeError(f"Unexpected parser {type(parser).__name__} in a JSON schema parser")

    def _atoms_for_json_parser(self, parser: JsonSchemaParser) -> List['_Atom']:
        stack = parser.object_stack
        if stack:
            top = stack[-1]
            if isinstance(top, UnionParser) and _holds_open_string(top):
                atoms: List[_Atom] = []
                for option in top.parsers:
                    atoms.extend(self._atoms_for_json_parser(self._fork(parser, option)))
                return atoms
            if _is_open_string(top):
                machine = self._string_machine(top)
                if machine is None:
                    return []
                return [_StringAtom(self, parser, machine)]
        return [_StructAtom(self, parser)]

    def _fork(self, parser: JsonSchemaParser, option: CharacterLevelParser) -> JsonSchemaParser:
        stack = parser.object_stack[:-1] + [option]
        forked = JsonSchemaParser(parser.context, parser.config, stack,
                                  parser.num_consecutive_whitespaces)
        forked.context.active_parser = forked
        forked.last_parsed_string = parser.last_parsed_string
        forked.last_non_whitespace_character = parser.last_non_whitespace_character
        return forked

    def _string_machine(self, state: StringParsingState):
        if state.is_json_key:
            inner = _key_language(state)
            if inner is None:
                return None
            return KeyStringMachine(inner, '', track_parsed=bool(state.allowed_strings))
        inner = _inner_language(state)
        if inner is None:
            return None
        return ValueStringMachine(inner)

    # -- closing a string ------------------------------------------------

    def close_string(self, snapshot: JsonSchemaParser, parsed: str) -> List['_Atom']:
        # The cache lives on the snapshot so that it cannot outlive it. Object
        # addresses are reused once an object is freed, so they must never be
        # cache keys on their own.
        cache = getattr(snapshot, '_byte_close_cache', None)
        if cache is None:
            cache = {}
            snapshot._byte_close_cache = cache
        cached = cache.get(parsed)
        if cached is None:
            cached = self.atoms_for(self._closed_parser(snapshot, parsed))
            cache[parsed] = cached
        return cached

    def _closed_parser(self, snapshot: JsonSchemaParser, parsed: str) -> CharacterLevelParser:
        top = snapshot.object_stack[-1]
        assert isinstance(top, StringParsingState)
        replacement = top._clone()
        # The contents were handled by the string machine; the character level
        # parser only needs to see a string that it accepts and then close.
        replacement.allowed_strings = []
        replacement.pattern = None
        replacement.regex_parser = None
        replacement.min_length = None
        replacement.max_length = None
        replacement.parsed_string = parsed
        stack = snapshot.object_stack[:-1] + [replacement]
        holder = JsonSchemaParser(snapshot.context, snapshot.config, stack,
                                  snapshot.num_consecutive_whitespaces)
        holder.context.active_parser = holder
        holder.last_parsed_string = snapshot.last_parsed_string
        holder.last_non_whitespace_character = snapshot.last_non_whitespace_character
        return holder.add_character('"')

    # -- alphabet --------------------------------------------------------

    def decode_characters(self, characters: str) -> Tuple[RangeSet, frozenset]:
        char_set = frozenset(characters)
        named = ranges.from_chars(char_set - {SENTINEL})
        if SENTINEL in char_set:
            return ranges.union(named, self.other_ranges), char_set
        return named, char_set

    def character_for(self, code_point: int) -> str:
        char = chr(code_point)
        if char in self.explicit_chars:
            return char
        return SENTINEL

    # -- cache keys -------------------------------------------------------

    def identity_token(self, value: object) -> int:
        """A stable number for ``value``, which is kept alive to own its address."""
        address = id(value)
        token = self._identity_tokens.get(address)
        if token is None:
            token = len(self._kept_alive)
            self._kept_alive.append(value)
            self._identity_tokens[address] = token
        return token

    def describe(self, parser: JsonSchemaParser) -> Hashable:
        description = getattr(parser, '_byte_description', _UNSET)
        if description is _UNSET:
            description = self.describe_json_parser(parser)
            if description is None:
                description = ('identity', self.number, self.identity_token(parser))
            parser._byte_description = description
        return description

    def describe_json_parser(self, parser: JsonSchemaParser) -> Optional[Hashable]:
        parts: List[Hashable] = []
        for member in parser.object_stack:
            description = self.describe_member(member)
            if description is None:
                return None
            parts.append(description)
        return ('json', self.number, tuple(parts), parser.num_consecutive_whitespaces,
                parser.last_non_whitespace_character, parser.last_parsed_string)

    def describe_member(self, parser: CharacterLevelParser) -> Optional[Hashable]:
        if isinstance(parser, ObjectParsingState):
            return ('object', self.identity_token(parser.schema_object),
                    parser.current_stage.value, parser.is_dictionary,
                    tuple(sorted(parser.existing_keys)))
        if isinstance(parser, ListParsingState):
            return ('list', self.identity_token(parser.list_member_type), parser.min_items,
                    parser.max_items, parser.num_items_seen, parser.seen_list_opener,
                    parser.seen_list_closer)
        if isinstance(parser, NumberParsingState):
            return ('number', parser.allow_floating_point, parser.parsed_string,
                    parser.seen_decimal_point, parser.seen_whitespace_after_digits,
                    parser.seen_exponent, parser.seen_digit)
        if isinstance(parser, StringParsingState):
            allowed = tuple(parser.allowed_strings) if parser.allowed_strings else None
            return ('string', allowed, parser.require_opening_quote, parser.require_closing_quote,
                    parser.min_length, parser.max_length, parser.pattern, parser.parsed_string,
                    parser.seen_opening_quote, parser.seen_closing_quote, parser.is_json_key)
        if isinstance(parser, StringParser):
            return ('literal', parser.target_str)
        if isinstance(parser, ForceStopParser):
            return ('stop', parser.allow_whitespace)
        if isinstance(parser, UnionParser):
            descriptions = [self.describe_member(child) for child in parser.parsers]
            if any(description is None for description in descriptions):
                return None
            return ('union', tuple(descriptions))
        if isinstance(parser, SequenceParser):
            descriptions = [self.describe_member(child) for child in parser.parsers]
            if any(description is None for description in descriptions):
                return None
            return ('sequence', tuple(descriptions))
        if isinstance(parser, JsonSchemaParser):
            return self.describe_json_parser(parser)
        return None


class _StructAtom(_Atom):
    """A position in the document that the character level parser handles."""

    __slots__ = ('environment', 'parser', '_allowed', '_chars', '_key')

    def __init__(self, environment: JsonEnvironment, parser: JsonSchemaParser):
        self.environment = environment
        self.parser = parser
        self._allowed: Optional[RangeSet] = None
        self._chars: Optional[frozenset] = None
        self._key: Optional[Hashable] = None

    def _ensure(self) -> None:
        if self._allowed is None:
            self._allowed, self._chars = self.environment.decode_characters(
                self.parser.get_allowed_characters())

    def allowed(self) -> RangeSet:
        self._ensure()
        return self._allowed

    def can_end(self) -> bool:
        return self.parser.can_end()

    def advance(self, code_point: int) -> List[_Atom]:
        self._ensure()
        character = self.environment.character_for(code_point)
        if character not in self._chars:
            return []
        return self.environment.atoms_for(self.parser.add_character(character))

    def key(self) -> Hashable:
        if self._key is None:
            self._key = ('struct', self.environment.describe(self.parser))
        return self._key


class _StringAtom(_Atom):
    """A position inside the contents of a JSON string."""

    __slots__ = ('environment', 'snapshot', 'machine', '_key')

    def __init__(self, environment: JsonEnvironment, snapshot: JsonSchemaParser, machine):
        self.environment = environment
        self.snapshot = snapshot
        self.machine = machine
        self._key: Optional[Hashable] = None

    def allowed(self) -> RangeSet:
        return self.machine.allowed()

    def can_end(self) -> bool:
        return False

    def advance(self, code_point: int) -> List[_Atom]:
        moved = self.machine.advance(code_point)
        if moved is None:
            return []
        if moved is CLOSE:
            return self.environment.close_string(self.snapshot, self.machine.resume_value())
        return [_StringAtom(self.environment, self.snapshot, moved)]

    def key(self) -> Hashable:
        if self._key is None:
            self._key = ('instring', self.environment.describe(self.snapshot),
                         self.machine.key())
        return self._key


class JsonLang(Lang):
    """A union of positions that the document could currently be in."""

    __slots__ = ('atoms', '_allowed', '_key')

    def __init__(self, atoms: Tuple[_Atom, ...]):
        self.atoms = atoms
        self._allowed: Optional[RangeSet] = None
        self._key: Optional[Hashable] = None

    def allowed(self) -> RangeSet:
        if self._allowed is None:
            self._allowed = ranges.union_all(atom.allowed() for atom in self.atoms)
        return self._allowed

    def can_end(self) -> bool:
        return any(atom.can_end() for atom in self.atoms)

    def advance(self, code_point: int) -> Optional[Lang]:
        results: List[_Atom] = []
        for atom in self.atoms:
            if ranges.contains(atom.allowed(), code_point):
                results.extend(atom.advance(code_point))
        return make_json(results)

    def key(self) -> Hashable:
        if self._key is None:
            self._key = ('jsonlang', frozenset(atom.key() for atom in self.atoms))
        return self._key


def make_json(atoms: List[_Atom]) -> Optional[Lang]:
    unique: Dict[Hashable, _Atom] = {}
    for atom in atoms:
        atom_key = atom.key()
        if atom_key not in unique:
            unique[atom_key] = atom
    if not unique:
        return None
    return JsonLang(tuple(unique.values()))


def _default_alphabet() -> str:
    return COMPLETE_ALPHABET + WHITESPACE_CHARACTERS + '\\' + SENTINEL


def _compile_schema_patterns(value) -> None:
    """Compile every ``pattern`` in the schema up front.

    An unsupported pattern is then reported while the enforcer is being
    created, rather than in the middle of a generation.
    """
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'pattern' and isinstance(child, str):
                compile_pattern(strip_anchors(child))
            else:
                _compile_schema_patterns(child)
    elif isinstance(value, list):
        for child in value:
            _compile_schema_patterns(child)


def json_lang_for(parser: JsonSchemaParser) -> Optional[Lang]:
    """Create the byte level language of a ``JsonSchemaParser``."""
    _compile_schema_patterns(getattr(parser.context, 'json_schema', None))
    alphabet = _default_alphabet()
    previous_config = parser.config
    previous_without_quotes = parser.context.alphabet_without_quotes
    previous_skip = parser.context.skip_regex_parsers
    parser.config = replace(parser.config, alphabet=alphabet)
    parser.context.alphabet_without_quotes = alphabet.replace('"', '')
    parser.context.active_parser = parser
    # The contents of every string are handled here, so the automata that the
    # character level parser would build for schema patterns are never used.
    parser.context.skip_regex_parsers = True
    try:
        environment = JsonEnvironment(alphabet.replace(SENTINEL, ''))
        return make_json(environment.atoms_for(parser))
    except Exception:
        # Leave the parser as it was so that the caller can fall back to
        # matching decoded token strings.
        parser.config = previous_config
        parser.context.alphabet_without_quotes = previous_without_quotes
        parser.context.skip_regex_parsers = previous_skip
        raise


__all__ = ['JsonLang', 'JsonEnvironment', 'json_lang_for', 'SENTINEL']
