"""Sets of Unicode scalar values, represented as sorted disjoint ranges.

A range set is a tuple of ``(low, high)`` pairs, inclusive on both ends, sorted
and non overlapping. Surrogate code points (U+D800-U+DFFF) are never members:
they are not scalar values and cannot be encoded in UTF-8.
"""
from bisect import bisect_right
from typing import Iterable, List, Sequence, Tuple

RangeSet = Tuple[Tuple[int, int], ...]

MAX_CODE_POINT = 0x10FFFF
SURROGATE_LOW = 0xD800
SURROGATE_HIGH = 0xDFFF

EMPTY: RangeSet = ()
FULL: RangeSet = ((0, SURROGATE_LOW - 1), (SURROGATE_HIGH + 1, MAX_CODE_POINT))


def normalize(pairs: Iterable[Tuple[int, int]]) -> RangeSet:
    """Sort, clamp, drop surrogates and merge a sequence of inclusive ranges."""
    cleaned: List[Tuple[int, int]] = []
    for low, high in pairs:
        if low < 0:
            low = 0
        if high > MAX_CODE_POINT:
            high = MAX_CODE_POINT
        if low > high:
            continue
        # Surrogates are not scalar values, split them out.
        if low < SURROGATE_LOW:
            cleaned.append((low, min(high, SURROGATE_LOW - 1)))
        if high > SURROGATE_HIGH:
            cleaned.append((max(low, SURROGATE_HIGH + 1), high))
    if not cleaned:
        return EMPTY
    cleaned.sort()
    merged: List[Tuple[int, int]] = []
    current_low, current_high = cleaned[0]
    for low, high in cleaned[1:]:
        if low <= current_high + 1:
            if high > current_high:
                current_high = high
        else:
            merged.append((current_low, current_high))
            current_low, current_high = low, high
    merged.append((current_low, current_high))
    return tuple(merged)


def union(*range_sets: RangeSet) -> RangeSet:
    pairs: List[Tuple[int, int]] = []
    for range_set in range_sets:
        pairs.extend(range_set)
    return normalize(pairs)


def union_all(range_sets: Iterable[RangeSet]) -> RangeSet:
    pairs: List[Tuple[int, int]] = []
    for range_set in range_sets:
        pairs.extend(range_set)
    return normalize(pairs)


def intersect(left: RangeSet, right: RangeSet) -> RangeSet:
    if not left or not right:
        return EMPTY
    result: List[Tuple[int, int]] = []
    i = j = 0
    while i < len(left) and j < len(right):
        low = max(left[i][0], right[j][0])
        high = min(left[i][1], right[j][1])
        if low <= high:
            result.append((low, high))
        if left[i][1] < right[j][1]:
            i += 1
        else:
            j += 1
    return tuple(result)


def intersects(left: RangeSet, right: RangeSet) -> bool:
    if not left or not right:
        return False
    i = j = 0
    while i < len(left) and j < len(right):
        if max(left[i][0], right[j][0]) <= min(left[i][1], right[j][1]):
            return True
        if left[i][1] < right[j][1]:
            i += 1
        else:
            j += 1
    return False


def subtract(left: RangeSet, right: RangeSet) -> RangeSet:
    if not left:
        return EMPTY
    if not right:
        return left
    right = normalize(right)  # the walk below needs the subtrahend in order
    result: List[Tuple[int, int]] = []
    j = 0
    for low, high in left:
        current = low
        while j < len(right) and right[j][1] < current:
            j += 1
        k = j
        while k < len(right) and right[k][0] <= high:
            if right[k][0] > current:
                result.append((current, right[k][0] - 1))
            if right[k][1] + 1 > current:
                current = right[k][1] + 1
            if current > high:
                break
            k += 1
        if current <= high:
            result.append((current, high))
    return tuple(result)


def complement(range_set: RangeSet) -> RangeSet:
    return subtract(FULL, range_set)


def contains(range_set: RangeSet, code_point: int) -> bool:
    index = bisect_right(range_set, (code_point, MAX_CODE_POINT + 1))
    if index == 0:
        return False
    low, high = range_set[index - 1]
    return low <= code_point <= high


def contains_range(range_set: RangeSet, low: int, high: int) -> bool:
    """Whether the range set intersects the inclusive interval ``[low, high]``."""
    if low > high:
        return False
    index = bisect_right(range_set, (low, MAX_CODE_POINT + 1))
    if index > 0 and range_set[index - 1][1] >= low:
        return True
    return index < len(range_set) and range_set[index][0] <= high


def from_code_points(code_points: Iterable[int]) -> RangeSet:
    return normalize((code_point, code_point) for code_point in code_points)


def from_chars(chars: Iterable[str]) -> RangeSet:
    return normalize((ord(char), ord(char)) for char in chars)


def single(code_point: int) -> RangeSet:
    return normalize([(code_point, code_point)])


def size(range_set: RangeSet) -> int:
    return sum(high - low + 1 for low, high in range_set)


def iterate(range_set: RangeSet) -> Iterable[int]:
    for low, high in range_set:
        for code_point in range(low, high + 1):
            yield code_point


# --- UTF-8 helpers -----------------------------------------------------------

#: Number of bytes in the UTF-8 encoding that starts with each lead byte, or 0
#: if the byte cannot start a sequence.
_SEQUENCE_LENGTH: List[int] = [0] * 256
for _byte in range(0x00, 0x80):
    _SEQUENCE_LENGTH[_byte] = 1
for _byte in range(0xC2, 0xE0):
    _SEQUENCE_LENGTH[_byte] = 2
for _byte in range(0xE0, 0xF0):
    _SEQUENCE_LENGTH[_byte] = 3
for _byte in range(0xF0, 0xF5):
    _SEQUENCE_LENGTH[_byte] = 4

_MIN_FOR_LENGTH = (0, 0, 0x80, 0x800, 0x10000)
_MAX_FOR_LENGTH = (0, 0x7F, 0x7FF, 0xFFFF, 0x10FFFF)


def sequence_length(lead_byte: int) -> int:
    """Total number of bytes of the UTF-8 sequence starting with ``lead_byte``."""
    return _SEQUENCE_LENGTH[lead_byte]


def prefix_code_point_bounds(prefix: Sequence[int]) -> Tuple[int, int]:
    """Bounds of the code points whose UTF-8 encoding starts with ``prefix``.

    ``prefix`` must be a non empty sequence of byte values that is shorter than
    the full sequence. Returns ``(low, high)``; ``low > high`` means that no
    scalar value has this prefix.
    """
    lead = prefix[0]
    length = _SEQUENCE_LENGTH[lead]
    if length == 0 or len(prefix) >= length:
        return 1, 0
    if length == 1:
        return lead, lead
    value = lead & (0x7F >> length)
    for byte in prefix[1:]:
        if byte < 0x80 or byte > 0xBF:
            return 1, 0
        value = (value << 6) | (byte & 0x3F)
    remaining = length - len(prefix)
    low = value << (6 * remaining)
    high = low | ((1 << (6 * remaining)) - 1)
    if low < _MIN_FOR_LENGTH[length]:
        low = _MIN_FOR_LENGTH[length]
    if high > _MAX_FOR_LENGTH[length]:
        high = _MAX_FOR_LENGTH[length]
    return low, high


def decode_sequence(sequence: Sequence[int]) -> int:
    """Decode a complete UTF-8 sequence, or return -1 if it is not valid."""
    lead = sequence[0]
    length = _SEQUENCE_LENGTH[lead]
    if length == 0 or length != len(sequence):
        return -1
    if length == 1:
        return lead
    value = lead & (0x7F >> length)
    for byte in sequence[1:]:
        if byte < 0x80 or byte > 0xBF:
            return -1
        value = (value << 6) | (byte & 0x3F)
    if value < _MIN_FOR_LENGTH[length] or value > _MAX_FOR_LENGTH[length]:
        return -1
    if SURROGATE_LOW <= value <= SURROGATE_HIGH:
        return -1
    return value
