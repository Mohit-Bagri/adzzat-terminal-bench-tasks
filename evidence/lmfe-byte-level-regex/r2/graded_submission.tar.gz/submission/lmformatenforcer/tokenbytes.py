"""Reading the exact bytes of every token out of a ``tokenizers.Tokenizer``.

Token masks can only be exact when the bytes that each token adds to the output
are known, because byte level vocabularies contain tokens that hold part of a
UTF-8 character. Two vocabulary families are supported:

* byte level BPE (GPT-2 style), where each character of a token maps to one
  byte through the byte to unicode table, and
* SentencePiece style BPE with byte fallback (Llama style), where a piece of
  the form ``<0xNN>`` is a single byte and every other piece is its UTF-8
  encoding with ``U+2581`` standing for a space.
"""
import json
from functools import lru_cache
from typing import Any, Dict, Optional, Set

__all__ = ['token_bytes_from_tokenizer']

_SENTENCEPIECE_SPACE = '▁'
_HEX_DIGITS = '0123456789abcdefABCDEF'


@lru_cache(maxsize=1)
def _unicode_to_byte() -> Dict[str, int]:
    """The inverse of the byte to unicode table of byte level BPE vocabularies."""
    printable = (list(range(ord('!'), ord('~') + 1))
                 + list(range(ord('¡'), ord('¬') + 1))
                 + list(range(ord('®'), ord('ÿ') + 1)))
    code_points = printable[:]
    extra = 0
    for byte in range(256):
        if byte not in printable:
            printable.append(byte)
            code_points.append(256 + extra)
            extra += 1
    return {chr(code_point): byte for byte, code_point in zip(printable, code_points)}


def _tokenizer_description(tokenizer: Any) -> Dict[str, Any]:
    """The tokenizer as a dictionary, from its own serialisation if possible."""
    try:
        return json.loads(tokenizer.to_str())
    except Exception:  # noqa: BLE001
        pass
    # Fall back to what the object model exposes, which is enough to tell the
    # two supported families apart.
    decoder = getattr(tokenizer, 'decoder', None)
    model = getattr(tokenizer, 'model', None)
    return {
        'decoder': {'type': type(decoder).__name__} if decoder is not None else None,
        'model': {'type': type(model).__name__,
                  'byte_fallback': bool(getattr(model, 'byte_fallback', False))},
    }


def _has_byte_level_decoder(decoder: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(decoder, dict):
        return False
    kind = decoder.get('type')
    if kind == 'ByteLevel':
        return True
    if kind == 'Sequence':
        return any(_has_byte_level_decoder(child) for child in decoder.get('decoders') or [])
    return False


def _uses_byte_fallback(description: Dict[str, Any]) -> bool:
    model = description.get('model') or {}
    if model.get('byte_fallback'):
        return True
    decoder = description.get('decoder')
    return _mentions_byte_fallback(decoder)


def _mentions_byte_fallback(decoder: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(decoder, dict):
        return False
    if decoder.get('type') == 'ByteFallback':
        return True
    if decoder.get('type') == 'Sequence':
        return any(_mentions_byte_fallback(child) for child in decoder.get('decoders') or [])
    return False


def _special_token_ids(tokenizer: Any) -> Set[int]:
    special: Set[int] = set()
    try:
        added = tokenizer.get_added_tokens_decoder()
    except Exception:  # noqa: BLE001
        return special
    for token_id, token in added.items():
        if getattr(token, 'special', False):
            special.add(token_id)
    return special


def _byte_level_token_bytes(piece: str, table: Dict[str, int]) -> bytes:
    try:
        return bytes(table[character] for character in piece)
    except KeyError as error:
        raise ValueError(
            f"Token {piece!r} is not a byte level piece: {error} has no byte") from error


def _byte_fallback_token_bytes(piece: str) -> bytes:
    if (len(piece) == 6 and piece.startswith('<0x') and piece.endswith('>')
            and piece[3] in _HEX_DIGITS and piece[4] in _HEX_DIGITS):
        return bytes((int(piece[3:5], 16),))
    return piece.replace(_SENTENCEPIECE_SPACE, ' ').encode('utf-8')


def token_bytes_from_tokenizer(tokenizer: Any) -> Dict[int, bytes]:
    """The exact bytes that every regular token of ``tokenizer`` contributes.

    :param tokenizer: A ``tokenizers.Tokenizer``.
    :return: A mapping from token id to bytes, for every id of
        ``tokenizer.get_vocab(with_added_tokens=False)`` that is not a special
        added token.
    :raises ValueError: If the vocabulary is neither byte level BPE nor
        SentencePiece style BPE with byte fallback.
    """
    tokenizer = getattr(tokenizer, 'backend_tokenizer', tokenizer)
    description = _tokenizer_description(tokenizer)
    vocabulary = tokenizer.get_vocab(with_added_tokens=False)
    special = _special_token_ids(tokenizer)
    if _has_byte_level_decoder(description.get('decoder')):
        table = _unicode_to_byte()
        return {token_id: _byte_level_token_bytes(piece, table)
                for piece, token_id in vocabulary.items() if token_id not in special}
    if _uses_byte_fallback(description):
        return {token_id: _byte_fallback_token_bytes(piece)
                for piece, token_id in vocabulary.items() if token_id not in special}
    raise ValueError(
        "token_bytes_from_tokenizer supports byte level BPE vocabularies and "
        "SentencePiece style BPE vocabularies with byte fallback, but this "
        f"tokenizer uses neither (decoder: {(description.get('decoder') or {}).get('type')}, "
        f"model: {(description.get('model') or {}).get('type')})")
