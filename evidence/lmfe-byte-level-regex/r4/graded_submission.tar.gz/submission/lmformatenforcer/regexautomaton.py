"""A regular expression automaton over unicode scalar values.

The byte level token enforcer needs to know, for every state of a pattern, the exact set
of scalar values that can come next and whether the match can end. ``interegular``, which
RegexParser uses, works over an alphabet of characters that were mentioned in the pattern
plus a single "anything else" symbol that is expanded with the tokenizer alphabet, so it
cannot answer that question for characters that no token contains. This module compiles
the supported pattern syntax into character set transitions instead, and determinizes
lazily. Only states from which the pattern can still be completed are ever created, so a
state that exists is always live.

Supported syntax: literal characters, escapes, ``.``, bracket classes with ranges and
leading ``^`` negation, groups ``( )`` and ``(?: )``, alternation ``|``, and the
quantifiers ``?``, ``*``, ``+``, ``{m}``, ``{m,}`` and ``{m,n}``. A leading ``^`` and a
trailing ``$`` are accepted and ignored, as the whole output is always matched.
"""
from bisect import bisect_right
from typing import Dict, FrozenSet, List, Optional, Sequence, Set, Tuple

from .charset import (ALL_SCALARS, CODE_POINT_LIMIT, SURROGATE_END, SURROGATE_START,
                      CodePointSet, cs_complement, cs_from_ranges, cs_from_string, cs_intersect,
                      cs_is_empty)

DEAD_STATE = -1

_shorthand_cache: Dict[str, CodePointSet] = {}


def _shorthand_class(name: str) -> CodePointSet:
    """The unicode meaning of ``\\d``, ``\\w`` and ``\\s``, as the regex module has it.

    Built on first use, because it means walking the whole code point space.
    """
    cached = _shorthand_cache.get(name)
    if cached is not None:
        return cached
    import unicodedata
    ranges: List[Tuple[int, int]] = []
    for code_point in range(CODE_POINT_LIMIT):
        if SURROGATE_START <= code_point < SURROGATE_END:
            continue
        character = chr(code_point)
        category = unicodedata.category(character)
        if name == 'd':
            member = category == 'Nd'
        elif name == 'w':
            member = (category[0] in 'LM' or category in ('Nd', 'Nl', 'Pc')
                      or code_point in (0x200C, 0x200D))
        else:
            member = character.isspace() and not 0x1C <= code_point <= 0x1F
        if member:
            ranges.append((code_point, code_point + 1))
    cached = cs_from_ranges(ranges)
    _shorthand_cache[name] = cached
    return cached
_CONTROL_ESCAPES = {'n': '\n', 't': '\t', 'r': '\r', 'f': '\f', 'v': '\v', 'a': '\a', '0': '\0'}
_ANY_CHARACTER = cs_intersect(ALL_SCALARS, cs_complement(cs_from_string("\n")))


class RegexSyntaxError(ValueError):
    """Raised when a pattern uses syntax that the byte level enforcer does not support."""


class _Node:
    __slots__ = ()


class _Chars(_Node):
    __slots__ = ('chars',)

    def __init__(self, chars: CodePointSet):
        self.chars = chars


class _Concat(_Node):
    __slots__ = ('parts',)

    def __init__(self, parts: List[_Node]):
        self.parts = parts


class _Alternate(_Node):
    __slots__ = ('options',)

    def __init__(self, options: List[_Node]):
        self.options = options


class _Repeat(_Node):
    __slots__ = ('child', 'minimum', 'maximum')

    def __init__(self, child: _Node, minimum: int, maximum: Optional[int]):
        self.child = child
        self.minimum = minimum
        self.maximum = maximum


class _Parser:
    def __init__(self, pattern: str):
        self.pattern = pattern
        self.position = 0

    def error(self, message: str) -> RegexSyntaxError:
        return RegexSyntaxError(f"{message} at index {self.position} of regex '{self.pattern}'")

    def peek(self) -> str:
        return self.pattern[self.position] if self.position < len(self.pattern) else ''

    def parse(self) -> _Node:
        node = self.parse_alternation()
        if self.position != len(self.pattern):
            raise self.error(f"Unexpected '{self.peek()}'")
        return node

    def parse_alternation(self) -> _Node:
        options = [self.parse_concatenation()]
        while self.peek() == '|':
            self.position += 1
            options.append(self.parse_concatenation())
        return options[0] if len(options) == 1 else _Alternate(options)

    def parse_concatenation(self) -> _Node:
        parts: List[_Node] = []
        while True:
            character = self.peek()
            if character in ('', '|', ')'):
                break
            parts.append(self.parse_quantified())
        if len(parts) == 1:
            return parts[0]
        return _Concat(parts)

    def parse_quantified(self) -> _Node:
        node = self.parse_atom()
        while True:
            character = self.peek()
            if character == '?':
                self.position += 1
                node = _Repeat(node, 0, 1)
            elif character == '*':
                self.position += 1
                node = _Repeat(node, 0, None)
            elif character == '+':
                self.position += 1
                node = _Repeat(node, 1, None)
            elif character == '{':
                counts = self.try_parse_counts()
                if counts is None:
                    break
                node = _Repeat(node, counts[0], counts[1])
            else:
                break
            if self.peek() in ('?', '+'):
                # Lazy and possessive quantifiers do not change the matched language.
                self.position += 1
        return node

    def try_parse_counts(self) -> Optional[Tuple[int, Optional[int]]]:
        start = self.position
        self.position += 1  # the '{'
        digits = ''
        while self.peek().isdigit():
            digits += self.peek()
            self.position += 1
        if not digits:
            self.position = start
            return None
        minimum = int(digits)
        maximum: Optional[int] = minimum
        if self.peek() == ',':
            self.position += 1
            digits = ''
            while self.peek().isdigit():
                digits += self.peek()
                self.position += 1
            maximum = int(digits) if digits else None
        if self.peek() != '}':
            self.position = start
            return None
        self.position += 1
        if maximum is not None and maximum < minimum:
            raise self.error("Repetition maximum is smaller than its minimum")
        return minimum, maximum

    def parse_atom(self) -> _Node:
        character = self.peek()
        if character == '(':
            self.position += 1
            if self.pattern.startswith('?:', self.position):
                self.position += 2
            elif self.peek() == '?':
                raise self.error("Only plain and non capturing groups are supported")
            node = self.parse_alternation()
            if self.peek() != ')':
                raise self.error("Missing ')'")
            self.position += 1
            return node
        if character == '[':
            return _Chars(self.parse_class())
        if character == '.':
            self.position += 1
            return _Chars(_ANY_CHARACTER)
        if character == '\\':
            return _Chars(self.parse_escape(in_class=False))
        if character in ('*', '+', '?', ')'):
            raise self.error(f"Unexpected '{character}'")
        if character in ('^', '$'):
            # Anchors are redundant, the pattern always has to match the whole output.
            self.position += 1
            return _Concat([])
        self.position += 1
        return _Chars(cs_from_string(character))

    def parse_escape(self, in_class: bool) -> CodePointSet:
        self.position += 1  # the backslash
        character = self.peek()
        if character == '':
            raise self.error("Pattern ends with a backslash")
        self.position += 1
        lowered = character.lower()
        if lowered in ('d', 'w', 's'):
            shorthand = _shorthand_class(lowered)
            if character.isupper():
                return cs_intersect(ALL_SCALARS, cs_complement(shorthand))
            return shorthand
        if character in _CONTROL_ESCAPES:
            return cs_from_string(_CONTROL_ESCAPES[character])
        if character in ('x', 'u', 'U'):
            digits = {'x': 2, 'u': 4, 'U': 8}[character]
            value = self.pattern[self.position:self.position + digits]
            if len(value) != digits or any(c not in '0123456789abcdefABCDEF' for c in value):
                raise self.error(f"Invalid \\{character} escape")
            self.position += digits
            code_point = int(value, 16)
            if code_point > 0x10FFFF:
                raise self.error("Escape is above the highest code point")
            return cs_from_ranges([(code_point, code_point + 1)])
        if character.isalnum():
            raise self.error(f"Unsupported escape '\\{character}'")
        return cs_from_string(character)

    def parse_class(self) -> CodePointSet:
        self.position += 1  # the '['
        negated = False
        if self.peek() == '^':
            negated = True
            self.position += 1
        ranges: List[Tuple[int, int]] = []
        first = True
        while True:
            character = self.peek()
            if character == '':
                raise self.error("Missing ']'")
            if character == ']' and not first:
                self.position += 1
                break
            first = False
            if character == '\\':
                members = self.parse_escape(in_class=True)
                single = members[0] if len(members) == 2 and members[1] == members[0] + 1 else None
            else:
                self.position += 1
                members = cs_from_string(character)
                single = ord(character)
            if single is not None and self.peek() == '-' and self.position + 1 < len(self.pattern) \
                    and self.pattern[self.position + 1] != ']':
                self.position += 1
                if self.peek() == '\\':
                    high_set = self.parse_escape(in_class=True)
                    if len(high_set) != 2 or high_set[1] != high_set[0] + 1:
                        raise self.error("Class range end must be a single character")
                    high = high_set[0]
                else:
                    high = ord(self.peek())
                    self.position += 1
                if high < single:
                    raise self.error("Class range is reversed")
                ranges.append((single, high + 1))
            else:
                ranges.extend((lo, hi) for lo, hi in zip(members[0::2], members[1::2]))
        members_set = cs_from_ranges(ranges)
        if negated:
            return cs_intersect(ALL_SCALARS, cs_complement(members_set))
        return cs_intersect(ALL_SCALARS, members_set)


_MAX_NFA_STATES = 200000


class _NFA:
    def __init__(self) -> None:
        self.epsilon: List[List[int]] = []
        self.transitions: List[List[Tuple[CodePointSet, int]]] = []

    def new_state(self) -> int:
        if len(self.epsilon) >= _MAX_NFA_STATES:
            raise RegexSyntaxError("The pattern expands to too many states, most likely "
                                   "because of a very large repetition count")
        self.epsilon.append([])
        self.transitions.append([])
        return len(self.epsilon) - 1

    def build(self, node: _Node) -> Tuple[int, int]:
        if isinstance(node, _Chars):
            start = self.new_state()
            end = self.new_state()
            if not cs_is_empty(node.chars):
                self.transitions[start].append((node.chars, end))
            return start, end
        if isinstance(node, _Concat):
            start = self.new_state()
            current = start
            for part in node.parts:
                part_start, part_end = self.build(part)
                self.epsilon[current].append(part_start)
                current = part_end
            return start, current
        if isinstance(node, _Alternate):
            start = self.new_state()
            end = self.new_state()
            for option in node.options:
                option_start, option_end = self.build(option)
                self.epsilon[start].append(option_start)
                self.epsilon[option_end].append(end)
            return start, end
        if isinstance(node, _Repeat):
            start = self.new_state()
            current = start
            for _ in range(node.minimum):
                child_start, child_end = self.build(node.child)
                self.epsilon[current].append(child_start)
                current = child_end
            end = self.new_state()
            if node.maximum is None:
                loop = self.new_state()
                self.epsilon[current].append(loop)
                child_start, child_end = self.build(node.child)
                self.epsilon[loop].append(child_start)
                self.epsilon[child_end].append(loop)
                self.epsilon[loop].append(end)
            else:
                for _ in range(node.maximum - node.minimum):
                    self.epsilon[current].append(end)
                    child_start, child_end = self.build(node.child)
                    self.epsilon[current].append(child_start)
                    current = child_end
                self.epsilon[current].append(end)
            return start, end
        raise RegexSyntaxError(f"Unknown pattern node {node}")


class RegexAutomaton:
    """A deterministic automaton over scalar values for one pattern."""

    def __init__(self, pattern: str):
        self.pattern = pattern
        node = _Parser(pattern).parse()
        nfa = _NFA()
        start, accept = nfa.build(node)
        self._epsilon = nfa.epsilon
        self._transitions = nfa.transitions
        self._accept = accept
        self._useful = self._find_useful_states(accept)
        self._state_sets: List[FrozenSet[int]] = []
        self._state_ids: Dict[FrozenSet[int], int] = {}
        self._allowed: List[Optional[CodePointSet]] = []
        self._loops: List[Optional[CodePointSet]] = []
        self._bounds: List[Optional[Tuple[int, ...]]] = []
        self._targets: List[Optional[Tuple[int, ...]]] = []
        self._final: List[bool] = []
        self.initial = self._intern(self._closure([start]))

    def _find_useful_states(self, accept: int) -> Set[int]:
        """Every state from which the accepting state is reachable."""
        incoming: Dict[int, List[int]] = {}
        for state, targets in enumerate(self._epsilon):
            for target in targets:
                incoming.setdefault(target, []).append(state)
        for state, moves in enumerate(self._transitions):
            for _, target in moves:
                incoming.setdefault(target, []).append(state)
        useful = {accept}
        pending = [accept]
        while pending:
            state = pending.pop()
            for previous in incoming.get(state, ()):
                if previous not in useful:
                    useful.add(previous)
                    pending.append(previous)
        return useful

    def _closure(self, states: Sequence[int]) -> FrozenSet[int]:
        seen: Set[int] = set()
        pending = list(states)
        while pending:
            state = pending.pop()
            if state in seen:
                continue
            seen.add(state)
            pending.extend(self._epsilon[state])
        return frozenset(state for state in seen if state in self._useful)

    def _intern(self, states: FrozenSet[int]) -> int:
        if not states:
            return DEAD_STATE
        existing = self._state_ids.get(states)
        if existing is not None:
            return existing
        state_id = len(self._state_sets)
        self._state_ids[states] = state_id
        self._state_sets.append(states)
        self._allowed.append(None)
        self._loops.append(None)
        self._bounds.append(None)
        self._targets.append(None)
        self._final.append(self._accept in states)
        return state_id

    def _expand(self, state_id: int) -> None:
        """Compute the transition table of a state by splitting its character sets.

        The character sets of the outgoing transitions are swept from left to right, so
        that every elementary range is visited once together with the set of states it
        leads to. The target of a range is the epsilon closure of that set, which repeats
        often and is therefore cached.
        """
        events: List[Tuple[int, int, int]] = []
        for nfa_state in self._state_sets[state_id]:
            for chars, target in self._transitions[nfa_state]:
                for lo, hi in zip(chars[0::2], chars[1::2]):
                    events.append((lo, 1, target))
                    events.append((hi, -1, target))
        events.sort()
        active: Dict[int, int] = {}
        closures: Dict[FrozenSet[int], int] = {}
        bounds: List[int] = []
        targets: List[int] = []
        position = 0
        index = 0
        while index < len(events):
            boundary = events[index][0]
            if active and boundary > position:
                reached = frozenset(active)
                target_id = closures.get(reached)
                if target_id is None:
                    target_id = self._intern(self._closure(reached))
                    closures[reached] = target_id
                if target_id != DEAD_STATE:
                    if bounds and bounds[-1] == position and targets[-1] == target_id:
                        bounds[-1] = boundary
                    else:
                        bounds.append(position)
                        bounds.append(boundary)
                        targets.append(target_id)
            while index < len(events) and events[index][0] == boundary:
                _, delta, target = events[index]
                count = active.get(target, 0) + delta
                if count:
                    active[target] = count
                else:
                    del active[target]
                index += 1
            position = boundary
        self._bounds[state_id] = tuple(bounds)
        self._targets[state_id] = tuple(targets)
        self._allowed[state_id] = cs_from_ranges(zip(bounds[0::2], bounds[1::2]))
        self._loops[state_id] = cs_from_ranges(
            (lo, hi) for (lo, hi), target in zip(zip(bounds[0::2], bounds[1::2]), targets)
            if target == state_id)

    def allowed(self, state_id: int) -> CodePointSet:
        allowed = self._allowed[state_id]
        if allowed is None:
            self._expand(state_id)
            allowed = self._allowed[state_id]
        return allowed  # type: ignore[return-value]

    def loops(self, state_id: int) -> CodePointSet:
        loops = self._loops[state_id]
        if loops is None:
            self._expand(state_id)
            loops = self._loops[state_id]
        return loops  # type: ignore[return-value]

    def transition(self, state_id: int, code_point: int) -> int:
        bounds = self._bounds[state_id]
        if bounds is None:
            self._expand(state_id)
            bounds = self._bounds[state_id]
        index = bisect_right(bounds, code_point)  # type: ignore[arg-type]
        if index % 2 == 0:
            return DEAD_STATE
        return self._targets[state_id][(index - 1) // 2]  # type: ignore[index]

    def is_final(self, state_id: int) -> bool:
        return self._final[state_id]

    def accepts(self, text: str) -> bool:
        state = self.initial
        for character in text:
            state = self.transition(state, ord(character))
            if state == DEAD_STATE:
                return False
        return self.is_final(state)


_automaton_cache: Dict[str, RegexAutomaton] = {}


def get_automaton(pattern: str) -> RegexAutomaton:
    """A cached automaton for a pattern. Patterns may repeat inside one json schema."""
    automaton = _automaton_cache.get(pattern)
    if automaton is None:
        automaton = RegexAutomaton(pattern)
        _automaton_cache[pattern] = automaton
    return automaton
