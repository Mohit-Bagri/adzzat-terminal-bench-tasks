"""Character set level models of the parsers, for the byte level token enforcer.

``CharacterLevelParser.get_allowed_characters()`` returns a string, so it can only
describe characters that the caller put into the parser's alphabet. The byte level
enforcer needs the complete set of unicode scalar values that may come next, which this
module provides as character sets.

Three kinds of model are combined here:

* Regular expressions are compiled into an automaton over scalar values
  (:mod:`lmformatenforcer.regexautomaton`), which answers exactly and also knows which
  characters keep the state unchanged.
* The structure of a json schema is modelled by running the unmodified
  :class:`JsonSchemaParser`. Its alphabet is replaced by the characters the schema can
  distinguish plus one representative of "every other character", so a single run of the
  real parser describes the behaviour for all scalar values.
* The string values of a json schema follow json's own string rules instead of the
  character level interface: escapes and ``\\u`` surrogate pairs decode, and the schema's
  constraints apply to the decoded value. Those are modelled by :class:`JsonStringState`.

Every model exposes the same small interface: the set of allowed characters, the subset of
those that leave the state unchanged (which lets the trie traversal accept whole
subtrees), whether the output may end here, and the step to the next state. A state may
split into several alternatives, so a position is a tuple of alternatives,
:class:`ByteParserState`.
"""
from dataclasses import replace
from typing import Any, Dict, Hashable, Iterable, List, Optional, Sequence, Tuple

from .charset import (ALL_SCALARS, EMPTY, CodePointSet, cs_ascii_mask, cs_contains, cs_from_ranges,
                      cs_from_string, cs_intersect, cs_intersects, cs_is_empty, cs_ranges,
                      cs_subtract, cs_union, cs_union_all)
from .characterlevelparser import (CharacterLevelParser, CharacterLevelParserConfig, SequenceParser,
                                   StringParser, UnionParser)
from .consts import WHITESPACE_CHARACTERS
from .exceptions import LMFormatEnforcerException
from .jsonschemaparser import JsonSchemaParser, StringParsingState
from .regexautomaton import DEAD_STATE, RegexAutomaton, get_automaton
from .regexparser import RegexParser

_QUOTE = 0x22
_BACKSLASH = 0x5C
_QUOTE_SET = cs_from_string('"')
_BACKSLASH_SET = cs_from_string('\\')
_U_SET = cs_from_string('u')
_RAW_FORBIDDEN = cs_from_ranges([(0, 0x20), (_QUOTE, _QUOTE + 1), (_BACKSLASH, _BACKSLASH + 1)])
"""Characters that may not appear raw between the quotes of a json string."""
_SHORT_ESCAPES = {'"': 0x22, '\\': 0x5C, '/': 0x2F, 'b': 0x08, 'f': 0x0C,
                  'n': 0x0A, 'r': 0x0D, 't': 0x09}
_HEX_DIGITS = "0123456789abcdef"
_HEX_VALUES = {character: value for value, character in enumerate(_HEX_DIGITS)}
_HEX_VALUES.update({character.upper(): value for value, character in enumerate(_HEX_DIGITS)})
_DIGIT_SETS = [cs_from_string(_HEX_DIGITS[value] + _HEX_DIGITS[value].upper())
               for value in range(16)]
_HIGH_SURROGATE_START = 0xD800
_LOW_SURROGATE_START = 0xDC00
_SURROGATE_END = 0xE000
_SUPPLEMENTARY_START = 0x10000
_CHAR_LEVEL_ESCAPE_SET = cs_from_string('"\\/bfnrtu')
_WHITESPACE_SET = cs_from_string(WHITESPACE_CHARACTERS)
_HEX_SET = cs_from_string(_HEX_DIGITS + _HEX_DIGITS.upper())
_RESUMED_STRING_PLACEHOLDER = "\ufffc"


# --------------------------------------------------------------------------------------
# Constraints on the decoded value of a json string
# --------------------------------------------------------------------------------------

class ValueRule:
    """What the decoded value of a json string value is still allowed to become."""

    __slots__ = ()

    def viable(self) -> CodePointSet:
        """Characters that can be appended to the value and still allow a legal value."""
        raise NotImplementedError()

    def loops(self) -> CodePointSet:
        """Characters whose addition leads back to an equal rule."""
        return EMPTY

    def can_end(self) -> bool:
        """Does the value as decoded so far satisfy the constraint?"""
        raise NotImplementedError()

    def add(self, code_point: int) -> Optional['ValueRule']:
        raise NotImplementedError()

    def key(self) -> Hashable:
        raise NotImplementedError()


class FreeTextRule(ValueRule):
    """A string value with an optional minimum and maximum number of characters."""

    __slots__ = ('minimum', 'maximum', 'count')

    def __init__(self, minimum: int, maximum: Optional[int], count: int):
        self.minimum = minimum
        self.maximum = maximum
        # Without a maximum, the exact count stops mattering once the minimum is reached.
        self.count = count if maximum is not None else min(count, minimum)

    def viable(self) -> CodePointSet:
        if self.maximum is not None and self.count >= self.maximum:
            return EMPTY
        return ALL_SCALARS

    def loops(self) -> CodePointSet:
        if self.maximum is None and self.count >= self.minimum:
            return ALL_SCALARS
        return EMPTY

    def can_end(self) -> bool:
        return self.count >= self.minimum

    def add(self, code_point: int) -> Optional['ValueRule']:
        if self.maximum is not None and self.count >= self.maximum:
            return None
        return FreeTextRule(self.minimum, self.maximum, self.count + 1)

    def key(self) -> Hashable:
        return ('free', self.minimum, self.maximum, self.count)


class EnumRule(ValueRule):
    """A string value that has to be one of a list of strings."""

    __slots__ = ('suffixes',)

    def __init__(self, suffixes: Tuple[str, ...]):
        self.suffixes = suffixes

    def viable(self) -> CodePointSet:
        return cs_from_ranges((ord(suffix[0]), ord(suffix[0]) + 1)
                              for suffix in self.suffixes if suffix)

    def can_end(self) -> bool:
        return '' in self.suffixes

    def add(self, code_point: int) -> Optional['ValueRule']:
        character = chr(code_point)
        remaining = tuple(suffix[1:] for suffix in self.suffixes if suffix[:1] == character)
        return EnumRule(remaining) if remaining else None

    def key(self) -> Hashable:
        return ('enum', self.suffixes)


class PatternRule(ValueRule):
    """A string value that has to match a pattern, matched against the decoded value."""

    __slots__ = ('automaton', 'state')

    def __init__(self, automaton: RegexAutomaton, state: int):
        self.automaton = automaton
        self.state = state

    def viable(self) -> CodePointSet:
        return self.automaton.allowed(self.state)

    def loops(self) -> CodePointSet:
        return self.automaton.loops(self.state)

    def can_end(self) -> bool:
        return self.automaton.is_final(self.state)

    def add(self, code_point: int) -> Optional['ValueRule']:
        state = self.automaton.transition(self.state, code_point)
        return PatternRule(self.automaton, state) if state != DEAD_STATE else None

    def key(self) -> Hashable:
        return ('pattern', id(self.automaton), self.state)


def _rule_for_string_parser(parser: StringParsingState) -> Optional[ValueRule]:
    """The constraint of a json string value, following the parser's own precedence.

    Returns None for a pattern that cannot be compiled, in which case the string is left
    to the character level interface of the real parser.
    """
    if parser.pattern:
        try:
            automaton = get_automaton(parser.pattern)
        except Exception:
            return None
        return PatternRule(automaton, automaton.initial)
    if parser.allowed_strings:
        strings = tuple(sorted({value for value in parser.allowed_strings
                                if isinstance(value, str)}))
        return EnumRule(strings)
    return FreeTextRule(parser.min_length or 0, parser.max_length, 0)


# --------------------------------------------------------------------------------------
# The json string value state machine
# --------------------------------------------------------------------------------------

MODE_RAW = 0
MODE_ESCAPE = 1
MODE_HEX = 2
MODE_PAIR_BACKSLASH = 3
MODE_PAIR_U = 4
MODE_PAIR_HEX = 5

CLOSED = 'closed'
"""Returned by a step that consumed the closing quote of a string."""


class JsonStringState:
    """A position inside the quotes of a json string value.

    The characters are the raw characters of the output, the constraint applies to the
    decoded value, and escapes are decoded on the way: ``\\u6771`` and ``東`` reach the
    same state, and a surrogate pair decodes to the single character it encodes.
    """

    __slots__ = ('rule', 'mode', 'digits', 'value', 'high', '_allowed', '_loops',
                 '_bmp_targets', '_pair_targets')

    def __init__(self, rule: ValueRule, mode: int = MODE_RAW, digits: int = 0,
                 value: int = 0, high: int = 0):
        self.rule = rule
        self.mode = mode
        self.digits = digits
        self.value = value
        self.high = high
        self._allowed: Optional[CodePointSet] = None
        self._loops: Optional[CodePointSet] = None
        self._bmp_targets: Optional[CodePointSet] = None
        self._pair_targets: Optional[CodePointSet] = None

    def key(self) -> Hashable:
        return (self.rule.key(), self.mode, self.digits, self.value, self.high)

    def bmp_targets(self) -> CodePointSet:
        """The 16 bit values a ``\\u`` escape may still produce.

        A value that is a high surrogate is included when some low surrogate can follow
        it to form a character the constraint still allows.
        """
        if self._bmp_targets is None:
            viable = self.rule.viable()
            ranges = [(lo, min(hi, _SUPPLEMENTARY_START))
                      for lo, hi in cs_ranges(viable) if lo < _SUPPLEMENTARY_START]
            for lo, hi in cs_ranges(viable):
                if hi <= _SUPPLEMENTARY_START:
                    continue
                low = max(lo, _SUPPLEMENTARY_START)
                first = _HIGH_SURROGATE_START + ((low - _SUPPLEMENTARY_START) >> 10)
                last = _HIGH_SURROGATE_START + ((hi - 1 - _SUPPLEMENTARY_START) >> 10)
                ranges.append((first, last + 1))
            self._bmp_targets = cs_from_ranges(ranges)
        return self._bmp_targets

    def pair_targets(self) -> CodePointSet:
        """The low surrogate values that may follow the high surrogate already seen."""
        if self._pair_targets is None:
            base = _SUPPLEMENTARY_START + ((self.high - _HIGH_SURROGATE_START) << 10)
            viable = cs_intersect(self.rule.viable(), cs_from_ranges([(base, base + 0x400)]))
            shift = _LOW_SURROGATE_START - base
            self._pair_targets = cs_from_ranges((lo + shift, hi + shift)
                                                for lo, hi in cs_ranges(viable))
        return self._pair_targets

    def _digit_set(self, targets: CodePointSet) -> CodePointSet:
        shift = 4 * (3 - self.digits)
        width = 1 << shift
        sets = []
        for value in range(16):
            low = (self.value * 16 + value) << shift
            if cs_intersects(targets, low, low + width):
                sets.append(_DIGIT_SETS[value])
        return cs_union_all(sets)

    def allowed(self) -> CodePointSet:
        if self._allowed is None:
            mode = self.mode
            if mode == MODE_RAW:
                viable = self.rule.viable()
                allowed = cs_subtract(viable, _RAW_FORBIDDEN)
                if self.rule.can_end():
                    allowed = cs_union(allowed, _QUOTE_SET)
                if not cs_is_empty(viable):
                    # Every scalar value can be written as an escape, so a backslash is
                    # allowed exactly when some character is still allowed.
                    allowed = cs_union(allowed, _BACKSLASH_SET)
                self._allowed = allowed
            elif mode == MODE_ESCAPE:
                viable = self.rule.viable()
                characters = [character for character, decoded in _SHORT_ESCAPES.items()
                              if cs_contains(viable, decoded)]
                allowed = cs_from_string("".join(characters))
                if not cs_is_empty(self.bmp_targets()):
                    allowed = cs_union(allowed, _U_SET)
                self._allowed = allowed
            elif mode == MODE_HEX:
                self._allowed = self._digit_set(self.bmp_targets())
            elif mode == MODE_PAIR_BACKSLASH:
                self._allowed = _BACKSLASH_SET if self.pair_targets() else EMPTY
            elif mode == MODE_PAIR_U:
                self._allowed = _U_SET if self.pair_targets() else EMPTY
            else:
                self._allowed = self._digit_set(self.pair_targets())
        return self._allowed

    def loops(self) -> CodePointSet:
        if self._loops is None:
            if self.mode == MODE_RAW:
                self._loops = cs_subtract(self.rule.loops(), _RAW_FORBIDDEN)
            else:
                self._loops = EMPTY
        return self._loops

    def step(self, code_point: int) -> Any:
        """The next state, ``CLOSED`` after the closing quote, or None when not allowed."""
        mode = self.mode
        if mode == MODE_RAW:
            if code_point == _QUOTE:
                return CLOSED if self.rule.can_end() else None
            if code_point == _BACKSLASH:
                return JsonStringState(self.rule, MODE_ESCAPE)
            if code_point < 0x20:
                return None  # raw control characters are not legal json
            rule = self.rule.add(code_point)
            return JsonStringState(rule, MODE_RAW) if rule is not None else None
        if mode == MODE_ESCAPE:
            character = chr(code_point)
            if character == 'u':
                return JsonStringState(self.rule, MODE_HEX)
            decoded = _SHORT_ESCAPES.get(character)
            if decoded is None:
                return None
            rule = self.rule.add(decoded)
            return JsonStringState(rule, MODE_RAW) if rule is not None else None
        if mode == MODE_HEX or mode == MODE_PAIR_HEX:
            digit = _HEX_VALUES.get(chr(code_point))
            if digit is None:
                return None
            value = self.value * 16 + digit
            if self.digits < 3:
                return JsonStringState(self.rule, mode, self.digits + 1, value, self.high)
            if mode == MODE_HEX:
                if _HIGH_SURROGATE_START <= value < _LOW_SURROGATE_START:
                    return JsonStringState(self.rule, MODE_PAIR_BACKSLASH, 0, 0, value)
                if _LOW_SURROGATE_START <= value < _SURROGATE_END:
                    return None  # an unpaired low surrogate escape is never legal
                decoded = value
            else:
                if not _LOW_SURROGATE_START <= value < _SURROGATE_END:
                    return None
                decoded = (_SUPPLEMENTARY_START + ((self.high - _HIGH_SURROGATE_START) << 10)
                           + value - _LOW_SURROGATE_START)
            rule = self.rule.add(decoded)
            return JsonStringState(rule, MODE_RAW) if rule is not None else None
        if mode == MODE_PAIR_BACKSLASH:
            if code_point != _BACKSLASH:
                return None
            return JsonStringState(self.rule, MODE_PAIR_U, 0, 0, self.high)
        if code_point != ord('u'):
            return None
        return JsonStringState(self.rule, MODE_PAIR_HEX, 0, 0, self.high)


class CharLevelStringState:
    """A position inside an unconstrained string of the character level interface.

    Free text property names follow the character level interface rather than json's
    string rules, so any scalar value is legal raw, and a backslash starts an escape that
    is only checked for shape. The content does not matter, only how many whitespace
    characters stand at the end, because the json parser stops allowing whitespace after
    `max_consecutive_whitespaces` of them. That keeps the state tiny, which keeps the
    traversal of such strings cheap.
    """

    __slots__ = ('mode', 'digits', 'whitespace', 'whitespace_limit')

    def __init__(self, whitespace_limit: int, mode: int = MODE_RAW, digits: int = 0,
                 whitespace: int = 0):
        self.whitespace_limit = whitespace_limit
        self.mode = mode
        self.digits = digits
        self.whitespace = min(whitespace, whitespace_limit)

    def key(self) -> Hashable:
        return (self.mode, self.digits, self.whitespace, self.whitespace_limit)

    def allowed(self) -> CodePointSet:
        if self.mode != MODE_RAW:
            return _CHAR_LEVEL_ESCAPE_SET if self.mode == MODE_ESCAPE else _HEX_SET
        if self.whitespace >= self.whitespace_limit:
            return cs_subtract(ALL_SCALARS, _WHITESPACE_SET)
        return ALL_SCALARS

    def loops(self) -> CodePointSet:
        if self.mode != MODE_RAW:
            return EMPTY
        # A whitespace character changes how many of them are at the end, and any other
        # character sets that count back to zero.
        loops = cs_subtract(ALL_SCALARS, cs_union(cs_union(_QUOTE_SET, _BACKSLASH_SET),
                                                  _WHITESPACE_SET))
        return loops if self.whitespace == 0 else EMPTY

    def step(self, code_point: int) -> Any:
        limit = self.whitespace_limit
        if self.mode == MODE_RAW:
            if code_point == _QUOTE:
                return CLOSED
            if code_point == _BACKSLASH:
                return CharLevelStringState(limit, MODE_ESCAPE)
            if cs_contains(_WHITESPACE_SET, code_point):
                if self.whitespace >= limit:
                    return None
                return CharLevelStringState(limit, MODE_RAW, 0, self.whitespace + 1)
            return self if self.whitespace == 0 else CharLevelStringState(limit)
        if self.mode == MODE_ESCAPE:
            character = chr(code_point)
            if character == 'u':
                return CharLevelStringState(limit, MODE_HEX)
            return CharLevelStringState(limit) if character in _SHORT_ESCAPES else None
        if chr(code_point) not in _HEX_VALUES:
            return None
        if self.digits < 3:
            return CharLevelStringState(limit, MODE_HEX, self.digits + 1)
        return CharLevelStringState(limit)


# --------------------------------------------------------------------------------------
# Alternatives
# --------------------------------------------------------------------------------------

class Alternative:
    """One deterministic possibility for the state of the output so far."""

    __slots__ = ()

    def allowed(self) -> CodePointSet:
        raise NotImplementedError()

    def loops(self) -> CodePointSet:
        """Characters that lead back to this very alternative."""
        return EMPTY

    def can_end(self) -> bool:
        raise NotImplementedError()

    def step(self, code_point: int) -> Sequence['Alternative']:
        raise NotImplementedError()


class RegexAlternative(Alternative):
    """A position in a regular expression, as a state of its automaton."""

    __slots__ = ('context', 'automaton', 'state')

    def __init__(self, context: 'ModelContext', automaton: RegexAutomaton, state: int):
        self.context = context
        self.automaton = automaton
        self.state = state

    def allowed(self) -> CodePointSet:
        return self.automaton.allowed(self.state)

    def loops(self) -> CodePointSet:
        return self.automaton.loops(self.state)

    def can_end(self) -> bool:
        return self.automaton.is_final(self.state)

    def step(self, code_point: int) -> Sequence[Alternative]:
        state = self.automaton.transition(self.state, code_point)
        if state == DEAD_STATE:
            return ()
        return (self.context.regex_alternative(self.automaton, state),)


class ExactStringAlternative(Alternative):
    """A position in a :class:`StringParser`, which allows exactly one string."""

    __slots__ = ('context', 'target', 'position', '_allowed')

    def __init__(self, context: 'ModelContext', target: str, position: int):
        self.context = context
        self.target = target
        self.position = position
        self._allowed = (cs_from_string(target[position]) if position < len(target) else EMPTY)

    def allowed(self) -> CodePointSet:
        return self._allowed

    def can_end(self) -> bool:
        return self.position >= len(self.target)

    def step(self, code_point: int) -> Sequence[Alternative]:
        if self.position < len(self.target) and ord(self.target[self.position]) == code_point:
            return (self.context.exact_string_alternative(self.target, self.position + 1),)
        return ()


class SequenceAlternative(Alternative):
    """A :class:`SequenceParser`: the first item is in progress, the rest follow."""

    __slots__ = ('context', 'items', '_positions', '_allowed', '_loops')

    def __init__(self, context: 'ModelContext', items: Tuple['ByteParserState', ...]):
        self.context = context
        self.items = items
        self._positions: Optional[Tuple[int, ...]] = None
        self._allowed: Optional[CodePointSet] = None
        self._loops: Optional[CodePointSet] = None

    def positions(self) -> Tuple[int, ...]:
        """The items that may receive the next character, like SequenceParser does."""
        if self._positions is None:
            positions = []
            for index, item in enumerate(self.items):
                positions.append(index)
                if not item.can_end():
                    break
            self._positions = tuple(positions)
        return self._positions

    def allowed(self) -> CodePointSet:
        if self._allowed is None:
            self._allowed = cs_union_all(self.items[index].allowed() for index in self.positions())
        return self._allowed

    def loops(self) -> CodePointSet:
        if self._loops is None:
            positions = self.positions()
            loops = self.items[0].loops()
            if len(positions) > 1:
                others = cs_union_all(self.items[index].allowed() for index in positions[1:])
                loops = cs_subtract(loops, others)
            self._loops = loops
        return self._loops

    def can_end(self) -> bool:
        return all(item.can_end() for item in self.items)

    def step(self, code_point: int) -> Sequence[Alternative]:
        results: List[Alternative] = []
        for index in self.positions():
            item = self.items[index]
            if not cs_contains(item.allowed(), code_point):
                continue
            advanced = item.step(code_point)
            if advanced is None:
                continue
            if index + 1 == len(self.items):
                results.extend(advanced.alternatives)
            else:
                results.append(self.context.sequence_alternative(
                    (advanced,) + self.items[index + 1:]))
        return results


class JsonStructureAlternative(Alternative):
    """A position in the structure of a json document, held by the real parser."""

    __slots__ = ('context', 'parser', '_characters', '_allowed', '_steps')

    def __init__(self, context: 'ModelContext', parser: CharacterLevelParser):
        self.context = context
        self.parser = parser
        self._characters: Optional[str] = None
        self._allowed: Optional[CodePointSet] = None
        self._steps: Dict[str, Sequence[Alternative]] = {}

    def allowed(self) -> CodePointSet:
        if self._allowed is None:
            self._characters = self.parser.get_allowed_characters()
            self._allowed = self.context.charset_of(self._characters)
        return self._allowed

    def can_end(self) -> bool:
        return self.parser.can_end()

    def step(self, code_point: int) -> Sequence[Alternative]:
        self.allowed()
        character = self.context.character_for(code_point, self._characters)
        cached = self._steps.get(character)
        if cached is None:
            cached = self.context.advance_real_parser(self.parser, character)
            self._steps[character] = cached
        return cached


class StringResume:
    """How to carry on with the structure once a string value has been closed."""

    __slots__ = ('context', 'parser', 'template', '_alternatives')

    def __init__(self, context: 'ModelContext', parser: JsonSchemaParser,
                 template: StringParsingState):
        self.context = context
        self.parser = parser
        self.template = template
        self._alternatives: Optional[Tuple[Alternative, ...]] = None

    def alternatives(self) -> Tuple[Alternative, ...]:
        """The structure state the closing quote leads to.

        Once a string is closed, every string parser behaves the same way: it can end and
        allows only whitespace. So the parser that was reading the string is replaced by a
        closed copy of itself, and the bookkeeping that ``JsonSchemaParser.add_character``
        does after a character is applied.
        """
        if self._alternatives is None:
            self._alternatives = self.context.close_string(self.parser, self.template)
        return self._alternatives


class JsonStringAlternative(Alternative):
    """A position inside a json string value, following json's string rules."""

    __slots__ = ('context', 'resume', 'state')

    def __init__(self, context: 'ModelContext', resume: StringResume, state: JsonStringState):
        self.context = context
        self.resume = resume
        self.state = state

    def allowed(self) -> CodePointSet:
        return self.state.allowed()

    def loops(self) -> CodePointSet:
        return self.state.loops()

    def can_end(self) -> bool:
        return False  # the string still has to be closed

    def step(self, code_point: int) -> Sequence[Alternative]:
        result = self.state.step(code_point)
        if result is None:
            return ()
        if result is CLOSED:
            return self.resume.alternatives()
        return (self.context.json_string_alternative(self.resume, result),)


class CharLevelStringAlternative(Alternative):
    """A position inside a free text property name, per the character level interface."""

    __slots__ = ('context', 'resume', 'state')

    def __init__(self, context: 'ModelContext', resume: StringResume,
                 state: CharLevelStringState):
        self.context = context
        self.resume = resume
        self.state = state

    def allowed(self) -> CodePointSet:
        return self.state.allowed()

    def loops(self) -> CodePointSet:
        return self.state.loops()

    def can_end(self) -> bool:
        return False

    def step(self, code_point: int) -> Sequence[Alternative]:
        result = self.state.step(code_point)
        if result is None:
            return ()
        if result is CLOSED:
            return self.resume.alternatives()
        return (self.context.char_level_string_alternative(self.resume, result),)


class GenericAlternative(Alternative):
    """Any other character level parser, driven through its own interface."""

    __slots__ = ('context', 'parser', '_characters', '_allowed', '_steps')

    def __init__(self, context: 'ModelContext', parser: CharacterLevelParser):
        self.context = context
        self.parser = parser
        self._characters: Optional[str] = None
        self._allowed: Optional[CodePointSet] = None
        self._steps: Dict[str, Sequence[Alternative]] = {}

    def allowed(self) -> CodePointSet:
        if self._allowed is None:
            self._characters = self.parser.get_allowed_characters()
            self._allowed = self.context.charset_of(self._characters)
        return self._allowed

    def can_end(self) -> bool:
        return self.parser.can_end()

    def step(self, code_point: int) -> Sequence[Alternative]:
        self.allowed()
        character = self.context.character_for(code_point, self._characters)
        cached = self._steps.get(character)
        if cached is None:
            try:
                updated = self.parser.add_character(character)
            except LMFormatEnforcerException:
                raise
            except Exception:
                cached = ()  # a parser that rejects a character it allowed leads nowhere
            else:
                cached = (self.context.generic_alternative(updated),)
            self._steps[character] = cached
        return cached


class StoppedAlternative(Alternative):
    """Nothing more may be generated, but the output as it stands may end.

    Used where the character level enforcer falls back to a ForceStopParser, when a
    sequence contains a token that the constraint does not allow.
    """

    __slots__ = ()

    def allowed(self) -> CodePointSet:
        return EMPTY

    def can_end(self) -> bool:
        return True

    def step(self, code_point: int) -> Sequence[Alternative]:
        return ()


# --------------------------------------------------------------------------------------
# States
# --------------------------------------------------------------------------------------

class ByteParserState:
    """A position in the output, as the set of alternatives that are still possible."""

    __slots__ = ('context', 'alternatives', '_allowed', '_loops', '_loops_mask', '_can_end',
                 '_steps', 'masks')

    def __init__(self, context: 'ModelContext', alternatives: Tuple[Alternative, ...]):
        self.context = context
        self.alternatives = alternatives
        self._allowed: Optional[CodePointSet] = None
        self._loops: Optional[CodePointSet] = None
        self._loops_mask: int = -1
        self._can_end: Optional[bool] = None
        self._steps: Dict[int, Optional['ByteParserState']] = {}
        self.masks: Dict[bytes, Any] = {}

    def allowed(self) -> CodePointSet:
        if self._allowed is None:
            self._allowed = cs_union_all(alternative.allowed()
                                         for alternative in self.alternatives)
        return self._allowed

    def loops(self) -> CodePointSet:
        """Characters that lead back to this very state, so a subtree can be taken whole."""
        if self._loops is None:
            loops = None
            for alternative in self.alternatives:
                other = alternative.loops()
                loops = other if loops is None else cs_intersect(loops, other)
                if not loops:
                    break
            self._loops = loops or EMPTY
            self._loops_mask = cs_ascii_mask(self._loops)
        return self._loops

    def loops_mask(self) -> int:
        if self._loops_mask < 0:
            self.loops()
        return self._loops_mask

    def can_end(self) -> bool:
        if self._can_end is None:
            self._can_end = any(alternative.can_end() for alternative in self.alternatives)
        return self._can_end

    def step(self, code_point: int) -> Optional['ByteParserState']:
        cached = self._steps.get(code_point, False)
        if cached is not False:
            return cached  # type: ignore[return-value]
        results: List[Alternative] = []
        for alternative in self.alternatives:
            if cs_contains(alternative.allowed(), code_point):
                results.extend(alternative.step(code_point))
        state = self.context.state(results) if results else None
        self._steps[code_point] = state
        return state


class ModelContext:
    """Shared state for one root parser: canonical alternatives, states and the alphabet.

    Alternatives and states are interned, so equal positions are the same object. That
    makes the token mask cache on a state effective across sequences, and lets the
    traversal compare states by identity.
    """

    def __init__(self, root_parser: CharacterLevelParser):
        significant = _significant_characters(root_parser)
        self.significant = significant
        self.representative = _pick_representative(significant)
        self.other_characters = cs_subtract(ALL_SCALARS, significant)
        alphabet = "".join(chr(code_point) for lo, hi in cs_ranges(significant)
                           for code_point in range(lo, hi))
        self.alphabet = alphabet + self.representative
        self.config = CharacterLevelParserConfig(alphabet=self.alphabet)
        self._states: Dict[Tuple[int, ...], ByteParserState] = {}
        self._regex: Dict[Tuple[int, int], RegexAlternative] = {}
        self._exact: Dict[Tuple[str, int], ExactStringAlternative] = {}
        self._sequences: Dict[Tuple[int, ...], SequenceAlternative] = {}
        self._json_strings: Dict[Tuple[int, Hashable], JsonStringAlternative] = {}
        self._char_strings: Dict[Tuple[int, Hashable], CharLevelStringAlternative] = {}
        self._charsets: Dict[str, CodePointSet] = {}
        self._character_sets: Dict[str, frozenset] = {}
        self.stopped = StoppedAlternative()
        self.initial = self.state(self.build(root_parser))

    # -- interning -------------------------------------------------------------------

    def state(self, alternatives: Iterable[Alternative]) -> ByteParserState:
        unique: Dict[int, Alternative] = {}
        for alternative in alternatives:
            unique[id(alternative)] = alternative
        key = tuple(sorted(unique))
        existing = self._states.get(key)
        if existing is None:
            existing = ByteParserState(self, tuple(unique[item] for item in key))
            self._states[key] = existing
        return existing

    def regex_alternative(self, automaton: RegexAutomaton, state: int) -> RegexAlternative:
        key = (id(automaton), state)
        existing = self._regex.get(key)
        if existing is None:
            existing = RegexAlternative(self, automaton, state)
            self._regex[key] = existing
        return existing

    def exact_string_alternative(self, target: str, position: int) -> ExactStringAlternative:
        key = (target, position)
        existing = self._exact.get(key)
        if existing is None:
            existing = ExactStringAlternative(self, target, position)
            self._exact[key] = existing
        return existing

    def sequence_alternative(self, items: Tuple[ByteParserState, ...]) -> SequenceAlternative:
        key = tuple(id(item) for item in items)
        existing = self._sequences.get(key)
        if existing is None:
            existing = SequenceAlternative(self, items)
            self._sequences[key] = existing
        return existing

    def json_string_alternative(self, resume: StringResume,
                                state: JsonStringState) -> JsonStringAlternative:
        key = (id(resume), state.key())
        existing = self._json_strings.get(key)
        if existing is None:
            existing = JsonStringAlternative(self, resume, state)
            self._json_strings[key] = existing
        return existing

    def char_level_string_alternative(self, resume: StringResume,
                                      state: CharLevelStringState) -> CharLevelStringAlternative:
        key = (id(resume), state.key())
        existing = self._char_strings.get(key)
        if existing is None:
            existing = CharLevelStringAlternative(self, resume, state)
            self._char_strings[key] = existing
        return existing

    def generic_alternative(self, parser: CharacterLevelParser) -> Alternative:
        return GenericAlternative(self, parser)

    # -- characters ------------------------------------------------------------------

    def character_for(self, code_point: int, allowed_characters: Optional[str] = None) -> str:
        """The character to hand to a real parser, which cannot tell "other" ones apart.

        A parser that names the character itself gets it as it is, so that a parser whose
        alphabet is wider than the characters we collected still behaves correctly.
        """
        if cs_contains(self.significant, code_point):
            return chr(code_point)
        if allowed_characters is not None \
                and chr(code_point) in self.character_set(allowed_characters):
            return chr(code_point)
        return self.representative

    def character_set(self, characters: str) -> frozenset:
        cached = self._character_sets.get(characters)
        if cached is None:
            cached = frozenset(characters)
            self._character_sets[characters] = cached
        return cached

    def charset_of(self, characters: str) -> CodePointSet:
        """Turn an allowed character string of a real parser into a character set."""
        cached = self._charsets.get(characters)
        if cached is None:
            ranges = []
            includes_other = False
            for character in characters:
                if character == self.representative:
                    includes_other = True
                else:
                    ranges.append((ord(character), ord(character) + 1))
            cached = cs_from_ranges(ranges)
            if includes_other:
                cached = cs_union(cached, self.other_characters)
            self._charsets[characters] = cached
        return cached

    # -- building models from parsers -------------------------------------------------

    def build(self, parser: CharacterLevelParser) -> List[Alternative]:
        """The alternatives a parser starts in, as a byte level model."""
        if isinstance(parser, RegexParser):
            pattern = getattr(parser.context, 'pattern_string', None)
            if pattern is not None:
                try:
                    automaton = get_automaton(pattern)
                except Exception:
                    automaton = None  # fall back to the parser's own fsm
                if automaton is not None:
                    return [self.regex_alternative(automaton, automaton.initial)]
            return [self.generic_alternative(_with_config(parser, self.config_for(parser)))]
        if isinstance(parser, JsonSchemaParser):
            return list(self.wrap_json(_rebuild_json_parser(parser, self.config_for(parser))))
        if isinstance(parser, StringParser):
            return [self.exact_string_alternative(parser.target_str, 0)]
        if isinstance(parser, UnionParser):
            alternatives: List[Alternative] = []
            for option in parser.parsers:
                alternatives.extend(self.build(option))
            return alternatives
        if isinstance(parser, SequenceParser):
            items = tuple(self.state(self.build(option)) for option in parser.parsers)
            if len(items) == 1:
                return list(items[0].alternatives)
            return [self.sequence_alternative(items)]
        return [self.generic_alternative(_with_config(parser, self.config_for(parser)))]

    def config_for(self, parser: CharacterLevelParser) -> CharacterLevelParserConfig:
        """The parser's own configuration, with every scalar value in the alphabet."""
        try:
            return replace(parser.config, alphabet=self.alphabet)
        except Exception:
            return self.config

    # -- json ------------------------------------------------------------------------

    def wrap_json(self, parser: CharacterLevelParser) -> Sequence[Alternative]:
        """Model a json parser state, taking over if it is inside a string."""
        if isinstance(parser, UnionParser):
            alternatives: List[Alternative] = []
            for option in parser.parsers:
                alternatives.extend(self.wrap_json(option))
            return alternatives
        if isinstance(parser, JsonSchemaParser):
            taken_over = self._string_alternatives(parser)
            if taken_over is not None:
                return taken_over
            return (JsonStructureAlternative(self, parser),)
        return (self.generic_alternative(parser),)

    def _string_alternatives(self, parser: JsonSchemaParser) -> Optional[Sequence[Alternative]]:
        """Take over from the real parser when it has just opened a string."""
        if not parser.object_stack:
            return None
        members = _union_members(parser.object_stack[-1])
        starts = []
        for member in members:
            if not (isinstance(member, StringParsingState) and member.require_opening_quote
                    and member.seen_opening_quote and not member.seen_closing_quote
                    and not member.parsed_string):
                return None
            starts.append(member)
        if not starts:
            return None
        if any(member.is_key for member in starts):
            if len(starts) != 1 or not _is_free_text_key(parser, starts[0]):
                return None  # a constrained property name stays with the real parser
            limit = parser.config.max_consecutive_whitespaces
            resume = StringResume(self, parser, starts[0])
            return (self.char_level_string_alternative(
                resume, CharLevelStringState(max(limit, 0))),)
        rules = [_rule_for_string_parser(member) for member in starts]
        if any(rule is None for rule in rules):
            return None  # a pattern we cannot compile stays with the real parser
        resume = StringResume(self, parser, starts[0])
        return tuple(self.json_string_alternative(resume, JsonStringState(rule))
                     for rule in rules if rule is not None)

    def advance_real_parser(self, parser: CharacterLevelParser,
                            character: str) -> Sequence[Alternative]:
        try:
            updated = parser.add_character(character)
        except LMFormatEnforcerException:
            # A schema the parser cannot support, which the user should hear about.
            raise
        except Exception:
            return ()
        return self.wrap_json(updated)

    def close_string(self, parser: JsonSchemaParser,
                     template: StringParsingState) -> Tuple[Alternative, ...]:
        """Replace the string parser on top of the stack with a closed copy of it."""
        finished = template._clone()
        finished.seen_opening_quote = True
        finished.seen_closing_quote = True
        finished.parsed_string = _RESUMED_STRING_PLACEHOLDER
        context = parser.context
        context.active_parser = parser
        stack = list(parser.object_stack)
        updated = JsonSchemaParser(context, parser.config, stack,
                                   parser.num_consecutive_whitespaces)
        context.active_parser = updated
        updated.last_parsed_string = parser.last_parsed_string
        updated.object_stack[-1] = finished
        updated.num_consecutive_whitespaces = 0
        updated.last_non_whitespace_character = '"'
        return tuple(self.wrap_json(updated))


def _union_members(parser: CharacterLevelParser) -> List[CharacterLevelParser]:
    if isinstance(parser, UnionParser):
        members: List[CharacterLevelParser] = []
        for option in parser.parsers:
            members.extend(_union_members(option))
        return members
    return [parser]


def _is_free_text_key(parser: JsonSchemaParser, key_parser: StringParsingState) -> bool:
    """May a free text property name be modelled without the real parser?

    The content of such a name only matters when the enclosing object has required
    properties, because the parser remembers which ones it has seen.
    """
    if key_parser.allowed_strings or key_parser.pattern:
        return False
    if key_parser.min_length or key_parser.max_length:
        return False
    if len(parser.object_stack) < 2:
        return False
    from .jsonschemaparser import ObjectParsingState
    below = parser.object_stack[-2]
    if not isinstance(below, ObjectParsingState):
        return False
    return not (below.schema_object.required or [])


def _with_config(parser: CharacterLevelParser,
                 config: CharacterLevelParserConfig) -> CharacterLevelParser:
    try:
        parser.config = config
    except Exception:
        pass
    return parser


def _rebuild_json_parser(parser: JsonSchemaParser,
                         config: CharacterLevelParserConfig) -> JsonSchemaParser:
    """A fresh json parser for the same schema, with the byte level alphabet.

    A copy is used rather than the caller's parser so that the mutable context the json
    parser shares between its states is ours alone.
    """
    schema = getattr(parser.context, 'json_schema_dict', None)
    if schema is not None:
        return JsonSchemaParser(schema, config)
    import copy
    duplicate = copy.deepcopy(parser)
    duplicate.config = config
    duplicate.context.alphabet_without_quotes = config.alphabet.replace('"', '')
    duplicate.context.active_parser = duplicate
    return duplicate


def _pick_representative(significant: CodePointSet) -> str:
    """A character that stands for every character the parsers cannot tell apart."""
    for code_point in range(0xE000, 0xF8FF):
        if not cs_contains(significant, code_point):
            return chr(code_point)
    for code_point in range(0x80, 0x110000):
        if not cs_contains(significant, code_point) and not 0xD800 <= code_point < 0xE000:
            return chr(code_point)
    raise ValueError("No character is left to represent the rest of the alphabet")


def _significant_characters(parser: CharacterLevelParser) -> CodePointSet:
    """Every character a real parser of this tree can tell apart from the others.

    That is all of ASCII, which covers json's structure, numbers and escapes, plus every
    character that appears in the schemas, patterns and strings of the parsers.
    """
    characters: List[Tuple[int, int]] = [(0, 0x80)]

    def add_text(text: str) -> None:
        characters.extend((ord(character), ord(character) + 1) for character in text)

    def walk_schema(schema: Any) -> None:
        if isinstance(schema, dict):
            for key, value in schema.items():
                add_text(str(key))
                if key == 'pattern' and isinstance(value, str):
                    add_pattern_alphabet(value)
                walk_schema(value)
        elif isinstance(schema, (list, tuple)):
            for item in schema:
                walk_schema(item)
        elif isinstance(schema, str):
            add_text(schema)

    def add_pattern_alphabet(pattern: str) -> None:
        """The characters the real regex parser of a schema pattern can tell apart.

        RegexParser works over the alphabet that interegular derives from the pattern, so
        every character of a class such as ``[\u4e00-\u9fa5]`` is one of them, not just
        the characters that the pattern spells out.
        """
        # StringParsingState strips a leading '^' and a trailing '$' before it builds its
        # RegexParser, because the whole value is always matched.
        if pattern.startswith('^'):
            pattern = pattern[1:]
        if pattern.endswith('$'):
            pattern = pattern[:-1]
        try:
            import interegular
            from interegular.fsm import anything_else
            from interegular.patterns import REFlags
            alphabet = interegular.parse_pattern(pattern).get_alphabet(REFlags(0))
        except Exception:
            return
        characters.extend((ord(symbol), ord(symbol) + 1) for symbol in alphabet
                          if symbol is not anything_else and isinstance(symbol, str)
                          and len(symbol) == 1)

    def walk_parser(current: CharacterLevelParser) -> None:
        if isinstance(current, RegexParser):
            pattern = getattr(current.context, 'pattern_string', None)
            if pattern:
                add_text(pattern)
            alphabet = getattr(current.context.pattern, 'alphabet', None)
            if alphabet is not None:
                characters.extend((ord(symbol), ord(symbol) + 1) for symbol in alphabet
                                  if isinstance(symbol, str) and len(symbol) == 1)
        elif isinstance(current, JsonSchemaParser):
            schema = getattr(current.context, 'json_schema_dict', None)
            if schema is not None:
                walk_schema(schema)
            else:
                walk_schema(current.context.model_class.model_dump())
        elif isinstance(current, StringParser):
            add_text(current.target_str)
        elif isinstance(current, (UnionParser, SequenceParser)):
            for option in current.parsers:
                walk_parser(option)

    walk_parser(parser)
    return cs_from_ranges(characters)
