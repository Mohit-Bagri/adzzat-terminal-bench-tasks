"""The byte level token filter.

When the tokenizer data knows the exact bytes of every token, the token enforcer works on
bytes instead of decoded strings. A token is allowed exactly when appending its bytes
keeps the output a strict UTF-8 prefix of some string the parser accepts, which includes
outputs that end in the middle of a character. The end of sequence token is allowed
exactly when the output is complete UTF-8 that the parser accepts in full.

The search walks the trie of token bytes (:mod:`lmformatenforcer.tokenbytetrie`) together
with the parser model (:mod:`lmformatenforcer.bytelevelparser`), pruning a subtree as soon
as its characters are not allowed, and taking a whole subtree at once when the parser
allows all of its characters without changing state. Masks are cached per parser state and
unfinished character, so repeated states cost nothing.
"""
from bisect import bisect_left
from typing import Dict, List, Sequence, TYPE_CHECKING, Tuple

from .charset import cs_contains, cs_intersects, cs_ranges
from .bytelevelparser import ByteParserState, ModelContext
from .characterlevelparser import CharacterLevelParser
from .tokenbytetrie import TokenByteTrie, TrieNode, prefix_code_point_range, utf8_length
from .tokenlist import TokenList

if TYPE_CHECKING:
    from .tokenenforcer import TokenEnforcerTokenizerData


class ByteTokenEnforcer:
    """Token filtering over the exact bytes of the vocabulary."""

    def __init__(self, tokenizer_data: 'TokenEnforcerTokenizerData',
                 parser: CharacterLevelParser):
        self.trie: TokenByteTrie = tokenizer_data.get_byte_trie()
        self.token_bytes: Dict[int, bytes] = tokenizer_data.token_bytes
        self.use_bitmask: bool = tokenizer_data.use_bitmask
        self.vocab_size: int = tokenizer_data.vocab_size
        eos = tokenizer_data.eos_token_id
        self.eos_token_ids: List[int] = list(eos) if isinstance(eos, list) else [eos]
        # An end of sequence token is not a regular token, so it normally has no bytes.
        self._eos_has_bytes = any(token_id in self.token_bytes for token_id in self.eos_token_ids)
        self.context = ModelContext(parser)
        self.stopped_state = self.context.state([self.context.stopped])
        self.prefix_states: Dict[Tuple[int, ...], Tuple[ByteParserState, bytes, TokenList]] = {}

    # -- public interface --------------------------------------------------------------

    def get_allowed_tokens(self, token_sequence: Sequence[int]) -> TokenList:
        key = tuple(token_sequence)
        existing = self.prefix_states.get(key)
        if existing is not None:
            return existing[2]
        previous = self.prefix_states.get(key[:-1]) if key else None
        if previous is None:
            # The first call for a sequence carries the prompt, which is not constrained.
            state, partial = self.context.initial, b''
        else:
            state, partial = self._advance(previous[0], previous[1], key[-1])
        mask = self.mask(state, partial)
        self.prefix_states[key] = (state, partial, mask)
        return mask

    def mask(self, state: ByteParserState, partial: bytes) -> TokenList:
        """The allowed tokens for a parser state and an unfinished character."""
        cached = state.masks.get(partial)
        if cached is not None:
            return cached
        tokens: List[int] = []
        root = self.trie.root if not partial else self.trie.partial_root(partial)
        self._collect(root, state, tokens)
        if not partial and state.can_end():
            tokens.extend(self.eos_token_ids)
            if self._eos_has_bytes:
                tokens = list(set(tokens))
        tokens.sort()
        token_list = TokenList(self.use_bitmask, self.vocab_size)
        token_list.extend(tokens)
        state.masks[partial] = token_list
        return token_list

    # -- the search --------------------------------------------------------------------

    def _collect(self, root: TrieNode, root_state: ByteParserState, out: List[int]) -> None:
        """Collect every token of the trie whose characters the parser allows.

        A subtree is taken whole when the parser allows all of its characters and stays in
        the same state for each of them, which is what happens inside free text, and it is
        skipped as soon as a character is not allowed.
        """
        pending: List[Tuple[TrieNode, ByteParserState]] = [(root, root_state)]
        while pending:
            node, state = pending.pop()
            loops = state.loops()
            loops_mask = state.loops_mask()
            if loops and node.subtree_within(loops, loops_mask):
                out.extend(node.subtree)
                continue
            if node.tokens:
                out.extend(node.tokens)
            allowed = state.allowed()
            if not allowed:
                continue
            for lo, hi, tokens in node.partials:
                # These tokens end inside a character, so any code point it can still
                # become is enough for them to be allowed.
                if cs_intersects(allowed, lo, hi):
                    out.extend(tokens)
            code_points = node.code_points
            if not code_points:
                continue
            children = node.children
            count = len(code_points)
            if len(allowed) > count:
                # More ranges than children, so ask about every child instead of scanning.
                candidates = [index for index in range(count)
                              if cs_contains(allowed, code_points[index])]
            else:
                candidates = []
                for lo, hi in cs_ranges(allowed):
                    index = bisect_left(code_points, lo)
                    while index < count and code_points[index] < hi:
                        candidates.append(index)
                        index += 1
            for index in candidates:
                code_point = code_points[index]
                child = children[index]
                if loops and cs_contains(loops, code_point) \
                        and child.subtree_within(loops, loops_mask):
                    out.extend(child.subtree)
                    continue
                following = state.step(code_point)
                if following is not None:
                    pending.append((child, following))

    # -- following the generated tokens ------------------------------------------------

    def _advance(self, state: ByteParserState, partial: bytes,
                 token_id: int) -> Tuple[ByteParserState, bytes]:
        data = self.token_bytes.get(token_id)
        if not data:
            # Tokens without bytes, such as the end of sequence token, add nothing.
            return state, partial
        buffer = partial
        for byte in data:
            if not buffer:
                length = utf8_length(byte)
                if length == 0:
                    return self._stopped()
                if length == 1:
                    state = state.step(byte)  # type: ignore[assignment]
                    if state is None:
                        return self._stopped()
                    continue
                buffer = bytes((byte,))
                continue
            buffer += bytes((byte,))
            code_range = prefix_code_point_range(buffer)
            if code_range is None:
                return self._stopped()
            if len(buffer) == utf8_length(buffer[0]):
                state = state.step(code_range[0])  # type: ignore[assignment]
                if state is None:
                    return self._stopped()
                buffer = b''
        if buffer:
            # The token left a character unfinished, which only works if the parser allows
            # one of the characters it can still become.
            code_range = prefix_code_point_range(buffer)
            if code_range is None or not cs_intersects(state.allowed(), *code_range):
                return self._stopped()
        return state, buffer

    def _stopped(self) -> Tuple[ByteParserState, bytes]:
        """A sequence left the language, which can happen in beam search scenarios."""
        return self.stopped_state, b''
