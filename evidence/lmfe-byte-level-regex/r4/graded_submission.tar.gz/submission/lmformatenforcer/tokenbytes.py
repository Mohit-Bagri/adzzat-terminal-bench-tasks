"""The exact bytes of every token of a tokenizer.

:class:`~lmformatenforcer.tokenenforcer.TokenEnforcerTokenizerData` can take a mapping
from token id to the bytes that the token adds to the output, which lets the token
enforcer be exact for vocabularies whose tokens do not respect character boundaries.
:func:`token_bytes_from_tokenizer` builds that mapping for the two vocabulary families
that hold bytes rather than text:

* Byte level BPE, as GPT-2 and most models trained on it use: every character of a token
  stands for one byte through the byte to unicode table that such tokenizers apply before
  training, and the decoder is a ``ByteLevel`` decoder.
* SentencePiece style BPE with byte fallback, as Llama uses: the model sets
  ``byte_fallback``, pieces of the form ``<0xNN>`` are single bytes, and every other piece
  is text in which ``▁`` stands for a space.
"""
import json
from functools import lru_cache
from typing import Any, Dict, List, Set

SENTENCEPIECE_SPACE = '▁'


@lru_cache(maxsize=1)
def byte_to_unicode() -> Dict[int, str]:
    """The byte to unicode table that byte level BPE tokenizers are trained with."""
    printable: List[int] = (list(range(ord('!'), ord('~') + 1))
                            + list(range(ord('¡'), ord('¬') + 1))
                            + list(range(ord('®'), ord('ÿ') + 1)))
    code_points = printable[:]
    extra = 0
    for byte in range(256):
        if byte not in printable:
            printable.append(byte)
            code_points.append(256 + extra)
            extra += 1
    return {byte: chr(code_point) for byte, code_point in zip(printable, code_points)}


@lru_cache(maxsize=1)
def unicode_to_byte() -> Dict[str, int]:
    """The inverse of :func:`byte_to_unicode`."""
    return {character: byte for byte, character in byte_to_unicode().items()}


def token_bytes_from_tokenizer(tokenizer) -> Dict[int, bytes]:
    """The exact bytes of every regular token of a `tokenizers.Tokenizer`.

    :param tokenizer: A `tokenizers.Tokenizer` with a byte level or a byte fallback
    vocabulary.
    :return: A mapping from token id to the bytes the token contributes to the output, for
    every token of the vocabulary except the special added tokens.
    :raises ValueError: If the bytes of the tokens cannot be determined, because the
    vocabulary is neither byte level nor byte fallback.
    """
    vocabulary = _vocabulary(tokenizer)
    special_ids = _special_token_ids(tokenizer)
    configuration = _configuration(tokenizer)
    if _is_byte_level(tokenizer, configuration):
        table = unicode_to_byte()
        return {token_id: _byte_level_bytes(piece, table)
                for piece, token_id in vocabulary.items() if token_id not in special_ids}
    if _has_byte_fallback(tokenizer, configuration):
        return {token_id: _byte_fallback_bytes(piece)
                for piece, token_id in vocabulary.items() if token_id not in special_ids}
    raise ValueError(
        "The bytes of the tokens of this tokenizer cannot be determined. Only byte level "
        "vocabularies (a ByteLevel decoder) and byte fallback vocabularies (a model with "
        "byte_fallback) are supported.")


def _byte_level_bytes(piece: str, table: Dict[str, int]) -> bytes:
    try:
        return bytes(table[character] for character in piece)
    except KeyError:
        raise ValueError(f"Token '{piece}' is not a byte level token, it contains a "
                         "character that does not stand for a byte") from None


def _byte_fallback_bytes(piece: str) -> bytes:
    if len(piece) == 6 and piece.startswith('<0x') and piece.endswith('>'):
        digits = piece[3:5]
        if all(digit in '0123456789abcdefABCDEF' for digit in digits):
            return bytes((int(digits, 16),))
    return piece.replace(SENTENCEPIECE_SPACE, ' ').encode('utf-8')


def _vocabulary(tokenizer) -> Dict[str, int]:
    try:
        return tokenizer.get_vocab(with_added_tokens=False)
    except TypeError:
        return tokenizer.get_vocab()


def _special_token_ids(tokenizer) -> Set[int]:
    try:
        added = tokenizer.get_added_tokens_decoder()
    except AttributeError:
        return set()
    return {token_id for token_id, token in added.items() if getattr(token, 'special', False)}


def _configuration(tokenizer) -> Dict[str, Any]:
    """The tokenizer's own json description, which names the decoder and the model."""
    try:
        return json.loads(tokenizer.to_str())
    except Exception:
        return {}


def _decoder_types(configuration: Dict[str, Any], tokenizer) -> List[str]:
    decoder = configuration.get('decoder')
    if isinstance(decoder, dict):
        kind = decoder.get('type')
        if kind == 'Sequence':
            return [str(part.get('type')) for part in decoder.get('decoders', [])
                    if isinstance(part, dict)]
        return [str(kind)]
    actual = getattr(tokenizer, 'decoder', None)
    return [type(actual).__name__] if actual is not None else []


def _is_byte_level(tokenizer, configuration: Dict[str, Any]) -> bool:
    return 'ByteLevel' in _decoder_types(configuration, tokenizer)


def _has_byte_fallback(tokenizer, configuration: Dict[str, Any]) -> bool:
    model = configuration.get('model')
    if isinstance(model, dict) and 'byte_fallback' in model:
        return bool(model['byte_fallback'])
    return bool(getattr(getattr(tokenizer, 'model', None), 'byte_fallback', False))
