"""Compact sets of unicode code points, used by the byte level token enforcer.

A character set is a flat tuple of ascending boundaries that describes the union of the
half open ranges ``[cs[0], cs[1]) | [cs[2], cs[3]) | ...``. The ranges are disjoint and
never touch, so a set has exactly one representation and membership is a single bisect.
"""
from bisect import bisect_right
from typing import Iterable, List, Sequence, Tuple

CodePointSet = Tuple[int, ...]

CODE_POINT_LIMIT = 0x110000
SURROGATE_START = 0xD800
SURROGATE_END = 0xE000

EMPTY: CodePointSet = ()
UNIVERSE: CodePointSet = (0, CODE_POINT_LIMIT)
"""Every code point, including the surrogates that UTF-8 cannot encode."""
ALL_SCALARS: CodePointSet = (0, SURROGATE_START, SURROGATE_END, CODE_POINT_LIMIT)
"""Every unicode scalar value, which is every code point except the surrogates."""


def cs_from_ranges(ranges: Iterable[Tuple[int, int]]) -> CodePointSet:
    """Build a character set from (start, end) pairs, end exclusive. Pairs may overlap."""
    ordered = sorted((lo, hi) for lo, hi in ranges if lo < hi)
    boundaries: List[int] = []
    for lo, hi in ordered:
        if boundaries and lo <= boundaries[-1]:
            if hi > boundaries[-1]:
                boundaries[-1] = hi
        else:
            boundaries.append(lo)
            boundaries.append(hi)
    return tuple(boundaries)



def cs_from_string(characters: str) -> CodePointSet:
    return cs_from_ranges((ord(c), ord(c) + 1) for c in characters)


def cs_is_empty(cs: CodePointSet) -> bool:
    return not cs


def cs_contains(cs: Sequence[int], code_point: int) -> bool:
    return bisect_right(cs, code_point) % 2 == 1


def cs_intersects(cs: Sequence[int], lo: int, hi: int) -> bool:
    """Does the set intersect the half open range [lo, hi)?"""
    if lo >= hi:
        return False
    index = bisect_right(cs, lo)
    if index % 2 == 1:
        return True
    return index < len(cs) and cs[index] < hi


def cs_covers(cs: Sequence[int], lo: int, hi: int) -> bool:
    """Does the set contain the whole half open range [lo, hi)?"""
    if lo >= hi:
        return True
    index = bisect_right(cs, lo)
    if index % 2 == 0:
        return False
    return cs[index] >= hi


def cs_union(first: CodePointSet, second: CodePointSet) -> CodePointSet:
    if not first:
        return second
    if not second:
        return first
    return cs_from_ranges(list(cs_ranges(first)) + list(cs_ranges(second)))


def cs_union_all(sets: Iterable[CodePointSet]) -> CodePointSet:
    ranges: List[Tuple[int, int]] = []
    for cs in sets:
        ranges.extend(cs_ranges(cs))
    return cs_from_ranges(ranges)


def cs_complement(cs: CodePointSet) -> CodePointSet:
    boundaries: List[int] = []
    previous = 0
    for lo, hi in cs_ranges(cs):
        if lo > previous:
            boundaries.append(previous)
            boundaries.append(lo)
        previous = hi
    if previous < CODE_POINT_LIMIT:
        boundaries.append(previous)
        boundaries.append(CODE_POINT_LIMIT)
    return tuple(boundaries)


def cs_intersect(first: CodePointSet, second: CodePointSet) -> CodePointSet:
    if not first or not second:
        return EMPTY
    result: List[int] = []
    first_index = 0
    second_index = 0
    while first_index < len(first) and second_index < len(second):
        lo = max(first[first_index], second[second_index])
        hi = min(first[first_index + 1], second[second_index + 1])
        if lo < hi:
            if result and result[-1] == lo:
                result[-1] = hi
            else:
                result.append(lo)
                result.append(hi)
        if first[first_index + 1] <= second[second_index + 1]:
            first_index += 2
        else:
            second_index += 2
    return tuple(result)


def cs_subtract(first: CodePointSet, second: CodePointSet) -> CodePointSet:
    if not second:
        return first
    return cs_intersect(first, cs_complement(second))


def cs_ranges(cs: CodePointSet) -> Iterable[Tuple[int, int]]:
    return zip(cs[0::2], cs[1::2])



def cs_ascii_mask(cs: CodePointSet) -> int:
    """A bitmask of the ASCII members of the set, bit i set when chr(i) is a member."""
    mask = 0
    for lo, hi in cs_ranges(cs):
        if lo >= 128:
            break
        mask |= ((1 << min(hi, 128)) - 1) ^ ((1 << lo) - 1)
    return mask


