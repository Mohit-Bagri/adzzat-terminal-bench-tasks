"""A trie over the exact bytes of every token, organized by character boundaries.

The token enforcer has to decide, for every token, whether appending its bytes keeps the
output a prefix of some legal string. Tokens of a byte level vocabulary do not respect
character boundaries: they may start in the middle of a character and they may end in the
middle of one. This trie therefore stores, for every node that sits on a character
boundary, the complete characters that can follow (so that a parser can be asked about
them), and separately the tokens that end inside the bytes of an unfinished character,
together with the range of code points that character can still become.

Each node also carries a summary of its whole subtree, which lets the traversal accept a
large subtree at once when the parser allows every character in it and does not change
state, which is the common case inside free text.
"""
import sys
from contextlib import contextmanager
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

from .charset import cs_covers, SURROGATE_END, SURROGATE_START

_LENGTH_BY_LEAD: List[int] = []
for _lead in range(256):
    if _lead < 0x80:
        _LENGTH_BY_LEAD.append(1)
    elif _lead < 0xC2:
        _LENGTH_BY_LEAD.append(0)  # continuation bytes and overlong two byte leads
    elif _lead < 0xE0:
        _LENGTH_BY_LEAD.append(2)
    elif _lead < 0xF0:
        _LENGTH_BY_LEAD.append(3)
    elif _lead < 0xF5:
        _LENGTH_BY_LEAD.append(4)
    else:
        _LENGTH_BY_LEAD.append(0)

_RANGE_BY_LENGTH = {1: (0, 0x80), 2: (0x80, 0x800), 3: (0x800, 0x10000), 4: (0x10000, 0x110000)}


def utf8_length(lead_byte: int) -> int:
    """The number of bytes of the character that starts with this byte, 0 if it cannot."""
    return _LENGTH_BY_LEAD[lead_byte]


def prefix_code_point_range(prefix: bytes) -> Optional[Tuple[int, int]]:
    """The code points a character can still become, given the first bytes of its UTF-8.

    Returns a half open range, or None when no valid character starts with these bytes.
    The range of a UTF-8 prefix is always contiguous, even where the surrogate block is
    excluded, because the excluded block always sits at one end of the range.
    """
    length = _LENGTH_BY_LEAD[prefix[0]]
    if length == 0 or len(prefix) > length:
        return None
    value = prefix[0] & (0x7F >> length) if length > 1 else prefix[0]
    for byte in prefix[1:]:
        if byte & 0xC0 != 0x80:
            return None
        value = (value << 6) | (byte & 0x3F)
    remaining = length - len(prefix)
    lo = value << (6 * remaining)
    hi = lo + (1 << (6 * remaining))
    valid_lo, valid_hi = _RANGE_BY_LENGTH[length]
    lo = max(lo, valid_lo)
    hi = min(hi, valid_hi)
    if lo >= hi:
        return None
    if length == 3:
        if lo >= SURROGATE_START and hi <= SURROGATE_END:
            return None
        if lo < SURROGATE_START < hi:
            hi = min(hi, SURROGATE_START)
        elif SURROGATE_START <= lo < SURROGATE_END:
            lo = SURROGATE_END
    return lo, hi


@contextmanager
def _deep_recursion() -> Iterator[None]:
    """Allow a recursion as deep as the longest token of the vocabulary is long."""
    previous_limit = sys.getrecursionlimit()
    sys.setrecursionlimit(max(previous_limit, 20000))
    try:
        yield
    finally:
        sys.setrecursionlimit(previous_limit)


class _ByteNode:
    __slots__ = ('children', 'tokens', 'keep', 'char_node')

    def __init__(self) -> None:
        self.children: Dict[int, '_ByteNode'] = {}
        self.tokens: List[int] = []
        self.keep = False
        self.char_node: Optional['TrieNode'] = None


class TrieNode:
    """A node of the trie that sits on a character boundary.

    ``code_points`` and ``children`` are parallel and sorted by code point, and describe
    the complete characters that may follow. ``partials`` holds, per group of tokens that
    end inside an unfinished character, the half open range of code points that character
    can still become. ``subtree`` is every token in the whole subtree, ``ascii_mask`` has
    one bit per ASCII character that appears in the subtree, and ``high_lo``/``high_hi``
    bound the non ASCII code points and partial ranges of the subtree.
    """

    __slots__ = ('tokens', 'code_points', 'children', 'partials', 'subtree',
                 'ascii_mask', 'high_lo', 'high_hi')

    def __init__(self, tokens: Tuple[int, ...], code_points: Tuple[int, ...],
                 children: Tuple['TrieNode', ...],
                 partials: Tuple[Tuple[int, int, Tuple[int, ...]], ...]):
        self.tokens = tokens
        self.code_points = code_points
        self.children = children
        self.partials = partials
        subtree: List[int] = list(tokens)
        ascii_mask = 0
        high_lo = 0
        high_hi = 0
        for lo, hi, partial_tokens in partials:
            subtree.extend(partial_tokens)
            high_lo = lo if high_lo == 0 or lo < high_lo else high_lo
            high_hi = max(high_hi, hi)
        for code_point, child in zip(code_points, children):
            if code_point < 128:
                ascii_mask |= 1 << code_point
            else:
                high_lo = code_point if high_lo == 0 or code_point < high_lo else high_lo
                high_hi = max(high_hi, code_point + 1)
            subtree.extend(child.subtree)
            ascii_mask |= child.ascii_mask
            if child.high_hi:
                high_lo = child.high_lo if high_lo == 0 or child.high_lo < high_lo else high_lo
                high_hi = max(high_hi, child.high_hi)
        self.subtree = tuple(subtree)
        self.ascii_mask = ascii_mask
        self.high_lo = high_lo
        self.high_hi = high_hi

    def subtree_within(self, cs: Sequence[int], ascii_mask: int) -> bool:
        """Is every character and partial range of the subtree inside this character set?

        ``ascii_mask`` must be the ASCII mask of ``cs``. The non ASCII part is tested
        against the bounding range of the subtree, so the answer can be a conservative
        no, which only costs some traversal speed.
        """
        if self.ascii_mask & ~ascii_mask:
            return False
        if self.high_hi and not cs_covers(cs, self.high_lo, self.high_hi):
            return False
        return True


class TokenByteTrie:
    """The trie of all token bytes, plus the views needed mid character."""

    def __init__(self, token_bytes: Dict[int, bytes]):
        byte_root = _ByteNode()
        for token_id, data in token_bytes.items():
            node = byte_root
            for byte in data:
                child = node.children.get(byte)
                if child is None:
                    child = _ByteNode()
                    node.children[byte] = child
                node = child
            node.tokens.append(token_id)
        self._byte_root = byte_root
        byte_root.keep = True
        self._mark_continuations(byte_root, b'')
        with _deep_recursion():
            self.root = self._char_node(byte_root)
        self._partial_roots: Dict[bytes, TrieNode] = {}

    def _mark_continuations(self, node: _ByteNode, path: bytes) -> None:
        """Keep the byte level view of the paths that can only be read mid character."""
        if len(path) >= 3:
            return
        for byte, child in node.children.items():
            if byte & 0xC0 == 0x80:
                child.keep = True
                self._mark_continuations(child, path + bytes((byte,)))

    def _char_node(self, byte_node: _ByteNode) -> TrieNode:
        if byte_node.char_node is not None:
            return byte_node.char_node
        entries: List[Tuple[int, TrieNode]] = []
        partials: List[Tuple[int, int, Tuple[int, ...]]] = []
        for byte, child in byte_node.children.items():
            length = _LENGTH_BY_LEAD[byte]
            if length == 0:
                continue  # can never start a character, only readable mid character
            if length == 1:
                entries.append((byte, self._char_node(child)))
            else:
                self._walk_character(child, bytes((byte,)), length, entries, partials)
        entries.sort()
        node = TrieNode(tuple(byte_node.tokens), tuple(entry[0] for entry in entries),
                        tuple(entry[1] for entry in entries), tuple(partials))
        byte_node.char_node = node
        if not byte_node.keep:
            # The byte level view of this node is only needed mid character, at the root.
            byte_node.children = {}
            byte_node.tokens = []
        return node

    def _walk_character(self, byte_node: _ByteNode, prefix: bytes, length: int,
                        entries: List[Tuple[int, TrieNode]],
                        partials: List[Tuple[int, int, Tuple[int, ...]]]) -> None:
        """Walk the bytes of one multi byte character, collecting what ends inside it."""
        code_range = prefix_code_point_range(prefix)
        if code_range is None:
            return
        if len(prefix) == length:
            entries.append((code_range[0], self._char_node(byte_node)))
            return
        if byte_node.tokens:
            partials.append((code_range[0], code_range[1], tuple(byte_node.tokens)))
        for byte, child in byte_node.children.items():
            self._walk_character(child, prefix + bytes((byte,)), length, entries, partials)

    def partial_root(self, partial: bytes) -> TrieNode:
        """The trie root as seen when the output ends inside the character ``partial``.

        The returned node describes the characters that the next token can complete the
        unfinished character into, and the tokens that leave it unfinished.
        """
        existing = self._partial_roots.get(partial)
        if existing is not None:
            return existing
        length = _LENGTH_BY_LEAD[partial[0]]
        entries: List[Tuple[int, TrieNode]] = []
        partials: List[Tuple[int, int, Tuple[int, ...]]] = []
        with _deep_recursion():
            self._walk_continuation(self._byte_root, b'', partial, length, entries,
                                    partials)
        entries.sort()
        node = TrieNode((), tuple(entry[0] for entry in entries),
                        tuple(entry[1] for entry in entries), tuple(partials))
        self._partial_roots[partial] = node
        return node

    def _walk_continuation(self, byte_node: _ByteNode, path: bytes, partial: bytes, length: int,
                           entries: List[Tuple[int, TrieNode]],
                           partials: List[Tuple[int, int, Tuple[int, ...]]]) -> None:
        for byte, child in byte_node.children.items():
            if byte & 0xC0 != 0x80:
                continue
            prefix = partial + path + bytes((byte,))
            code_range = prefix_code_point_range(prefix)
            if code_range is None:
                continue
            if len(prefix) == length:
                entries.append((code_range[0], self._char_node(child)))
                continue
            if child.tokens:
                partials.append((code_range[0], code_range[1], tuple(child.tokens)))
            self._walk_continuation(child, path + bytes((byte,)), partial, length,
                                    entries, partials)
