"""The exact bytes that every token of a tokenizer adds to the generated output.

`TokenEnforcerTokenizerData` can be given a `token_bytes` mapping in order to enforce formats
on the bytes of the tokens instead of on their decoded strings, which is what byte level
vocabularies need. This module builds that mapping from a `tokenizers.Tokenizer`, for the two
vocabulary families in which a token maps to a fixed byte string:

* byte level BPE (GPT-2 style), where every character of a token stands for one byte, and
* SentencePiece style BPE with byte fallback (Llama style), where a piece is either a single
  byte written as `<0xNN>` or text in which U+2581 stands for a space.
"""
import json
import re
from functools import lru_cache
from typing import Any, Dict, Optional

_BYTE_FALLBACK_PIECE = re.compile(r"^<0x([0-9a-fA-F]{2})>$")
_SENTENCEPIECE_SPACE = "▁"


@lru_cache(maxsize=1)
def byte_to_unicode() -> Dict[int, str]:
    """The byte to unicode table of byte level BPE vocabularies (GPT-2 style)."""
    printable = (list(range(ord("!"), ord("~") + 1)) + list(range(ord("¡"), ord("¬") + 1)) +
                 list(range(ord("®"), ord("ÿ") + 1)))
    bytes_ = printable[:]
    code_points = printable[:]
    extra = 0
    for byte in range(256):
        if byte not in bytes_:
            bytes_.append(byte)
            code_points.append(256 + extra)
            extra += 1
    return {byte: chr(code_point) for byte, code_point in zip(bytes_, code_points)}


@lru_cache(maxsize=1)
def unicode_to_byte() -> Dict[str, int]:
    """The inverse of `byte_to_unicode()`."""
    return {character: byte for byte, character in byte_to_unicode().items()}


def token_bytes_from_tokenizer(tokenizer) -> Dict[int, bytes]:
    """The bytes that every regular token of `tokenizer` contributes to the output.

    :param tokenizer: A `tokenizers.Tokenizer`.
    :return: A mapping from token id to bytes, for every id of the tokenizer's vocabulary
    (without added tokens) except the special added tokens.
    :raises ValueError: If the vocabulary is neither byte level BPE nor a byte fallback
    SentencePiece style vocabulary, or if a token cannot be mapped to bytes.
    """
    configuration = _tokenizer_configuration(tokenizer)
    vocabulary = tokenizer.get_vocab(with_added_tokens=False)
    special_ids = _special_token_ids(tokenizer)
    if _has_byte_level_decoder(configuration.get("decoder")):
        convert = _byte_level_piece
    elif (configuration.get("model") or {}).get("byte_fallback"):
        convert = _byte_fallback_piece
    else:
        raise ValueError(
            "token_bytes_from_tokenizer supports byte level BPE vocabularies (a ByteLevel "
            "decoder) and SentencePiece style vocabularies with byte fallback, but this "
            "tokenizer is neither")
    token_bytes = {}
    for piece, token_id in vocabulary.items():
        if token_id in special_ids:
            continue
        token_bytes[token_id] = convert(piece)
    return token_bytes


def _tokenizer_configuration(tokenizer) -> Dict[str, Any]:
    """The serialized form of the tokenizer, which describes its model and decoder."""
    try:
        return json.loads(tokenizer.to_str())
    except AttributeError as error:
        raise ValueError(f"Expected a tokenizers.Tokenizer, got {type(tokenizer)}") from error


def _special_token_ids(tokenizer) -> set:
    try:
        added_tokens = tokenizer.get_added_tokens_decoder()
    except AttributeError:
        return set()
    return set(token_id for token_id, added_token in added_tokens.items()
               if getattr(added_token, 'special', False))


def _has_byte_level_decoder(decoder: Optional[Dict[str, Any]]) -> bool:
    """Whether the decoder is a ByteLevel decoder, on its own or inside a Sequence."""
    if not decoder:
        return False
    if decoder.get("type") == "ByteLevel":
        return True
    if decoder.get("type") == "Sequence":
        return any(_has_byte_level_decoder(inner) for inner in decoder.get("decoders") or [])
    return False


def _byte_level_piece(piece: str) -> bytes:
    table = unicode_to_byte()
    try:
        return bytes(table[character] for character in piece)
    except KeyError as error:
        raise ValueError(f"The token {piece!r} is not a byte level token: {error}") from error


def _byte_fallback_piece(piece: str) -> bytes:
    match = _BYTE_FALLBACK_PIECE.match(piece)
    if match:
        return bytes((int(match.group(1), 16),))
    return piece.replace(_SENTENCEPIECE_SPACE, " ").encode("utf-8")
