"""Sets of unicode code points, and the hooks that let the existing character level parsers
be driven with an alphabet of every unicode scalar value.

Byte level token enforcement needs to know which characters a parser allows, and for
patterns such as `[^,]` or free text JSON strings that set contains over a million
characters. Materializing it as a string (the CharacterLevelParser interface) is not an
option, so the byte level code works with CharSet instead, and the few places in which the
parsers test membership of a single character delegate to `parser_accepts`, which uses the
CharSet of the parser when the byte level engine is active.
"""
from bisect import bisect_right
from typing import Callable, Iterable, Iterator, List, Optional, Tuple

MAX_CODE_POINT = 0x10FFFF
FIRST_SURROGATE = 0xD800
LAST_SURROGATE = 0xDFFF


class CharSet:
    """An immutable set of unicode code points, stored as sorted, disjoint, non adjacent ranges.

    The ranges are kept in a flat tuple of half open boundaries
    (start0, end0, start1, end1, ...), which makes membership a single bisect."""
    __slots__ = ('bounds',)

    def __init__(self, bounds: Tuple[int, ...] = ()):
        self.bounds = bounds

    @staticmethod
    def from_ranges(ranges: Iterable[Tuple[int, int]]) -> 'CharSet':
        """Create a CharSet from (first, last) inclusive code point pairs, in any order."""
        pairs = sorted((first, last) for first, last in ranges if first <= last)
        bounds = []
        for first, last in pairs:
            if bounds and first <= bounds[-1]:
                if last + 1 > bounds[-1]:
                    bounds[-1] = last + 1
            else:
                bounds.append(first)
                bounds.append(last + 1)
        return CharSet(tuple(bounds))

    @staticmethod
    def from_chars(characters: Iterable[str]) -> 'CharSet':
        """Create a CharSet from an iterable of single character strings."""
        code_points = sorted(set(ord(character) for character in characters))
        bounds = []
        for code_point in code_points:
            if bounds and code_point == bounds[-1]:
                bounds[-1] = code_point + 1
            else:
                bounds.append(code_point)
                bounds.append(code_point + 1)
        return CharSet(tuple(bounds))

    @staticmethod
    def from_code_points(code_points: Iterable[int]) -> 'CharSet':
        return CharSet.from_ranges((code_point, code_point) for code_point in code_points)

    def contains(self, code_point: int) -> bool:
        return bool(bisect_right(self.bounds, code_point) & 1)

    def intersects(self, first: int, last: int) -> bool:
        """Does the set contain any code point in the inclusive range [first, last]?"""
        bounds = self.bounds
        index = bisect_right(bounds, first)
        if index & 1:
            return True
        return index < len(bounds) and bounds[index] <= last

    def __bool__(self) -> bool:
        return bool(self.bounds)

    def __eq__(self, other) -> bool:
        return isinstance(other, CharSet) and self.bounds == other.bounds

    def __hash__(self) -> int:
        return hash(self.bounds)

    def __repr__(self) -> str:
        ranges = ", ".join(f"{hex(self.bounds[i])}-{hex(self.bounds[i + 1] - 1)}"
                           for i in range(0, len(self.bounds), 2))
        return f"CharSet({ranges})"

    def count(self) -> int:
        bounds = self.bounds
        return sum(bounds[i + 1] - bounds[i] for i in range(0, len(bounds), 2))

    def chars(self) -> Iterator[str]:
        bounds = self.bounds
        for i in range(0, len(bounds), 2):
            for code_point in range(bounds[i], bounds[i + 1]):
                yield chr(code_point)

    def __or__(self, other: 'CharSet') -> 'CharSet':
        if not self.bounds:
            return other
        if not other.bounds:
            return self
        return CharSet(_combine(self.bounds, other.bounds, 1))

    def __and__(self, other: 'CharSet') -> 'CharSet':
        if not self.bounds or not other.bounds:
            return EMPTY_CHARSET
        return CharSet(_combine(self.bounds, other.bounds, 2))

    def minus(self, other: 'CharSet') -> 'CharSet':
        if not self.bounds or not other.bounds:
            return self
        return self & other.complement()

    def complement(self) -> 'CharSet':
        """The complement within all unicode scalar values (surrogates are never included)."""
        return SCALAR_VALUES & CharSet(_complement_bounds(self.bounds))


def _complement_bounds(bounds: Tuple[int, ...]) -> Tuple[int, ...]:
    result = []
    position = 0
    for i in range(0, len(bounds), 2):
        if bounds[i] > position:
            result.append(position)
            result.append(bounds[i])
        position = bounds[i + 1]
    if position <= MAX_CODE_POINT:
        result.append(position)
        result.append(MAX_CODE_POINT + 1)
    return tuple(result)


def _combine(first: Tuple[int, ...], second: Tuple[int, ...], threshold: int) -> Tuple[int, ...]:
    """Merge two boundary tuples, keeping the code points covered by at least `threshold` of them.

    Both tuples alternate between the start and the end of a range, so the parity of an index
    says whether the boundary opens or closes a range. Walking the two tuples together with a
    counter of how many ranges are open gives the union (threshold 1) or the intersection
    (threshold 2). Boundaries that meet cancel out, which merges adjacent ranges."""
    result: List[int] = []
    index = other = 0
    size, other_size = len(first), len(second)
    depth = 0
    while index < size or other < other_size:
        if other >= other_size or (index < size and first[index] <= second[other]):
            boundary = first[index]
            opening = not index & 1
            index += 1
        else:
            boundary = second[other]
            opening = not other & 1
            other += 1
        if opening:
            depth += 1
            if depth != threshold:
                continue
        else:
            depth -= 1
            if depth != threshold - 1:
                continue
        if result and result[-1] == boundary:
            result.pop()
        else:
            result.append(boundary)
    return tuple(result)


EMPTY_CHARSET = CharSet()
SCALAR_VALUES = CharSet((0, FIRST_SURROGATE, LAST_SURROGATE + 1, MAX_CODE_POINT + 1))
"""Every unicode scalar value - the alphabet that byte level enforcement uses."""


# UTF-8 helpers. A "strict prefix" is a (possibly empty) sequence of complete characters
# followed by at most one incomplete character.

_LENGTH_RANGES = {1: (0x00, 0x7F), 2: (0x80, 0x7FF), 3: (0x800, 0xFFFF), 4: (0x10000, MAX_CODE_POINT)}


def utf8_sequence_length(lead_byte: int) -> int:
    """The total number of bytes of the character that starts with `lead_byte`, or 0 if it cannot."""
    if lead_byte < 0x80:
        return 1
    if lead_byte < 0xC2:  # continuation bytes, and the overlong leads 0xC0 / 0xC1
        return 0
    if lead_byte < 0xE0:
        return 2
    if lead_byte < 0xF0:
        return 3
    if lead_byte < 0xF5:
        return 4
    return 0


def code_point_range(prefix: bytes) -> Optional[Tuple[int, int, int]]:
    """The code points whose UTF-8 encoding starts with `prefix`.

    Returns (first, last, missing_bytes) where missing_bytes is how many bytes are still needed
    to complete the character, or None if no valid character starts with these bytes."""
    length = utf8_sequence_length(prefix[0])
    if length == 0 or len(prefix) > length:
        return None
    value = prefix[0] if length == 1 else prefix[0] & (0x7F >> length)
    for byte in prefix[1:]:
        if byte < 0x80 or byte > 0xBF:
            return None
        value = (value << 6) | (byte & 0x3F)
    missing = length - len(prefix)
    first = value << (6 * missing)
    last = first + (1 << (6 * missing)) - 1
    valid_first, valid_last = _LENGTH_RANGES[length]
    first = max(first, valid_first)
    last = min(last, valid_last)
    if first > last:
        return None
    return first, last, missing


def utf8_strict_prefix_length(data: bytes) -> Optional[int]:
    """The number of bytes of `data` that form complete characters, or None if `data` is not a
    strict UTF-8 prefix (every byte must belong to a valid, possibly incomplete, character)."""
    position = 0
    size = len(data)
    while position < size:
        length = utf8_sequence_length(data[position])
        if length == 0:
            return None
        chunk = data[position:position + length]
        if code_point_range(chunk) is None:
            return None
        if len(chunk) < length:
            return position
        position += length
    return position


# The character level parsers test whether a single character is allowed with
# `character in parser.get_allowed_characters()`. While the byte level engine is active the
# tests below are answered from the parser's CharSet instead, so that characters outside the
# configured alphabet (any multi byte character, for example) are handled correctly.

_charset_hook: Optional[Callable[[object], Optional[CharSet]]] = None
_active_depth = 0


def set_charset_hook(hook: Callable[[object], Optional[CharSet]]) -> None:
    global _charset_hook
    _charset_hook = hook


class unicode_alphabet_active:
    """Context manager that turns on the full unicode alphabet for parser membership tests."""
    def __enter__(self):
        global _active_depth
        _active_depth += 1
        return self

    def __exit__(self, *args):
        global _active_depth
        _active_depth -= 1
        return False


def is_unicode_alphabet_active() -> bool:
    return _active_depth > 0


def parser_charset(parser) -> Optional[CharSet]:
    """The CharSet of a parser, if the byte level engine is active and knows this parser type."""
    if _active_depth > 0 and _charset_hook is not None:
        return _charset_hook(parser)
    return None


def parser_accepts(parser, character: str) -> bool:
    """Whether `parser` allows `character` as its next character."""
    charset = parser_charset(parser)
    if charset is not None:
        return charset.contains(ord(character))
    return character in parser.get_allowed_characters()


def parser_allows_nothing(parser) -> bool:
    """Whether `parser` allows no characters at all."""
    charset = parser_charset(parser)
    if charset is not None:
        return not charset
    return parser.get_allowed_characters() == ''
