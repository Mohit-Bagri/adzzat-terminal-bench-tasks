"""CharSets for the states of a RegexParser's FSM.

`RegexParser.get_allowed_characters()` expands the FSM's `anything_else` symbol with the
characters of the configured alphabet. Byte level enforcement instead needs the exact set of
unicode scalar values that keep the regex on a path to a full match, so the sets are computed
from the FSM here and cached on the parser's shared context.
"""
from typing import Dict, Set

from interegular.fsm import anything_else

from .charsets import CharSet, SCALAR_VALUES


class _FsmCharSets:
    def __init__(self, fsm):
        self.fsm = fsm
        self.live_states = _live_states(fsm)
        self.state_charsets: Dict[int, CharSet] = {}
        explicit = CharSet.from_chars(symbol for symbol in fsm.alphabet.keys() if symbol != anything_else)
        self.anything_else_charset = explicit.complement()
        self.transition_charsets: Dict[int, CharSet] = {}

    def transition_charset(self, transition: int) -> CharSet:
        charset = self.transition_charsets.get(transition)
        if charset is None:
            symbols = self.fsm.alphabet.by_transition[transition]
            charset = CharSet.from_chars(symbol for symbol in symbols if symbol != anything_else)
            if any(symbol == anything_else for symbol in symbols):
                charset = charset | self.anything_else_charset
            self.transition_charsets[transition] = charset
        return charset

    def state_charset(self, state: int) -> CharSet:
        charset = self.state_charsets.get(state)
        if charset is None:
            charset = CharSet()
            for transition, target in self.fsm.map.get(state, {}).items():
                if target in self.live_states:
                    charset = charset | self.transition_charset(transition)
            charset = charset & SCALAR_VALUES
            self.state_charsets[state] = charset
        return charset


def _live_states(fsm) -> Set[int]:
    """The states from which a final state is reachable."""
    incoming: Dict[int, Set[int]] = {}
    for state, transitions in fsm.map.items():
        for target in transitions.values():
            incoming.setdefault(target, set()).add(state)
    live = set(state for state in fsm.finals if state in fsm.states)
    pending = list(live)
    while pending:
        state = pending.pop()
        for source in incoming.get(state, ()):
            if source not in live:
                live.add(source)
                pending.append(source)
    return live


def fsm_charsets(context) -> _FsmCharSets:
    """The cached CharSets of the FSM of a RegexParser context."""
    charsets = getattr(context, 'byte_level_charsets', None)
    if charsets is None:
        charsets = _FsmCharSets(context.pattern)
        context.byte_level_charsets = charsets
    return charsets


def regex_charset(parser) -> CharSet:
    """The characters that keep a RegexParser on a path to a full match."""
    if parser.current_state < 0:  # UNINITIALIZED_STATE / INVALID_STATE
        return CharSet()
    return fsm_charsets(parser.context).state_charset(parser.current_state)


def regex_can_end(parser) -> bool:
    """Whether the regex fully matches what the parser has consumed so far."""
    return parser.current_state in parser.context.pattern.finals


def regex_is_live(parser) -> bool:
    """Whether some string accepted by the regex starts with what the parser has consumed."""
    if parser.current_state < 0:
        return False
    return parser.current_state in fsm_charsets(parser.context).live_states
