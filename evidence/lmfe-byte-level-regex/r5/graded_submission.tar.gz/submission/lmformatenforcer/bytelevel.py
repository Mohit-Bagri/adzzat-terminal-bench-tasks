"""Byte level token enforcement.

`TokenEnforcer` normally matches tokens against the parsers by their decoded strings, which
cannot express the tokens of a byte level BPE vocabulary: many of them hold only a part of a
character. When `TokenEnforcerTokenizerData` is given the bytes of every token, the enforcer
uses the code in this module instead, which walks a trie of the token bytes while feeding
complete characters to the parser, and keeps the bytes of an incomplete character pending until
a later token completes it.

A token is allowed exactly when the bytes generated so far, plus the bytes of the token, are a
strict UTF-8 prefix of a string that the parser accepts.
"""
import enum
import sys
from typing import Dict, Hashable, List, Optional, Sequence, Set, Tuple

from .charsets import (CharSet, EMPTY_CHARSET, SCALAR_VALUES, code_point_range,
                       set_charset_hook, utf8_sequence_length)
from .characterlevelparser import (CharacterLevelParser, ForceStopParser, SequenceParser,
                                   StringParser, UnionParser)
from .consts import BACKSLASH, WHITESPACE_CHARACTERS
from .external.jsonschemaobject import JsonSchemaObject
from .jsonschemaparser import (JsonSchemaParser, ListParsingState, NumberParsingState,
                               ObjectParsingState, StringParsingState)
from .jsonstringvalue import JsonStringValue
from .regexcharsets import regex_can_end, regex_charset
from .regexparser import RegexParser

_WHITESPACE = CharSet.from_chars(WHITESPACE_CHARACTERS)
_QUOTE = CharSet.from_chars('"')
_QUOTE_AND_WHITESPACE = CharSet.from_chars('"' + WHITESPACE_CHARACTERS)
_QUOTE_AND_BACKSLASH = CharSet.from_chars('"' + BACKSLASH)


# --------------------------------------------------------------------------------------
# The characters a parser allows, with every unicode scalar value as the alphabet.
# --------------------------------------------------------------------------------------

def charset_of(parser) -> CharSet:
    """The set of characters that `parser` allows next, with the full unicode alphabet.

    Only characters that keep the parser on a path to an accepting state are included, so that
    a token that ends inside a character is allowed exactly when some character that starts with
    its last bytes is allowed."""
    parser_class = parser.__class__
    handler = _HANDLERS.get(parser_class)
    if handler is None:
        handler = _resolve_handler(parser_class)
    return handler(parser)


def _resolve_handler(parser_class):
    for base in parser_class.__mro__:
        handler = _HANDLERS.get(base)
        if handler is not None:
            _HANDLERS[parser_class] = handler
            return handler
    _HANDLERS[parser_class] = _allowed_characters_charset
    return _allowed_characters_charset


def _allowed_characters_charset(parser) -> CharSet:
    """Fallback for parsers whose allowed characters are a plain (finite) string."""
    return CharSet.from_chars(parser.get_allowed_characters()) & SCALAR_VALUES


def _union_charset(parser: UnionParser) -> CharSet:
    charset = EMPTY_CHARSET
    for option in parser.parsers:
        charset = charset | charset_of(option)
    return charset


def _sequence_charset(parser: SequenceParser) -> CharSet:
    charset = EMPTY_CHARSET
    for option in parser.parsers:
        charset = charset | charset_of(option)
        if not option.can_end():
            break
    return charset


def _string_parser_charset(parser: StringParser) -> CharSet:
    return CharSet.from_chars(parser.target_str[:1])


def _force_stop_charset(parser: ForceStopParser) -> CharSet:
    return _WHITESPACE if parser.allow_whitespace else EMPTY_CHARSET


def _json_schema_charset(parser: JsonSchemaParser) -> CharSet:
    # Mirrors JsonSchemaParser.get_allowed_characters(), including its active parser bookkeeping.
    parser.context.active_parser = parser
    charset = EMPTY_CHARSET
    inside_string_value = EMPTY_CHARSET
    for state in reversed(parser.object_stack):
        # The characters of a JSON string value are the ones the value itself allows - the limit
        # on consecutive whitespaces applies to the structure around it, not inside it.
        structure, in_value = _split_string_value_charset(state)
        charset = charset | structure
        inside_string_value = inside_string_value | in_value
        if not state.can_end():
            break
    if not parser.object_stack:
        # The parser is done, but whitespace is still accepted (as in the character level parser).
        charset = _WHITESPACE
    if parser.num_consecutive_whitespaces >= parser.config.max_consecutive_whitespaces:
        charset = charset.minus(_WHITESPACE)
    return charset | inside_string_value


def _split_string_value_charset(state) -> Tuple[CharSet, CharSet]:
    """The characters `state` allows, split into the ones that belong to the structure and the
    ones that are inside a JSON string value."""
    if _is_open_string_value(state):
        return EMPTY_CHARSET, _string_state_charset(state)
    state_class = state.__class__
    if state_class is UnionParser or state_class is SequenceParser:
        structure = EMPTY_CHARSET
        in_value = EMPTY_CHARSET
        for option in state.parsers:
            option_structure, option_in_value = _split_string_value_charset(option)
            structure = structure | option_structure
            in_value = in_value | option_in_value
            if state_class is SequenceParser and not option.can_end():
                break
        return structure, in_value
    return charset_of(state), EMPTY_CHARSET


def _is_open_string_value(state) -> bool:
    """Whether `state` is a JSON string value that is being written right now."""
    return (state.__class__ is StringParsingState and state.value_state is not None
            and state.seen_opening_quote and not state.seen_closing_quote)


def _string_state_charset(parser: StringParsingState) -> CharSet:
    if not parser.seen_opening_quote:
        return _QUOTE_AND_WHITESPACE
    if parser.seen_closing_quote:
        return _WHITESPACE
    value_state = parser.value_state
    if value_state is not None:
        return value_state.input_charset()
    if parser.regex_parser is not None:
        # Quotes and backslashes are not supported inside a pattern, as in the character level parser.
        charset = regex_charset(parser.regex_parser).minus(_QUOTE_AND_BACKSLASH)
        if regex_can_end(parser.regex_parser):
            charset = charset | _QUOTE
        return charset
    if parser.allowed_strings:
        return CharSet.from_chars(parser.get_allowed_characters())
    # Free text: the alphabet is every unicode scalar value, and a backslash is always allowed.
    if parser.min_length is not None and len(parser.parsed_string) < parser.min_length:
        return SCALAR_VALUES.minus(_QUOTE)
    if parser.max_length is not None and len(parser.parsed_string) >= parser.max_length:
        return _QUOTE
    return SCALAR_VALUES


_HANDLERS = {
    RegexParser: regex_charset,
    UnionParser: _union_charset,
    SequenceParser: _sequence_charset,
    StringParser: _string_parser_charset,
    ForceStopParser: _force_stop_charset,
    JsonSchemaParser: _json_schema_charset,
    StringParsingState: _string_state_charset,
    ObjectParsingState: _allowed_characters_charset,
    NumberParsingState: _allowed_characters_charset,
    ListParsingState: _allowed_characters_charset,
    CharacterLevelParser: _allowed_characters_charset,
}

set_charset_hook(charset_of)


# --------------------------------------------------------------------------------------
# Keys that identify a parser state, so that token lists can be reused.
# --------------------------------------------------------------------------------------

NO_KEY = object()
"""Returned when a parser state cannot be identified, which disables caching for it."""

_pinned_objects: Dict[int, object] = {}


def _identity(value) -> int:
    """A stable id for an object that is not hashable (a schema, for example)."""
    key = id(value)
    if key not in _pinned_objects:
        _pinned_objects[key] = value  # Keep a reference, so that the id stays unique
    return key


def state_key(parser) -> Hashable:
    """A hashable value that fully determines the future behaviour of a parser state."""
    parser_class = parser.__class__
    if parser_class is RegexParser:
        return ('regex', parser.context, parser.current_state)
    if parser_class is JsonSchemaParser:
        stack = _sequence_key(parser.object_stack)
        if stack is NO_KEY:
            return NO_KEY
        return ('json', parser.context, stack, parser.num_consecutive_whitespaces,
                parser.last_parsed_string, parser.last_non_whitespace_character)
    if parser_class is UnionParser or parser_class is SequenceParser:
        options = _sequence_key(parser.parsers)
        if options is NO_KEY:
            return NO_KEY
        return ('union' if parser_class is UnionParser else 'sequence', options)
    if parser_class is StringParser:
        return ('literal', parser.target_str)
    if parser_class is ForceStopParser:
        return ('stop', parser.allow_whitespace)
    if isinstance(parser, CharacterLevelParser):
        fields = []
        for name in sorted(parser.__dict__):
            if name == 'root':  # A back pointer to the JsonSchemaParser, not part of the state
                continue
            value = _value_key(parser.__dict__[name])
            if value is NO_KEY:
                return NO_KEY
            fields.append((name, value))
        return (parser_class.__name__, tuple(fields))
    return NO_KEY


def _sequence_key(values: Sequence) -> Hashable:
    keys = []
    for value in values:
        key = state_key(value)
        if key is NO_KEY:
            return NO_KEY
        keys.append(key)
    return tuple(keys)


def _value_key(value) -> Hashable:
    if value is None or isinstance(value, (bool, int, float, str, bytes)):
        return value
    if isinstance(value, (list, tuple)):
        keys = []
        for item in value:
            key = _value_key(item)
            if key is NO_KEY:
                return NO_KEY
            keys.append(key)
        return tuple(keys)
    if isinstance(value, (set, frozenset)):
        keys = []
        for item in value:
            key = _value_key(item)
            if key is NO_KEY:
                return NO_KEY
            keys.append(key)
        return ('set', frozenset(keys))
    if isinstance(value, CharacterLevelParser):
        return state_key(value)
    if isinstance(value, JsonStringValue):
        return ('value', value.key())
    if isinstance(value, enum.Enum):
        return ('enum', value.__class__.__name__, value.name)
    if isinstance(value, JsonSchemaObject):
        return ('schema', _identity(value))
    return NO_KEY


# --------------------------------------------------------------------------------------
# Per tokenizer byte level data.
# --------------------------------------------------------------------------------------

class ByteTrieNode:
    """A node of the trie of token byte strings.

    Besides the tokens that end here, a node knows how its subtree looks to the free text
    shortcut: `characters` is the number of characters the node's byte string adds to a JSON
    string value (-1 if it cannot be plain text in one, 0 if no token ends here), and the two
    subtree fields summarize the same information for everything below, which lets the walk
    skip the tokens that the shortcut has already answered."""
    __slots__ = ('tokens', 'children', 'characters', 'subtree_other', 'subtree_max_plain')

    def __init__(self):
        self.tokens: List[int] = []
        self.children: Dict[int, 'ByteTrieNode'] = {}
        self.characters: int = 0
        self.subtree_other: bool = False
        self.subtree_max_plain: int = 0

    def add(self, token_bytes: bytes, token_id: int, characters: int) -> None:
        node = self
        for byte in token_bytes:
            child = node.children.get(byte)
            if child is None:
                child = ByteTrieNode()
                node.children[byte] = child
            node = child
        node.tokens.append(token_id)
        node.characters = characters

    def summarize(self) -> None:
        """Fill in the subtree fields of every node, deepest first."""
        order = [self]
        index = 0
        while index < len(order):
            order.extend(order[index].children.values())
            index += 1
        for node in reversed(order):
            other = node.characters < 0
            max_plain = node.characters if node.characters > 0 else 0
            for child in node.children.values():
                other = other or child.subtree_other
                if child.subtree_max_plain > max_plain:
                    max_plain = child.subtree_max_plain
            node.subtree_other = other
            node.subtree_max_plain = max_plain


_NOT_PLAIN_BYTES = bytes(range(0x20)) + b'"' + b'\\'


def plain_text_character_count(token_bytes: bytes) -> Optional[int]:
    """How many characters a token adds to a JSON string value, counting an incomplete trailing
    character as one, or None if the token cannot be written inside a string value as it is
    (because it is not valid UTF-8 from a character boundary, or contains a quote, a backslash
    or a control character)."""
    size = len(token_bytes)
    if not size:
        return None
    if len(token_bytes.translate(None, _NOT_PLAIN_BYTES)) != size:
        return None
    if max(token_bytes) < 0x80:
        return size
    position = 0
    characters = 0
    while position < size:
        length = utf8_sequence_length(token_bytes[position])
        if length == 0:
            return None
        if code_point_range(token_bytes[position:position + length]) is None:
            return None
        characters += 1
        position += length
    return characters


class TokenByteData:
    """The byte strings of every regular token, arranged for byte level enforcement."""

    def __init__(self, token_bytes: Dict[int, bytes]):
        self.token_bytes = token_bytes
        self.root = ByteTrieNode()
        # Tokens that are plain text inside a JSON string value are also looked up by the number
        # of characters they add, so that a free text value does not need a trie walk at all.
        self.text_tokens_by_length: Dict[int, List[int]] = {}
        self.max_text_characters = 0
        for token_id, data in token_bytes.items():
            characters = plain_text_character_count(data)
            self.root.add(data, token_id, -1 if characters is None else characters)
            if characters is not None:
                self.text_tokens_by_length.setdefault(characters, []).append(token_id)
                if characters > self.max_text_characters:
                    self.max_text_characters = characters
        self.root.summarize()
        self._text_tokens_up_to: Dict[int, List[int]] = {}
        # The trie is walked recursively, one or two frames per byte of a token.
        longest_token = max((len(data) for data in token_bytes.values()), default=0)
        needed_depth = 4 * longest_token + 200
        if sys.getrecursionlimit() < needed_depth:
            sys.setrecursionlimit(needed_depth)

    def skip_text_tokens_up_to(self, max_characters: Optional[int]) -> int:
        """The `skip` argument of the trie walk that matches `text_tokens_up_to`."""
        if max_characters is None or max_characters > self.max_text_characters:
            return self.max_text_characters
        return max(0, max_characters)

    def text_tokens_up_to(self, max_characters: Optional[int]) -> List[int]:
        """The tokens that are plain text inside a JSON string value and add at most
        `max_characters` characters to it (all of them if `max_characters` is None)."""
        if max_characters is None or max_characters > self.max_text_characters:
            max_characters = self.max_text_characters
        if max_characters <= 0:
            return []
        tokens = self._text_tokens_up_to.get(max_characters)
        if tokens is None:
            tokens = []
            for length in range(1, max_characters + 1):
                tokens.extend(self.text_tokens_by_length.get(length, ()))
            tokens.sort()
            self._text_tokens_up_to[max_characters] = tokens
        return tokens


# --------------------------------------------------------------------------------------
# The allowed tokens of a parser state.
# --------------------------------------------------------------------------------------

class ByteLevelTokenCollector:
    """Collects the tokens that a parser state allows, caching the result per state."""

    CACHED_TOKENS_LIMIT = 4000000
    """How many token ids to keep in the cache of token lists, before dropping all of them"""
    REGEX_TRANSITIONS_LIMIT = 200000
    """How many regex transitions to remember, before dropping all of them"""

    def __init__(self, data: TokenByteData):
        self.data = data
        self.cache: Dict[Hashable, List[int]] = {}
        self.cached_tokens = 0
        # A regex state reacts to a character with nothing but a table lookup, and the trie
        # visits the same (state, character) pair once per path that reaches it.
        self.regex_transitions: Dict[Tuple, Tuple[CharacterLevelParser, CharSet]] = {}

    def allowed_tokens(self, parser: CharacterLevelParser, pending_bytes: bytes) -> List[int]:
        key = state_key(parser)
        if key is NO_KEY:
            return self._collect(parser, pending_bytes)
        cache_key = (key, pending_bytes)
        tokens = self.cache.get(cache_key)
        if tokens is None:
            tokens = self._collect(parser, pending_bytes)
            if self.cached_tokens > self.CACHED_TOKENS_LIMIT:
                self.cache.clear()
                self.cached_tokens = 0
            self.cache[cache_key] = tokens
            self.cached_tokens += len(tokens)
        return tokens

    def _collect(self, parser: CharacterLevelParser, pending_bytes: bytes) -> List[int]:
        if parser.__class__ is UnionParser:
            # The language of a union is the union of the languages of its options.
            merged: Set[int] = set()
            for option in parser.parsers:
                merged.update(self.allowed_tokens(option, pending_bytes))
            return sorted(merged)
        charset = charset_of(parser)
        root = self.data.root
        tokens: List[int] = list(root.tokens)
        if pending_bytes:
            self._walk_incomplete_character(root, parser, charset, pending_bytes, tokens, 0)
            tokens.sort()
            return tokens
        remaining = _free_text_characters_left(parser)
        if remaining is _NOT_FREE_TEXT:
            self._walk(root, parser, charset, tokens, 0)
        else:
            # A free text JSON string value accepts every character, so whether a plain text
            # token is allowed only depends on how many characters the value may still contain.
            # The walk then only has to look at the tokens that the lists do not cover.
            tokens.extend(self.data.text_tokens_up_to(remaining))
            self._walk(root, parser, charset, tokens, self.data.skip_text_tokens_up_to(remaining))
        tokens.sort()
        return tokens

    def _walk(self, node: ByteTrieNode, parser: CharacterLevelParser, charset: CharSet,
              tokens: List[int], skip: int) -> None:
        """Explore `node` with the parser at a character boundary.

        `skip` is how many characters a plain text token may add to a JSON string value and
        still be covered by the precalculated token lists; such tokens, and the subtrees that
        hold nothing else, are left out here."""
        for byte, child in node.children.items():
            if skip and not child.subtree_other and child.subtree_max_plain <= skip:
                continue
            if byte < 0x80:
                if charset.contains(byte):
                    self._add_character(child, parser, chr(byte), tokens, skip)
                continue
            span = code_point_range(bytes((byte,)))
            if span is None:
                continue
            first, last, _ = span
            if not charset.intersects(first, last):
                continue
            if child.tokens and (not skip or child.characters < 0 or child.characters > skip):
                tokens.extend(child.tokens)
            self._walk_incomplete_character(child, parser, charset, bytes((byte,)), tokens, skip)

    def _walk_incomplete_character(self, node: ByteTrieNode, parser: CharacterLevelParser,
                                   charset: CharSet, prefix: bytes, tokens: List[int],
                                   skip: int) -> None:
        """Explore `node` with the bytes of an incomplete character pending."""
        for byte, child in node.children.items():
            if byte < 0x80 or byte > 0xBF:
                continue
            if skip and not child.subtree_other and child.subtree_max_plain <= skip:
                continue
            extended = prefix + bytes((byte,))
            span = code_point_range(extended)
            if span is None:
                continue
            first, last, missing = span
            if missing == 0:
                if charset.contains(first):
                    self._add_character(child, parser, chr(first), tokens, skip)
                continue
            if not charset.intersects(first, last):
                continue
            if child.tokens and (not skip or child.characters < 0 or child.characters > skip):
                tokens.extend(child.tokens)
            self._walk_incomplete_character(child, parser, charset, extended, tokens, skip)

    def _add_character(self, node: ByteTrieNode, parser: CharacterLevelParser, character: str,
                       tokens: List[int], skip: int) -> None:
        if parser.__class__ is RegexParser:
            transition_key = (parser.context, parser.current_state, character)
            transition = self.regex_transitions.get(transition_key)
            if transition is None:
                next_parser = parser.add_character(character)
                transition = (next_parser, charset_of(next_parser))
                if len(self.regex_transitions) > self.REGEX_TRANSITIONS_LIMIT:
                    self.regex_transitions.clear()
                self.regex_transitions[transition_key] = transition
            next_parser, next_charset = transition
        else:
            next_parser = parser.add_character(character)
            next_charset = charset_of(next_parser)
        if not next_charset.bounds and not next_parser.can_end():
            return  # The character leads to a state that can neither continue nor end
        if node.tokens and (not skip or node.characters < 0 or node.characters > skip):
            tokens.extend(node.tokens)
        if next_charset.bounds and node.children:
            self._walk(node, next_parser, next_charset, tokens, skip)


_NOT_FREE_TEXT = object()


def _free_text_characters_left(parser: CharacterLevelParser):
    """How many characters may still be written into a free text JSON string value that is
    open right now (None if unlimited), or `_NOT_FREE_TEXT` if there is none.

    Such a value accepts every character, so every plain text token that is short enough is
    allowed, whatever else the parser would accept."""
    parser_class = parser.__class__
    if parser_class is JsonSchemaParser:
        if not parser.object_stack:
            return _NOT_FREE_TEXT
        return _free_text_capacity(parser.object_stack[-1])
    if parser_class is SequenceParser:
        return _free_text_characters_left(parser.parsers[0])
    return _NOT_FREE_TEXT


def _free_text_capacity(state: CharacterLevelParser):
    if _is_open_string_value(state):
        value_state = state.value_state
        if value_state.is_unconstrained_text() and state.require_closing_quote:
            return value_state.constraint.remaining_characters()
        return _NOT_FREE_TEXT
    if state.__class__ is UnionParser:
        capacity = _NOT_FREE_TEXT
        for option in state.parsers:
            option_capacity = _free_text_capacity(option)
            if option_capacity is _NOT_FREE_TEXT:
                continue
            if option_capacity is None:
                return None
            capacity = option_capacity if capacity is _NOT_FREE_TEXT else max(capacity, option_capacity)
        return capacity
    return _NOT_FREE_TEXT
