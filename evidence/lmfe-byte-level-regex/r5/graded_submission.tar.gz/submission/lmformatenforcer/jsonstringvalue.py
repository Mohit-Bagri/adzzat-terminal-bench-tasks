"""JSON string values, parsed according to RFC 8259 with the schema constraints applied to the
decoded value.

The character level `StringParsingState` treats the characters between the quotes as the value
itself, which is not enough for byte level enforcement: `"\\u6771\\u4eac"` and `"東京"` are the
same value 東京, and a schema that allows 東京 has to allow both spellings (and no other). This
module implements the escape sequences of JSON strings, and tracks which decoded values are
still reachable, so that a character is allowed exactly when some completion of the value
satisfies the constraints of the schema.
"""
from typing import Dict, Hashable, Optional, Sequence, Tuple

from .charsets import CharSet, SCALAR_VALUES, FIRST_SURROGATE, LAST_SURROGATE
from .consts import BACKSLASH, BACKSLASH_ESCAPING_CHARACTERS
from .regexcharsets import regex_can_end, regex_charset

FIRST_HIGH_SURROGATE = 0xD800
LAST_HIGH_SURROGATE = 0xDBFF
FIRST_LOW_SURROGATE = 0xDC00
LAST_LOW_SURROGATE = 0xDFFF

CONTROL_CHARACTERS = CharSet.from_ranges([(0x00, 0x1F)])
RAW_CHARACTERS = SCALAR_VALUES.minus(CharSet.from_chars('"' + BACKSLASH)).minus(CONTROL_CHARACTERS)
"""The characters that may appear between the quotes of a JSON string without an escape."""

_SHORT_ESCAPES = {'"': '"', BACKSLASH: BACKSLASH, '/': '/',
                  'b': '\b', 'f': '\f', 'n': '\n', 'r': '\r', 't': '\t'}
assert set(_SHORT_ESCAPES) == set(BACKSLASH_ESCAPING_CHARACTERS)

_HEX_DIGIT_CHARACTERS = [CharSet.from_chars("0123456789abcdef"[digit] + "0123456789ABCDEF"[digit])
                         for digit in range(16)]
_QUOTE = CharSet.from_chars('"')
_BACKSLASH = CharSet.from_chars(BACKSLASH)
_UNICODE_ESCAPE_MARKER = CharSet.from_chars('u')


class StringValueConstraint:
    """What a schema allows the decoded value of a string to be."""

    def allowed_characters(self) -> CharSet:
        """The characters that may be appended to the decoded value."""
        raise NotImplementedError()

    def can_end(self) -> bool:
        """Whether the decoded value is complete."""
        raise NotImplementedError()

    def add_character(self, character: str) -> 'StringValueConstraint':
        raise NotImplementedError()

    def key(self) -> Hashable:
        raise NotImplementedError()


class DeadValue(StringValueConstraint):
    """A value that no completion can satisfy."""

    def allowed_characters(self) -> CharSet:
        return CharSet()

    def can_end(self) -> bool:
        return False

    def add_character(self, character: str) -> StringValueConstraint:
        return self

    def key(self) -> Hashable:
        return ('dead',)


DEAD_VALUE = DeadValue()


class FreeTextValue(StringValueConstraint):
    """Any text, optionally limited by minLength / maxLength (in decoded characters)."""

    def __init__(self, min_length: Optional[int], max_length: Optional[int], length: int = 0):
        self.min_length = min_length
        self.max_length = max_length
        self.length = length

    def allowed_characters(self) -> CharSet:
        if self.max_length is not None and self.length >= self.max_length:
            return CharSet()
        return SCALAR_VALUES

    def can_end(self) -> bool:
        return self.min_length is None or self.length >= self.min_length

    def add_character(self, character: str) -> StringValueConstraint:
        if self.max_length is not None and self.length >= self.max_length:
            return DEAD_VALUE
        return FreeTextValue(self.min_length, self.max_length, self.length + 1)

    def remaining_characters(self) -> Optional[int]:
        """How many more characters the value may contain, or None if unlimited."""
        if self.max_length is None:
            return None
        return max(0, self.max_length - self.length)

    def key(self) -> Hashable:
        missing = 0 if self.min_length is None else max(0, self.min_length - self.length)
        remaining = -1 if self.max_length is None else max(0, self.max_length - self.length)
        return ('free', missing, remaining)


class EnumValue(StringValueConstraint):
    """One of a list of values (`enum` or `const`)."""

    def __init__(self, suffixes: Tuple[str, ...]):
        self.suffixes = suffixes

    @staticmethod
    def create(values: Sequence[str], min_length: Optional[int], max_length: Optional[int]) -> StringValueConstraint:
        suffixes = tuple(sorted(set(
            value for value in values
            if isinstance(value, str)
            and (min_length is None or len(value) >= min_length)
            and (max_length is None or len(value) <= max_length))))
        if not suffixes:
            return DEAD_VALUE
        return EnumValue(suffixes)

    def allowed_characters(self) -> CharSet:
        return CharSet.from_chars(suffix[0] for suffix in self.suffixes if suffix)

    def can_end(self) -> bool:
        return any(not suffix for suffix in self.suffixes)

    def add_character(self, character: str) -> StringValueConstraint:
        suffixes = tuple(suffix[1:] for suffix in self.suffixes if suffix[:1] == character)
        if not suffixes:
            return DEAD_VALUE
        return EnumValue(suffixes)

    def key(self) -> Hashable:
        return ('enum', self.suffixes)


class PatternValue(StringValueConstraint):
    """A value that has to fully match a regular expression."""

    def __init__(self, regex_parser):
        self.regex_parser = regex_parser

    def allowed_characters(self) -> CharSet:
        return regex_charset(self.regex_parser)

    def can_end(self) -> bool:
        return regex_can_end(self.regex_parser)

    def add_character(self, character: str) -> StringValueConstraint:
        return PatternValue(self.regex_parser.add_character(character))

    def key(self) -> Hashable:
        return ('pattern', self.regex_parser.context, self.regex_parser.current_state)


_INPUT_CHARSET_CACHE: Dict[Hashable, 'CharSet'] = {}
_INPUT_CHARSET_CACHE_LIMIT = 100000


# Stages of the escape sequence state machine.
_RAW = 0                  # between the quotes, outside any escape
_AFTER_BACKSLASH = 1      # a backslash was seen
_UNICODE_HEX = 2          # inside the four hex digits of a \u escape
_SURROGATE_BACKSLASH = 3  # a high surrogate escape was seen, its low surrogate must follow
_SURROGATE_MARKER = 4     # the backslash of the low surrogate escape was seen
_SURROGATE_HEX = 5        # inside the four hex digits of the low surrogate escape


class JsonStringValue:
    """The state of a JSON string value: how much of the decoded value was parsed, and how much
    of an escape sequence is pending."""
    __slots__ = ('constraint', 'stage', 'digits', 'digit_value', 'high_surrogate')

    def __init__(self, constraint: StringValueConstraint, stage: int = _RAW,
                 digits: int = 0, digit_value: int = 0, high_surrogate: int = 0):
        self.constraint = constraint
        self.stage = stage
        self.digits = digits
        self.digit_value = digit_value
        self.high_surrogate = high_surrogate

    @staticmethod
    def create(allowed_strings: Optional[Sequence[str]], min_length: Optional[int],
               max_length: Optional[int], regex_parser) -> 'JsonStringValue':
        if regex_parser is not None:
            constraint: StringValueConstraint = PatternValue(regex_parser)
        elif allowed_strings:
            constraint = EnumValue.create(allowed_strings, min_length, max_length)
        else:
            constraint = FreeTextValue(min_length, max_length)
        return JsonStringValue(constraint)

    def is_unconstrained_text(self) -> bool:
        """Whether the value is free text in its initial escape state, which lets the token
        enforcer use its precalculated token lists."""
        return self.stage == _RAW and isinstance(self.constraint, FreeTextValue)

    def input_charset(self) -> CharSet:
        """The characters allowed next, including the closing quote if the value may end.

        The byte level engine asks for this once per node of the token trie, so the result is
        cached by the state key."""
        key = self.key()
        charset = _INPUT_CHARSET_CACHE.get(key)
        if charset is None:
            charset = self.allowed_characters()
            if self.can_close():
                charset = charset | _QUOTE
            if len(_INPUT_CHARSET_CACHE) > _INPUT_CHARSET_CACHE_LIMIT:
                _INPUT_CHARSET_CACHE.clear()
            _INPUT_CHARSET_CACHE[key] = charset
        return charset

    def is_outside_escape(self) -> bool:
        """Whether the next character starts a new raw character, escape or the closing quote."""
        return self.stage == _RAW

    def can_close(self) -> bool:
        """Whether the closing quote may be written now."""
        return self.stage == _RAW and self.constraint.can_end()

    def allowed_characters(self) -> CharSet:
        """The characters allowed next, not counting the closing quote."""
        stage = self.stage
        allowed = self.constraint.allowed_characters()
        if stage == _RAW:
            charset = allowed & RAW_CHARACTERS
            if allowed:
                # Any character can be written as an escape sequence.
                charset = charset | _BACKSLASH
            return charset
        if stage == _AFTER_BACKSLASH:
            charset = CharSet.from_chars(
                character for character, decoded in _SHORT_ESCAPES.items()
                if allowed.contains(ord(decoded)))
            if allowed:
                charset = charset | _UNICODE_ESCAPE_MARKER
            return charset
        if stage == _UNICODE_HEX:
            return self._allowed_hex_digits(allowed, False)
        if stage == _SURROGATE_BACKSLASH:
            return _BACKSLASH if self._surrogate_pair_possible(allowed) else CharSet()
        if stage == _SURROGATE_MARKER:
            return _UNICODE_ESCAPE_MARKER if self._surrogate_pair_possible(allowed) else CharSet()
        return self._allowed_hex_digits(allowed, True)

    def _surrogate_pair_possible(self, allowed: CharSet) -> bool:
        base = _supplementary_base(self.high_surrogate)
        return allowed.intersects(base, base + 0x3FF)

    def _allowed_hex_digits(self, allowed: CharSet, low_surrogate: bool) -> CharSet:
        shift = 4 * (3 - self.digits)
        span = (1 << shift) - 1
        charset = CharSet()
        for digit in range(16):
            first = ((self.digit_value << 4) | digit) << shift
            last = first + span
            if low_surrogate:
                usable = _low_surrogate_usable(allowed, self.high_surrogate, first, last)
            else:
                usable = _code_unit_usable(allowed, first, last)
            if usable:
                charset = charset | _HEX_DIGIT_CHARACTERS[digit]
        return charset

    def add_character(self, character: str) -> 'JsonStringValue':
        stage = self.stage
        if stage == _RAW:
            if character == BACKSLASH:
                return JsonStringValue(self.constraint, _AFTER_BACKSLASH)
            return JsonStringValue(self.constraint.add_character(character))
        if stage == _AFTER_BACKSLASH:
            if character == 'u':
                return JsonStringValue(self.constraint, _UNICODE_HEX)
            decoded = _SHORT_ESCAPES.get(character)
            if decoded is None:
                return JsonStringValue(DEAD_VALUE)
            return JsonStringValue(self.constraint.add_character(decoded))
        if stage == _SURROGATE_BACKSLASH:
            if character != BACKSLASH:
                return JsonStringValue(DEAD_VALUE)
            return JsonStringValue(self.constraint, _SURROGATE_MARKER, high_surrogate=self.high_surrogate)
        if stage == _SURROGATE_MARKER:
            if character != 'u':
                return JsonStringValue(DEAD_VALUE)
            return JsonStringValue(self.constraint, _SURROGATE_HEX, high_surrogate=self.high_surrogate)
        # Inside the hex digits of a \u escape.
        digit = _hex_value(character)
        if digit is None:
            return JsonStringValue(DEAD_VALUE)
        value = (self.digit_value << 4) | digit
        digits = self.digits + 1
        if digits < 4:
            return JsonStringValue(self.constraint, stage, digits, value, self.high_surrogate)
        if stage == _SURROGATE_HEX:
            if not FIRST_LOW_SURROGATE <= value <= LAST_LOW_SURROGATE:
                return JsonStringValue(DEAD_VALUE)
            code_point = _supplementary_base(self.high_surrogate) + (value - FIRST_LOW_SURROGATE)
            return JsonStringValue(self.constraint.add_character(chr(code_point)))
        if FIRST_HIGH_SURROGATE <= value <= LAST_HIGH_SURROGATE:
            return JsonStringValue(self.constraint, _SURROGATE_BACKSLASH, high_surrogate=value)
        if FIRST_LOW_SURROGATE <= value <= LAST_LOW_SURROGATE:
            return JsonStringValue(DEAD_VALUE)  # an unpaired low surrogate
        return JsonStringValue(self.constraint.add_character(chr(value)))

    def key(self) -> Hashable:
        return (self.stage, self.digits, self.digit_value, self.high_surrogate, self.constraint.key())


def _supplementary_base(high_surrogate: int) -> int:
    return 0x10000 + ((high_surrogate - FIRST_HIGH_SURROGATE) << 10)


def _code_unit_usable(allowed: CharSet, first: int, last: int) -> bool:
    """Whether a \\u escape whose code unit is in [first, last] can produce an allowed character."""
    if first <= FIRST_SURROGATE - 1 and allowed.intersects(first, min(last, FIRST_SURROGATE - 1)):
        return True
    if last >= LAST_SURROGATE + 1 and allowed.intersects(max(first, LAST_SURROGATE + 1), last):
        return True
    high_first = max(first, FIRST_HIGH_SURROGATE)
    high_last = min(last, LAST_HIGH_SURROGATE)
    if high_first <= high_last:
        # A high surrogate escape has to be followed by a low surrogate escape, and together they
        # can spell any of the supplementary characters of these high surrogates.
        if allowed.intersects(_supplementary_base(high_first), _supplementary_base(high_last) + 0x3FF):
            return True
    return False


def _low_surrogate_usable(allowed: CharSet, high_surrogate: int, first: int, last: int) -> bool:
    low_first = max(first, FIRST_LOW_SURROGATE)
    low_last = min(last, LAST_LOW_SURROGATE)
    if low_first > low_last:
        return False
    base = _supplementary_base(high_surrogate)
    return allowed.intersects(base + (low_first - FIRST_LOW_SURROGATE),
                              base + (low_last - FIRST_LOW_SURROGATE))


def _hex_value(character: str) -> Optional[int]:
    code_point = ord(character)
    if 0x30 <= code_point <= 0x39:
        return code_point - 0x30
    if 0x61 <= code_point <= 0x66:
        return code_point - 0x61 + 10
    if 0x41 <= code_point <= 0x46:
        return code_point - 0x41 + 10
    return None
