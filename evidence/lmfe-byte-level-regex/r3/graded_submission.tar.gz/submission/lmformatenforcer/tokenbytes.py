"""The exact bytes that every token of a tokenizer contributes to the output.

`TokenEnforcerTokenizerData` takes these as `token_bytes`, which is what makes the allowed
token masks exact for constraints over characters that no single token holds. Two families
of vocabularies are supported:

* byte level BPE (GPT-2 style), where each character of a token maps to one byte through
  the byte to unicode table, and
* SentencePiece style BPE with byte fallback (Llama style), where a `<0xNN>` piece is that
  single byte and any other piece is its UTF-8, with U+2581 standing for a space.
"""
import json
import re
from functools import lru_cache
from typing import Any, Dict, List, Set

SENTENCEPIECE_SPACE = '▁'
_BYTE_FALLBACK_PIECE = re.compile(r'^<0x([0-9A-Fa-f]{2})>$')


@lru_cache(maxsize=1)
def byte_level_decoder() -> Dict[str, int]:
    """The inverse of the byte to unicode table that byte level BPE vocabularies use."""
    printable = (list(range(ord("!"), ord("~") + 1)) + list(range(ord("¡"), ord("¬") + 1)) +
                 list(range(ord("®"), ord("ÿ") + 1)))
    codes = printable[:]
    extra = 0
    for byte in range(256):
        if byte not in printable:
            printable.append(byte)
            codes.append(256 + extra)
            extra += 1
    return {chr(code): byte for byte, code in zip(printable, codes)}


def _tokenizer_spec(tokenizer) -> Dict[str, Any]:
    """The tokenizer.json content of a `tokenizers.Tokenizer`, or an empty spec."""
    try:
        return json.loads(tokenizer.to_str())
    except Exception:
        return {}


def _decoder_names(tokenizer, spec: Dict[str, Any]) -> List[str]:
    """The decoder type names of the tokenizer, flattening a Sequence of decoders."""
    decoder = spec.get('decoder')
    if isinstance(decoder, dict):
        if decoder.get('type') == 'Sequence':
            return [step.get('type') for step in decoder.get('decoders') or [] if isinstance(step, dict)]
        return [decoder.get('type')]
    decoder_object = getattr(tokenizer, 'decoder', None)
    if decoder_object is None:
        return []
    return [type(decoder_object).__name__]


def _special_token_ids(tokenizer, spec: Dict[str, Any]) -> Set[int]:
    """The ids of the special added tokens, which contribute no bytes to the output."""
    added_tokens = spec.get('added_tokens')
    if isinstance(added_tokens, list):
        return set(entry['id'] for entry in added_tokens
                   if isinstance(entry, dict) and entry.get('special') and 'id' in entry)
    try:
        added = tokenizer.get_added_tokens_decoder()
    except Exception:
        return set()
    return set(token_id for token_id, token in added.items() if getattr(token, 'special', False))


def token_bytes_from_tokenizer(tokenizer) -> Dict[int, bytes]:
    """The exact bytes of every regular token of `tokenizer`.

    :param tokenizer: A `tokenizers.Tokenizer`.
    :return: The bytes that each id of `tokenizer.get_vocab(with_added_tokens=False)`
    contributes, except for the special added tokens.
    :raises ValueError: If the bytes of the vocabulary cannot be determined.
    """
    spec = _tokenizer_spec(tokenizer)
    try:
        vocabulary = tokenizer.get_vocab(with_added_tokens=False)
    except TypeError:
        vocabulary = tokenizer.get_vocab()
    special_ids = _special_token_ids(tokenizer, spec)
    regular = [(piece, token_id) for piece, token_id in vocabulary.items() if token_id not in special_ids]
    decoder_names = _decoder_names(tokenizer, spec)

    if 'ByteLevel' in decoder_names:
        table = byte_level_decoder()
        token_bytes: Dict[int, bytes] = {}
        for piece, token_id in regular:
            try:
                token_bytes[token_id] = bytes(table[character] for character in piece)
            except KeyError:
                raise ValueError(f"Token {piece!r} of a byte level vocabulary is not made of "
                                 "byte to unicode characters")
        return token_bytes

    model = spec.get('model') or {}
    if model.get('byte_fallback'):
        token_bytes = {}
        for piece, token_id in regular:
            single_byte = _BYTE_FALLBACK_PIECE.match(piece)
            if single_byte:
                token_bytes[token_id] = bytes([int(single_byte.group(1), 16)])
            else:
                token_bytes[token_id] = piece.replace(SENTENCEPIECE_SPACE, ' ').encode('utf-8')
        return token_bytes

    raise ValueError("Cannot determine the token bytes of this tokenizer: only byte level BPE "
                     "vocabularies (a ByteLevel decoder) and SentencePiece style BPE "
                     "vocabularies with byte fallback are supported")
