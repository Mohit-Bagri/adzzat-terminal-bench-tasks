"""Character sets over Unicode scalar values, and the UTF-8 arithmetic built on them.

The byte level token enforcer has to reason about every Unicode scalar value, so the
character sets it works with are kept as sorted code point ranges instead of strings.
`CharSetStr` lets such a set travel through the `CharacterLevelParser` interface, whose
`get_allowed_characters()` returns a string: it is a `str` subclass whose membership test
consults the range set, so parsers can keep asking `character in allowed_characters`.
"""
from bisect import bisect_right
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

MAX_CODEPOINT = 0x10FFFF
SURROGATE_FIRST = 0xD800
SURROGATE_LAST = 0xDFFF

RangeList = Tuple[Tuple[int, int], ...]


def _normalize(ranges: Iterable[Tuple[int, int]]) -> RangeList:
    """Sort, clip to the scalar value space and merge a list of inclusive ranges."""
    cleaned: List[Tuple[int, int]] = []
    for low, high in ranges:
        if low < 0:
            low = 0
        if high > MAX_CODEPOINT:
            high = MAX_CODEPOINT
        if low > high:
            continue
        cleaned.append((low, high))
    if not cleaned:
        return ()
    cleaned.sort()
    merged: List[Tuple[int, int]] = []
    current_low, current_high = cleaned[0]
    for low, high in cleaned[1:]:
        if low <= current_high + 1:
            if high > current_high:
                current_high = high
        else:
            merged.append((current_low, current_high))
            current_low, current_high = low, high
    merged.append((current_low, current_high))
    return tuple(merged)


class CharSet:
    """An immutable set of Unicode scalar values, stored as sorted disjoint ranges."""

    __slots__ = ('ranges', '_starts', 'intern_id')

    def __init__(self, ranges: RangeList = ()):
        self.ranges = ranges
        self._starts = tuple(low for low, _ in ranges)
        self.intern_id: Optional[int] = None

    # Construction

    @staticmethod
    def from_ranges(ranges: Iterable[Tuple[int, int]]) -> 'CharSet':
        return CharSet(_normalize(ranges))

    @staticmethod
    def from_codepoints(codepoints: Iterable[int]) -> 'CharSet':
        return CharSet(_normalize((codepoint, codepoint) for codepoint in codepoints))

    @staticmethod
    def from_string(characters: str) -> 'CharSet':
        if not characters:
            return EMPTY_CHARSET
        if isinstance(characters, CharSetStr):
            return characters.charset
        return CharSet(_normalize((ord(character), ord(character)) for character in characters))

    @staticmethod
    def single(codepoint: int) -> 'CharSet':
        return CharSet(((codepoint, codepoint),))

    # Queries

    def __bool__(self) -> bool:
        return bool(self.ranges)

    def __eq__(self, other) -> bool:
        return isinstance(other, CharSet) and self.ranges == other.ranges

    def __hash__(self) -> int:
        return hash(self.ranges)

    def __repr__(self) -> str:
        return 'CharSet({})'.format(', '.join(f'{low:04X}-{high:04X}' for low, high in self.ranges))

    def contains_codepoint(self, codepoint: int) -> bool:
        index = bisect_right(self._starts, codepoint) - 1
        return index >= 0 and self.ranges[index][1] >= codepoint

    def __contains__(self, character: str) -> bool:
        return len(character) == 1 and self.contains_codepoint(ord(character))

    def intersects(self, low: int, high: int) -> bool:
        """Does the set contain any code point in the inclusive range [low, high]?"""
        if low > high:
            return False
        index = bisect_right(self._starts, high) - 1
        return index >= 0 and self.ranges[index][1] >= low

    def covers(self, low: int, high: int) -> bool:
        """Does the set contain every code point in the inclusive range [low, high]?"""
        if low > high:
            return True
        index = bisect_right(self._starts, low) - 1
        return index >= 0 and self.ranges[index][1] >= high

    def size(self) -> int:
        return sum(high - low + 1 for low, high in self.ranges)

    def codepoints(self) -> Iterable[int]:
        for low, high in self.ranges:
            yield from range(low, high + 1)

    def min_codepoint(self) -> Optional[int]:
        return self.ranges[0][0] if self.ranges else None

    # Set operations

    def clip(self, low: int, high: int) -> 'CharSet':
        """The subset inside the inclusive range [low, high]."""
        if low > high or not self.ranges:
            return EMPTY_CHARSET
        if self.ranges[0][0] >= low and self.ranges[-1][1] <= high:
            return self
        kept: List[Tuple[int, int]] = []
        index = max(0, bisect_right(self._starts, low) - 1)
        for range_low, range_high in self.ranges[index:]:
            if range_low > high:
                break
            new_low = range_low if range_low > low else low
            new_high = range_high if range_high < high else high
            if new_low <= new_high:
                kept.append((new_low, new_high))
        return CharSet(tuple(kept))

    def union(self, other: 'CharSet') -> 'CharSet':
        if not self.ranges:
            return other
        if not other.ranges:
            return self
        return CharSet(_normalize(self.ranges + other.ranges))

    def intersection(self, other: 'CharSet') -> 'CharSet':
        if not self.ranges or not other.ranges:
            return EMPTY_CHARSET
        kept: List[Tuple[int, int]] = []
        own_index = other_index = 0
        own, theirs = self.ranges, other.ranges
        while own_index < len(own) and other_index < len(theirs):
            low = max(own[own_index][0], theirs[other_index][0])
            high = min(own[own_index][1], theirs[other_index][1])
            if low <= high:
                kept.append((low, high))
            if own[own_index][1] < theirs[other_index][1]:
                own_index += 1
            else:
                other_index += 1
        return CharSet(tuple(kept))

    def difference(self, other: 'CharSet') -> 'CharSet':
        if not self.ranges or not other.ranges:
            return self
        kept: List[Tuple[int, int]] = []
        other_index = 0
        theirs = other.ranges
        for low, high in self.ranges:
            cursor = low
            while other_index < len(theirs) and theirs[other_index][1] < cursor:
                other_index += 1
            index = other_index
            while index < len(theirs) and theirs[index][0] <= high:
                hole_low, hole_high = theirs[index]
                if hole_low > cursor:
                    kept.append((cursor, hole_low - 1))
                if hole_high + 1 > cursor:
                    cursor = hole_high + 1
                if cursor > high:
                    break
                index += 1
            if cursor <= high:
                kept.append((cursor, high))
        return CharSet(tuple(kept))


EMPTY_CHARSET = CharSet()
"""The empty set."""

UNIVERSE_CHARSET = CharSet(((0, SURROGATE_FIRST - 1), (SURROGATE_LAST + 1, MAX_CODEPOINT)))
"""Every Unicode scalar value: surrogates are not scalar values and cannot be encoded."""

_SURROGATE_CHARSET = CharSet(((SURROGATE_FIRST, SURROGATE_LAST),))

_CHARSET_INTERN: Dict[RangeList, CharSet] = {}


def intern_charset(charset: CharSet) -> CharSet:
    """Return a canonical instance for `charset`, numbered so that caches can key on it."""
    if charset.intern_id is not None:
        return charset
    existing = _CHARSET_INTERN.get(charset.ranges)
    if existing is None:
        charset.intern_id = len(_CHARSET_INTERN)
        _CHARSET_INTERN[charset.ranges] = charset
        return charset
    return existing


_ASCII_CHARACTERS = ''.join(chr(codepoint) for codepoint in range(0x80))


class CharSetStr(str):
    """A `get_allowed_characters()` result that stands for a set of code point ranges.

    The string contents are only the ASCII members of the set (or a single representative
    if there are none), which keeps the common `character in allowed` test and the
    ``allowed == ''`` emptiness test meaningful, while `__contains__` stays exact.
    """

    charset: CharSet

    def __new__(cls, charset: CharSet) -> 'CharSetStr':
        ascii_ranges = charset.clip(0, 0x7F).ranges
        if len(ascii_ranges) == 1:
            low, high = ascii_ranges[0]
            ascii_part = _ASCII_CHARACTERS[low:high + 1]
        else:
            ascii_part = ''.join(_ASCII_CHARACTERS[low:high + 1] for low, high in ascii_ranges)
        if not ascii_part:
            smallest = charset.min_codepoint()
            ascii_part = '' if smallest is None else chr(smallest)
        instance = super().__new__(cls, ascii_part)
        instance.charset = charset
        return instance

    def __contains__(self, item) -> bool:
        if isinstance(item, str) and len(item) == 1:
            return self.charset.contains_codepoint(ord(item))
        return str.__contains__(self, item)

    def __add__(self, other) -> 'CharSetStr':
        return CharSetStr(self.charset.union(CharSet.from_string(other)))

    def __radd__(self, other) -> 'CharSetStr':
        return CharSetStr(self.charset.union(CharSet.from_string(other)))

    def replace(self, old: str, new: str = '', *args) -> 'CharSetStr':  # type: ignore[override]
        """Replace characters, reading both arguments as sets of characters.

        That is what an allowed character string is; the parsers only ever remove a single
        character from one (the quote and the backslash of a regex constrained string).
        """
        updated = self.charset.difference(CharSet.from_string(old))
        if new:
            updated = updated.union(CharSet.from_string(new))
        return CharSetStr(updated)


def charset_of(characters: str) -> CharSet:
    """The set of scalar values that a `get_allowed_characters()` result stands for."""
    if isinstance(characters, CharSetStr):
        return characters.charset
    return CharSet.from_string(characters)


def combine_allowed_characters(parts: Sequence[str]) -> Optional[CharSetStr]:
    """Union of several `get_allowed_characters()` results, or None if none of them is a set."""
    if not any(isinstance(part, CharSetStr) for part in parts):
        return None
    combined = EMPTY_CHARSET
    for part in parts:
        combined = combined.union(charset_of(part))
    return CharSetStr(combined)


def remove_characters(characters: str, removed: str) -> str:
    """Drop `removed` from a `get_allowed_characters()` result, keeping range sets intact."""
    if isinstance(characters, CharSetStr):
        return CharSetStr(characters.charset.difference(CharSet.from_string(removed)))
    return "".join(character for character in characters if character not in removed)


# UTF-8 arithmetic

_SEQUENCE_LENGTH: List[int] = [0] * 256
for _byte in range(0x00, 0x80):
    _SEQUENCE_LENGTH[_byte] = 1
for _byte in range(0xC2, 0xE0):
    _SEQUENCE_LENGTH[_byte] = 2
for _byte in range(0xE0, 0xF0):
    _SEQUENCE_LENGTH[_byte] = 3
for _byte in range(0xF0, 0xF5):
    _SEQUENCE_LENGTH[_byte] = 4

_LEAD_VALUE_MASK = {1: 0x7F, 2: 0x1F, 3: 0x0F, 4: 0x07}
_LEAD_BASE = {2: 0xC0, 3: 0xE0, 4: 0xF0}
_LENGTH_RANGE = {1: (0x00, 0x7F), 2: (0x80, 0x7FF), 3: (0x800, 0xFFFF), 4: (0x10000, MAX_CODEPOINT)}


def sequence_length(lead_byte: int) -> int:
    """The length of the UTF-8 sequence that starts with `lead_byte`, or 0 if it cannot."""
    return _SEQUENCE_LENGTH[lead_byte]


def pending_window(pending: bytes) -> Tuple[int, int]:
    """The inclusive code point range still reachable after the partial sequence `pending`.

    An empty range (low > high) means that `pending` cannot start a valid character.
    """
    length = _SEQUENCE_LENGTH[pending[0]]
    remaining = length - len(pending)
    if remaining <= 0:
        return 1, 0
    value = pending[0] & _LEAD_VALUE_MASK[length]
    for byte in pending[1:]:
        if byte & 0xC0 != 0x80:
            return 1, 0
        value = (value << 6) | (byte & 0x3F)
    base = value << (6 * remaining)
    window_low, window_high = _LENGTH_RANGE[length]
    scalar_values = UNIVERSE_CHARSET.clip(max(base, window_low),
                                          min(base | ((1 << (6 * remaining)) - 1), window_high))
    if not scalar_values:
        return 1, 0
    return scalar_values.ranges[0][0], scalar_values.ranges[-1][1]


def utf8_byte_options(charset: CharSet, pending: bytes) -> Tuple[Dict[int, int], Tuple[int, ...]]:
    """Which bytes may follow `pending` while staying a UTF-8 prefix of a character in `charset`.

    Returns the bytes that complete a character (mapped to that code point) and the bytes
    that leave the sequence incomplete.
    """
    if charset.intersects(SURROGATE_FIRST, SURROGATE_LAST):
        charset = charset.difference(_SURROGATE_CHARSET)
    complete: Dict[int, int] = {}
    partial: List[int] = []
    if not pending:
        for low, high in charset.clip(0x00, 0x7F).ranges:
            for byte in range(low, high + 1):
                complete[byte] = byte
        for length in (2, 3, 4):
            shift = 6 * (length - 1)
            lead_base = _LEAD_BASE[length]
            range_low, range_high = _LENGTH_RANGE[length]
            for low, high in charset.clip(range_low, range_high).ranges:
                partial.extend(range(lead_base | (low >> shift), (lead_base | (high >> shift)) + 1))
    else:
        length = _SEQUENCE_LENGTH[pending[0]]
        remaining = length - len(pending)
        value = pending[0] & _LEAD_VALUE_MASK[length]
        for byte in pending[1:]:
            value = (value << 6) | (byte & 0x3F)
        base = value << (6 * remaining)
        shift = 6 * (remaining - 1)
        window_low, window_high = _LENGTH_RANGE[length]
        low_bound = max(base, window_low)
        high_bound = min(base | ((1 << (6 * remaining)) - 1), window_high)
        for low, high in charset.clip(low_bound, high_bound).ranges:
            first_byte = 0x80 + ((low - base) >> shift)
            last_byte = 0x80 + ((high - base) >> shift)
            if remaining == 1:
                for byte in range(first_byte, last_byte + 1):
                    complete[byte] = base + (byte - 0x80)
            else:
                partial.extend(range(first_byte, last_byte + 1))
    if len(partial) > 1:
        partial = sorted(set(partial))
    return complete, tuple(partial)
