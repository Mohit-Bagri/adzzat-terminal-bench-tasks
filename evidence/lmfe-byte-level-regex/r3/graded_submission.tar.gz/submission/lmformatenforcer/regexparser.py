from typing import Dict, Hashable, Optional, Set, Union, List
import interegular
from interegular.fsm import anything_else

from .characterlevelparser import CharacterLevelParser, CharacterLevelParserConfig
from .charsets import EMPTY_CHARSET, UNIVERSE_CHARSET, CharSet, CharSetStr, intern_charset

class RegexParser(CharacterLevelParser):
    """RegexParser is an example CharacterLevelParser that only allows strings that match a given regular expression."""

    UNINITIALIZED_STATE = -1
    INVALID_STATE = -2

    class _Context:
        pattern: interegular.FSM
        anything_else_characters: str
        state_character_cache: Dict[int, str]
        state_charset_cache: Dict[int, CharSetStr]
        viable_states: Optional[Set[int]]
        explicit_charset: Optional[CharSet]
    
    context: _Context
    current_state: int

    def __init__(self, pattern: Union[str, _Context], config: Optional[CharacterLevelParserConfig] = None, current_state: int = UNINITIALIZED_STATE):
        super().__init__(config)
        if isinstance(pattern, str):
            self.context = RegexParser._Context()
            self.context.pattern = interegular.parse_pattern(pattern).to_fsm()
            self.context.state_character_cache = {}
            self.context.state_charset_cache = {}
            self.context.viable_states = None
            self.context.explicit_charset = None
            self._update_alphabet(self.config.alphabet)
        else:
            self.context = pattern
        self.current_state: int = self.context.pattern.initial if current_state == RegexParser.UNINITIALIZED_STATE else current_state

    def add_character(self, new_character: str) -> 'RegexParser':
        if self.current_state == RegexParser.INVALID_STATE:
            return self
        
        state = self.current_state
        fsm = self.context.pattern
        # Mostly taken from FSM.accept()
        symbol = new_character
        if anything_else in fsm.alphabet and not symbol in fsm.alphabet:
            symbol = anything_else
        transition = fsm.alphabet[symbol]

        try:
            # Prefer try-catch to checking if transition exists to avoid double lookup perf hit in valid case
            state = fsm.map[state][transition]  # type: ignore
            return RegexParser(self.context, self.config, state)
        except KeyError:
            # Missing transition = transition to dead state
            return RegexParser(self.context, self.config, RegexParser.INVALID_STATE)
    
    def can_end(self) -> bool:
        if self.config.byte_level:
            # A dead state has no completion, so it must not be reported as a valid ending.
            return self.current_state in self.context.pattern.finals
        return self.current_state in self.context.pattern.finals or self.current_state == RegexParser.INVALID_STATE
    
    def get_allowed_characters(self) -> str:
        if self.config.byte_level:
            return self._get_allowed_charset_str()
        if self.current_state not in self.context.pattern.map:
            return ''
        if self.current_state not in self.context.state_character_cache:
            allowed_characters = []
            state_map = self.context.pattern.map[self.current_state]
            for symbol_idx in state_map:
                symbols: List[str] = self.context.pattern.alphabet.by_transition[symbol_idx]
                for symbol in symbols:
                    if symbol == anything_else:
                        allowed_characters.append(self.context.anything_else_characters)
                    else:
                        allowed_characters.append(symbol)
            self.context.state_character_cache[self.current_state] = "".join(allowed_characters)
        return self.context.state_character_cache[self.current_state]
    
    def cache_key(self) -> Optional[Hashable]:
        # If we are in the same regex fsm state, the allowed next tokens are the same ones
        return self.current_state

    def state_key(self) -> Optional[Hashable]:
        return ('regex', id(self.context), self.current_state)

    def _get_allowed_charset_str(self) -> CharSetStr:
        """The exact set of scalar values that can continue towards a full match.

        Unlike the string based version, this does not depend on the configured alphabet:
        a character class or '.' stands for every scalar value it describes. Transitions
        into states that can no longer reach a final state are dropped, so every allowed
        character keeps a full match reachable.
        """
        cached = self.context.state_charset_cache.get(self.current_state)
        if cached is not None:
            return cached
        fsm = self.context.pattern
        state_map = fsm.map.get(self.current_state)
        allowed = EMPTY_CHARSET
        if state_map:
            viable = self._viable_states()
            codepoints: List[int] = []
            for symbol_idx, destination in state_map.items():
                if destination not in viable:
                    continue
                symbols: List[str] = fsm.alphabet.by_transition[symbol_idx]
                for symbol in symbols:
                    if symbol == anything_else:
                        allowed = allowed.union(UNIVERSE_CHARSET.difference(self._explicit_charset()))
                    else:
                        codepoints.append(ord(symbol))
            if codepoints:
                allowed = allowed.union(CharSet.from_codepoints(codepoints))
        result = CharSetStr(intern_charset(allowed.intersection(UNIVERSE_CHARSET)))
        self.context.state_charset_cache[self.current_state] = result
        return result

    def _explicit_charset(self) -> CharSet:
        """The characters that the pattern mentions explicitly ('anything_else' is the rest)."""
        if self.context.explicit_charset is None:
            self.context.explicit_charset = CharSet.from_codepoints(
                ord(symbol) for symbol in self.context.pattern.alphabet.keys() if symbol != anything_else)
        return self.context.explicit_charset

    def _viable_states(self) -> Set[int]:
        """The states from which a final state is still reachable."""
        if self.context.viable_states is None:
            fsm = self.context.pattern
            incoming: Dict[int, Set[int]] = {}
            for state, state_map in fsm.map.items():
                for destination in state_map.values():
                    incoming.setdefault(destination, set()).add(state)
            viable = set(fsm.finals)
            pending = list(fsm.finals)
            while pending:
                state = pending.pop()
                for source in incoming.get(state, ()):
                    if source not in viable:
                        viable.add(source)
                        pending.append(source)
            self.context.viable_states = viable
        return self.context.viable_states

    def _update_alphabet(self, new_alphabet: str):
        if self.context:
            not_anything_else_characters = set([c for c in self.context.pattern.alphabet.keys() if c != anything_else])
            self.context.anything_else_characters = "".join([c for c in new_alphabet if c not in not_anything_else_characters])    
    
    @CharacterLevelParser.config.setter
    def config(self, new_config: CharacterLevelParserConfig):
        CharacterLevelParser.config.fset(self, new_config)  # Original set
        self._update_alphabet(new_config.alphabet)
