"""Exact token masks for byte level vocabularies.

A byte level BPE vocabulary contains tokens that hold only part of a UTF-8 character, so
tokens cannot be matched against the characters a `CharacterLevelParser` allows. Instead,
the parser is wrapped in a byte level automaton: a state is a parser state plus the bytes
of a character that is not complete yet, and a token is allowed when its bytes walk that
automaton without leaving the set of strings the parser accepts.
"""
import logging
from dataclasses import replace
from typing import Dict, FrozenSet, Hashable, List, Optional, Tuple

from .characterlevelparser import CharacterLevelParser, CharacterLevelParserConfig
from .charsets import UNIVERSE_CHARSET, CharSet, charset_of, intern_charset, utf8_byte_options


class ByteTrieNode:
    __slots__ = ('children', 'tokens')

    def __init__(self) -> None:
        self.children: Dict[int, 'ByteTrieNode'] = {}
        self.tokens: List[int] = []


class ByteTokenTrie:
    """The tokens of the vocabulary, keyed by the exact bytes they contribute."""

    def __init__(self, token_bytes: Dict[int, bytes]) -> None:
        self.root = ByteTrieNode()
        self.max_token_length = 0
        for token_id, data in token_bytes.items():
            node = self.root
            for byte in data:
                child = node.children.get(byte)
                if child is None:
                    child = ByteTrieNode()
                    node.children[byte] = child
                node = child
            node.tokens.append(token_id)
            if len(data) > self.max_token_length:
                self.max_token_length = len(data)


_byte_options_cache: Dict[Tuple[int, bytes], Tuple[Dict[int, int], FrozenSet[int]]] = {}
_MISSING = object()


class ByteLevelState:
    """A parser state, together with the bytes of a partially written character."""

    __slots__ = ('_filter', 'parser', 'pending', '_charset', '_options', '_steps', '_mask')

    def __init__(self, token_filter: 'ByteLevelTokenFilter', parser: CharacterLevelParser, pending: bytes):
        self._filter = token_filter
        self.parser = parser
        self.pending = pending
        self._charset: Optional[CharSet] = None
        self._options: Optional[Tuple[Dict[int, int], FrozenSet[int]]] = None
        self._steps: Dict[int, Optional['ByteLevelState']] = {}
        self._mask: Optional[List[int]] = None

    def can_end(self) -> bool:
        """Whether the output so far is complete UTF-8 that the parser accepts in full."""
        return not self.pending and self.parser.can_end()

    def charset(self) -> CharSet:
        """The scalar values the parser allows next."""
        if self._charset is None:
            allowed = charset_of(self.parser.get_allowed_characters())
            self._charset = intern_charset(allowed.intersection(UNIVERSE_CHARSET))
        return self._charset

    def _byte_options(self) -> Tuple[Dict[int, int], FrozenSet[int]]:
        """Which bytes complete a character, and which leave one incomplete."""
        if self._options is None:
            charset = self.charset()
            cache_key = (charset.intern_id, self.pending)
            options = _byte_options_cache.get(cache_key)
            if options is None:
                complete, partial = utf8_byte_options(charset, self.pending)
                options = (complete, frozenset(partial))
                _byte_options_cache[cache_key] = options
            self._options = options
        return self._options

    def step(self, byte: int) -> Optional['ByteLevelState']:
        """The state after `byte`, or None if the byte cannot continue the output."""
        steps = self._steps
        if byte in steps:
            return steps[byte]
        complete, partial = self._byte_options()
        codepoint = complete.get(byte)
        next_state: Optional['ByteLevelState']
        if codepoint is not None:
            try:
                next_parser = self.parser.add_character(chr(codepoint))
            except Exception:
                logging.debug("Byte level parser rejected an allowed character", exc_info=True)
                next_state = None
            else:
                next_state = self._filter.state_for(next_parser, b'')
        elif byte in partial:
            next_state = self._filter.state_for(self.parser, self.pending + bytes((byte,)))
        else:
            next_state = None
        steps[byte] = next_state
        return next_state

    def advance(self, data: bytes) -> Optional['ByteLevelState']:
        state: Optional['ByteLevelState'] = self
        for byte in data:
            state = state.step(byte)
            if state is None:
                return None
        return state


class ByteLevelTokenFilter:
    """Computes the allowed token masks of one parser over a byte level vocabulary."""

    def __init__(self, trie: ByteTokenTrie, root_parser: CharacterLevelParser,
                 share_states: bool = True):
        """
        :param trie: The vocabulary, keyed by token bytes.
        :param root_parser: The parser that defines the allowed strings.
        :param share_states: Whether parser states that `state_key()` reports as equivalent
        may share their work. Turning it off is much slower but relies on nothing.
        """
        self.trie = trie
        self.root_parser = root_parser
        self.share_states = share_states
        self.states: Dict[Hashable, ByteLevelState] = {}
        self.root_state = self.state_for(root_parser, b'')

    def state_for(self, parser: CharacterLevelParser, pending: bytes) -> ByteLevelState:
        """A state for `parser` and `pending`, shared with equivalent states when possible."""
        parser_key = parser.state_key() if self.share_states else None
        if parser_key is None:
            return ByteLevelState(self, parser, pending)
        key = (parser_key, pending)
        state = self.states.get(key)
        if state is None:
            state = ByteLevelState(self, parser, pending)
            self.states[key] = state
        return state

    def allowed_tokens(self, state: ByteLevelState) -> List[int]:
        """The sorted ids of the tokens whose bytes may be appended in `state`."""
        if state._mask is not None:
            return state._mask
        tokens: List[int] = []
        pending = [(state, self.trie.root)]
        missing = _MISSING
        while pending:
            current, node = pending.pop()
            if node.tokens:
                tokens.extend(node.tokens)
            steps = current._steps
            for byte, child in node.children.items():
                next_state = steps.get(byte, missing)
                if next_state is missing:
                    next_state = current.step(byte)
                if next_state is not None:
                    pending.append((next_state, child))
        tokens.sort()
        state._mask = tokens
        return tokens


def byte_level_config(config: CharacterLevelParserConfig, alphabet: str) -> CharacterLevelParserConfig:
    return replace(config, alphabet=alphabet, byte_level=True)


def apply_byte_level_config(parser: CharacterLevelParser, config: CharacterLevelParserConfig) -> None:
    """Give `parser` and every parser it contains the byte level configuration.

    Composite parsers do not pass their configuration down, but the byte level rules apply
    at every depth: every parser in the tree works over the whole Unicode range.
    """
    visited = set()
    pending = [parser]
    while pending:
        current = pending.pop()
        if id(current) in visited:
            continue
        visited.add(id(current))
        current.config = config
        for child in getattr(current, 'parsers', ()) or ():
            if isinstance(child, CharacterLevelParser):
                pending.append(child)
