"""Exact token masks for byte level vocabularies.

`TokenEnforcer` normally matches tokens by the string they decode to. In a byte level BPE
vocabulary a token may hold only a part of a character, so its string is not enough: the
enforcer has to reason about the bytes themselves. This module does that. It keeps the
generated output as "the parser state after every whole character" plus the bytes of a
character that is still incomplete, and it walks a trie of the vocabulary to find every token
whose bytes keep the output a prefix of something the parser accepts.

The character level parsers are used as they are, except that the sets of allowed characters
are computed as code point ranges (see `charsets`), so that `.`, negated classes and JSON
free text mean every unicode scalar value rather than the characters of the tokenizer. The one
part that is not taken from the character level parsers is the inside of a JSON string value,
which is parsed with JSON's own string syntax so that the schema can be applied to the
characters the value decodes to (see `jsonstringvalue`); everything around it, the structure
included, still behaves exactly as the character level parsers do.
"""
from typing import Callable, Dict, Hashable, List, Optional, Sequence, Tuple, Union

from .charsets import (ALL_CHARACTERS, EMPTY_CHAR_SET, CharSet, char_set, characters_starting_with,
                       decode_character, split_token_bytes, utf8_sequence_length)
from .characterlevelparser import (CharacterLevelParser, ForceStopParser, SequenceParser, StringParser,
                                   UnionParser)
from .consts import WHITESPACE_CHARACTERS
from .jsonschemaparser import (JsonSchemaParser, ListParsingState, NumberParsingState, ObjectParsingStage,
                               ObjectParsingState, StringParsingState)
from .jsonstringvalue import JsonStringValueParser
from .regexfsm import fsm_info
from .regexparser import RegexParser
from .tokenlist import TokenList

_WHITESPACE = char_set(WHITESPACE_CHARACTERS)
_QUOTE = char_set('"')
_QUOTE_OR_WHITESPACE = char_set('"' + WHITESPACE_CHARACTERS)
_BACKSLASH = char_set('\\')
_QUOTE_AND_BACKSLASH = char_set('"\\')
_MISSING = object()


class ByteTokenNode:
    """A node of the vocabulary trie, one whole character per edge."""

    __slots__ = ('children', 'tokens', 'partial_tokens')

    def __init__(self) -> None:
        self.children: Dict[str, 'ByteTokenNode'] = {}
        self.tokens: List[int] = []
        self.partial_tokens: Dict[bytes, List[int]] = {}
        """Tokens that end here plus the bytes of an unfinished character, by those bytes."""


class ByteTokenIndex:
    """The vocabulary, indexed by the characters and partial characters that tokens are made of.

    Every token is split into the continuation bytes it starts with (which can only finish a
    character that was already started), the whole characters in its middle, and the bytes of
    an unfinished character at its end. Tokens whose bytes can never appear in valid UTF-8 are
    dropped, since they can never be allowed.
    """

    def __init__(self, token_bytes: Dict[int, bytes]):
        self.root = ByteTokenNode()
        self.continuation_roots: Dict[bytes, ByteTokenNode] = {}
        self.continuations_by_length: Dict[int, List[Tuple[bytes, ByteTokenNode]]] = {1: [], 2: [], 3: []}
        self.empty_tokens: List[int] = []
        self.token_bytes = token_bytes
        for token_id, data in token_bytes.items():
            if not data:
                self.empty_tokens.append(token_id)
                continue
            split = split_token_bytes(bytes(data))
            if split is None:
                continue
            continuation, characters, partial = split
            if continuation:
                node = self.continuation_roots.get(continuation)
                if node is None:
                    node = ByteTokenNode()
                    self.continuation_roots[continuation] = node
                    self.continuations_by_length[len(continuation)].append((continuation, node))
            else:
                node = self.root
            for character in characters:
                child = node.children.get(character)
                if child is None:
                    child = ByteTokenNode()
                    node.children[character] = child
                node = child
            if partial:
                node.partial_tokens.setdefault(partial, []).append(token_id)
            else:
                node.tokens.append(token_id)


def prepare_parser(parser: CharacterLevelParser) -> CharacterLevelParser:
    """Return a copy of `parser` whose JSON string values follow JSON's own string rules.

    Composite parsers do not pass their configuration down, so every JsonSchemaParser in the
    tree, at any depth, is rebuilt with its own context marked.
    """
    if isinstance(parser, JsonSchemaParser):
        context = JsonSchemaParser._Context()
        context.model_class = parser.context.model_class
        context.alphabet_without_quotes = getattr(parser.context, 'alphabet_without_quotes',
                                                  parser.config.alphabet.replace('"', ''))
        context.byte_level_string_values = True
        prepared = JsonSchemaParser(context, parser.config)
        context.active_parser = prepared
        return prepared
    if isinstance(parser, (UnionParser, SequenceParser)):
        return type(parser)([prepare_parser(option) for option in parser.parsers])
    return parser


def _regex_allowed(parser: RegexParser) -> CharSet:
    return fsm_info(parser.context.pattern).allowed_characters(parser.current_state)


def _string_parser_allowed(parser: StringParser) -> CharSet:
    return CharSet.from_chars(parser.target_str[:1])


def _force_stop_allowed(parser: ForceStopParser) -> CharSet:
    return _WHITESPACE if parser.allow_whitespace else EMPTY_CHAR_SET


def _union_allowed(parser: UnionParser) -> CharSet:
    allowed = EMPTY_CHAR_SET
    for option in parser.parsers:
        allowed = allowed.union(allowed_characters(option))
    return allowed


def _sequence_allowed(parser: SequenceParser) -> CharSet:
    allowed = EMPTY_CHAR_SET
    for option in parser.parsers:
        allowed = allowed.union(allowed_characters(option))
        if not option.can_end():
            break
    return allowed


def _json_schema_allowed(parser: JsonSchemaParser) -> CharSet:
    parser.context.active_parser = parser
    allowed = EMPTY_CHAR_SET
    found = False
    for element in reversed(parser.object_stack):
        found = True
        allowed = allowed.union(allowed_characters(element))
        if not element.can_end():
            break
    if not found:
        # Nothing left to parse. Upstream allows whitespace here, to keep beam search happy.
        allowed = _WHITESPACE
    if parser.num_consecutive_whitespaces >= parser.config.max_consecutive_whitespaces:
        allowed = allowed.difference(_WHITESPACE)
    return allowed


def _string_state_allowed(parser: StringParsingState) -> CharSet:
    """The range level version of StringParsingState.get_allowed_characters()."""
    if not parser.seen_opening_quote:
        return _QUOTE_OR_WHITESPACE
    if parser.seen_closing_quote:
        return _WHITESPACE
    if parser.regex_parser is not None:
        info = fsm_info(parser.regex_parser.context.pattern)
        state = parser.regex_parser.current_state
        allowed = info.allowed_characters(state).difference(_QUOTE_AND_BACKSLASH)
        if info.can_end(state):
            allowed = allowed.union(_QUOTE)
        return allowed
    if parser.allowed_strings:
        parsed = parser.parsed_string
        length = len(parsed)
        continuations = set()
        for allowed_string in parser.allowed_strings:
            if len(allowed_string) > length and allowed_string.startswith(parsed):
                continuations.add(allowed_string[length])
        allowed = CharSet.from_chars(continuations)
        if parser.require_closing_quote and parsed in parser.allowed_strings:
            allowed = allowed.union(_QUOTE)
        if not parsed and not parser.require_opening_quote:
            allowed = allowed.union(_WHITESPACE)
        return allowed
    # Free text. The alphabet of the parser is every unicode scalar value.
    if parser.min_length is not None and len(parser.parsed_string) < parser.min_length:
        return ALL_CHARACTERS.difference(_QUOTE)
    if parser.max_length is not None and len(parser.parsed_string) >= parser.max_length:
        return _QUOTE
    return ALL_CHARACTERS


def _plain_allowed(parser: CharacterLevelParser) -> CharSet:
    return CharSet.from_chars(parser.get_allowed_characters())


_ALLOWED_HANDLERS: Sequence[Tuple[type, Callable[[CharacterLevelParser], CharSet]]] = (
    (RegexParser, _regex_allowed),
    (JsonSchemaParser, _json_schema_allowed),
    (JsonStringValueParser, lambda parser: parser.byte_allowed_characters()),
    (StringParsingState, _string_state_allowed),
    (UnionParser, _union_allowed),
    (SequenceParser, _sequence_allowed),
    (StringParser, _string_parser_allowed),
    (ForceStopParser, _force_stop_allowed),
    (ObjectParsingState, _plain_allowed),
    (ListParsingState, _plain_allowed),
    (NumberParsingState, _plain_allowed),
)

_allowed_cache: Dict[type, Callable[[CharacterLevelParser], CharSet]] = {}


def allowed_characters(parser: CharacterLevelParser) -> CharSet:
    """The set of characters the parser allows next, as code point ranges."""
    handler = _allowed_cache.get(type(parser))
    if handler is None:
        handler = _plain_allowed
        for parser_type, candidate in _ALLOWED_HANDLERS:
            if isinstance(parser, parser_type):
                handler = candidate
                break
        _allowed_cache[type(parser)] = handler
    return handler(parser)


def _advance_union(parser: UnionParser, character: str) -> CharacterLevelParser:
    options = [advance_parser(option, character)
               for option in parser.parsers if character in allowed_characters(option)]
    if len(options) == 1:
        return options[0]
    return UnionParser(options)


def _advance_sequence(parser: SequenceParser, character: str) -> CharacterLevelParser:
    options: List[CharacterLevelParser] = []
    for index, option in enumerate(parser.parsers):
        if character in allowed_characters(option):
            remaining = [advance_parser(option, character)] + parser.parsers[index + 1:]
            options.append(remaining[0] if len(remaining) == 1 else SequenceParser(remaining))
        if not option.can_end():
            break
    if len(options) == 1:
        return options[0]
    return UnionParser(options)


def _advance_json_schema(parser: JsonSchemaParser, character: str) -> CharacterLevelParser:
    """JsonSchemaParser.add_character(), dispatching on code point ranges instead of strings."""
    parser.context.active_parser = parser
    stack = parser.object_stack
    receiving_idx = len(stack) - 1
    last_parsed_string = parser.last_parsed_string
    while receiving_idx >= 0 and character not in allowed_characters(stack[receiving_idx]):
        finished_receiver = stack[receiving_idx]
        if isinstance(finished_receiver, StringParsingState):
            last_parsed_string = finished_receiver.parsed_string
        receiving_idx -= 1

    updated_parser = JsonSchemaParser(parser.context, parser.config, stack[:receiving_idx + 1],
                                      parser.num_consecutive_whitespaces)
    updated_parser.context.active_parser = updated_parser
    updated_parser.last_parsed_string = last_parsed_string
    if receiving_idx >= 0:
        updated_parser.object_stack[receiving_idx] = advance_parser(
            updated_parser.object_stack[receiving_idx], character)
    if character in WHITESPACE_CHARACTERS:
        # The whitespace bookkeeping of the JSON parser is part of the structure, so it counts
        # every character, including the ones that a string value took.
        updated_parser.num_consecutive_whitespaces += 1
        updated_parser.last_non_whitespace_character = parser.last_non_whitespace_character
    else:
        updated_parser.num_consecutive_whitespaces = 0
        updated_parser.last_non_whitespace_character = character

    if updated_parser.object_stack and isinstance(updated_parser.object_stack[-1], UnionParser) and \
            any(isinstance(option, (ObjectParsingState, ListParsingState))
                for option in updated_parser.object_stack[-1].parsers):
        # Options that modify the object stack need a stack of their own.
        option_parsers = []
        for option in updated_parser.object_stack[-1].parsers:
            option_stack = updated_parser.object_stack[:-1] + [option]
            option_parser = JsonSchemaParser(parser.context, parser.config, option_stack,
                                             updated_parser.num_consecutive_whitespaces)
            option_parser.context.active_parser = option_parser
            option_parser.last_parsed_string = last_parsed_string
            option_parser.last_non_whitespace_character = updated_parser.last_non_whitespace_character
            option_parsers.append(option_parser)
        return UnionParser(option_parsers)

    new_object_stack = updated_parser.object_stack
    while new_object_stack and new_object_stack[-1].can_end() and not allowed_characters(new_object_stack[-1]):
        finished_receiver = new_object_stack[-1]
        if isinstance(finished_receiver, StringParsingState):
            updated_parser.last_parsed_string = finished_receiver.parsed_string
        del new_object_stack[-1]
        if new_object_stack:
            new_top_parser = new_object_stack[-1]
            if isinstance(new_top_parser, ListParsingState):
                new_top_parser = new_top_parser._clone()
                new_top_parser.num_items_seen += 1
                new_object_stack[-1] = new_top_parser
    return updated_parser


_ADVANCE_HANDLERS: Sequence[Tuple[type, Callable[[CharacterLevelParser, str], CharacterLevelParser]]] = (
    (JsonSchemaParser, _advance_json_schema),
    (JsonStringValueParser, lambda parser, character: parser.byte_advance(character)),
    (UnionParser, _advance_union),
    (SequenceParser, _advance_sequence),
)

_advance_cache: Dict[type, Callable[[CharacterLevelParser, str], CharacterLevelParser]] = {}


def _advance_plain(parser: CharacterLevelParser, character: str) -> CharacterLevelParser:
    return parser.add_character(character)


def advance_parser(parser: CharacterLevelParser, character: str) -> CharacterLevelParser:
    """The parser state after `character`, which must be allowed."""
    handler = _advance_cache.get(type(parser))
    if handler is None:
        handler = _advance_plain
        for parser_type, candidate in _ADVANCE_HANDLERS:
            if isinstance(parser, parser_type):
                handler = candidate
                break
        _advance_cache[type(parser)] = handler
    return handler(parser, character)


def _contains_list_state(parsers: Sequence[CharacterLevelParser]) -> bool:
    for parser in parsers:
        if isinstance(parser, ListParsingState):
            return True
        if isinstance(parser, (UnionParser, SequenceParser)) and _contains_list_state(parser.parsers):
            return True
    return False


def _awaits_key_value_separator(parsers: Sequence[CharacterLevelParser]) -> bool:
    """Whether some object is about to read ':', which is when the last parsed key matters."""
    for parser in parsers:
        if isinstance(parser, ObjectParsingState) and \
                parser.current_stage == ObjectParsingStage.PARSING_KEY_VALUE_SEPARATOR:
            return True
        if isinstance(parser, (UnionParser, SequenceParser)) and _awaits_key_value_separator(parser.parsers):
            return True
    return False


class ParserState:
    """One canonical parser state, with the transitions and sets computed for it so far."""

    __slots__ = ('parser', 'key', 'transitions', 'mask', '_allowed', '_can_end', '_partial')

    def __init__(self, parser: CharacterLevelParser, key: Hashable):
        self.parser = parser
        self.key = key
        self.transitions: Dict[str, Optional['ParserState']] = {}
        self.mask: Dict[bytes, TokenList] = {}
        self._allowed: Optional[CharSet] = None
        self._can_end: Optional[bool] = None
        self._partial: Dict[bytes, bool] = {}

    @property
    def allowed(self) -> CharSet:
        if self._allowed is None:
            self._allowed = allowed_characters(self.parser)
        return self._allowed

    @property
    def can_end(self) -> bool:
        if self._can_end is None:
            self._can_end = self.parser.can_end()
        return self._can_end

    def can_start_character(self, prefix: bytes) -> bool:
        """Whether some allowed character's UTF-8 encoding starts with `prefix`."""
        answer = self._partial.get(prefix)
        if answer is None:
            allowed = self.allowed
            answer = any(allowed.intersects_range(first, last)
                         for first, last in characters_starting_with(prefix).ranges)
            self._partial[prefix] = answer
        return answer


class ByteLevelTokenEnforcer:
    """Computes token masks over token bytes for one parser."""

    MAX_CACHED_STATES = 20000
    MAX_CACHED_MASK_TOKENS = 4_000_000

    def __init__(self,
                 index: ByteTokenIndex,
                 parser: CharacterLevelParser,
                 eos_token_id: Union[int, List[int]],
                 use_bitmask: bool,
                 vocab_size: int):
        self.index = index
        self.eos_token_ids = list(eos_token_id) if isinstance(eos_token_id, list) else [eos_token_id]
        self.use_bitmask = use_bitmask
        self.vocab_size = vocab_size
        self.states: Dict[Hashable, ParserState] = {}
        self._identities: Dict[int, object] = {}
        self._cached_mask_size = 0
        self._eos_in_vocabulary = any(token_id in index.token_bytes for token_id in self.eos_token_ids)
        self.root_state = self._intern(prepare_parser(parser))
        self.dead_state = self._intern(ForceStopParser())

    # State management

    def _identity(self, item: object) -> int:
        """A stable identity for objects that appear in state keys, keeping them alive."""
        identity = id(item)
        self._identities.setdefault(identity, item)
        return identity

    def _intern(self, parser: CharacterLevelParser) -> ParserState:
        key = self.state_key(parser)
        state = self.states.get(key)
        if state is None:
            if len(self.states) > self.MAX_CACHED_STATES:
                self.states.clear()
            state = ParserState(parser, key)
            self.states[key] = state
        return state

    def step(self, state: ParserState, character: str) -> Optional[ParserState]:
        """The state after `character`, or None if the character is not allowed."""
        next_state = state.transitions.get(character, _MISSING)
        if next_state is _MISSING:
            if character in state.allowed:
                next_state = self._intern(advance_parser(state.parser, character))
            else:
                next_state = None
            state.transitions[character] = next_state
        return next_state

    def feed_bytes(self, state: ParserState, pending: bytes, data: bytes) -> Tuple[ParserState, bytes]:
        """Apply the bytes of a generated token, returning the new state and incomplete character."""
        buffer = pending + data
        index = 0
        length = len(buffer)
        while index < length:
            size = utf8_sequence_length(buffer[index])
            if size is None:
                return self.dead_state, b''
            if index + size > length:
                remaining = buffer[index:]
                if not characters_starting_with(remaining):
                    return self.dead_state, b''
                return state, remaining
            character = decode_character(buffer[index:index + size])
            if character is None:
                return self.dead_state, b''
            next_state = self.step(state, character)
            if next_state is None:
                return self.dead_state, b''
            state = next_state
            index += size
        return state, b''

    # Mask computation

    def allowed_tokens(self, state: ParserState, pending: bytes) -> TokenList:
        cached = state.mask.get(pending)
        if cached is not None:
            return cached
        tokens: List[int] = []
        if not pending:
            tokens.extend(self.index.empty_tokens)
            self._collect(self.index.root, state, tokens)
            if state.can_end:
                tokens.extend(self.eos_token_ids)
        else:
            if state.can_start_character(pending):
                tokens.extend(self.index.empty_tokens)
            self._collect_continuations(state, pending, tokens)
        mask = TokenList(self.use_bitmask, self.vocab_size)
        mask.extend(sorted(set(tokens)) if self._eos_in_vocabulary else sorted(tokens))
        self._cached_mask_size += len(tokens)
        if self._cached_mask_size > self.MAX_CACHED_MASK_TOKENS:
            self._forget_masks()
        state.mask[pending] = mask
        return mask

    def _forget_masks(self) -> None:
        for state in self.states.values():
            state.mask.clear()
        self._cached_mask_size = 0

    def _collect(self, node: ByteTokenNode, state: ParserState, tokens: List[int]) -> None:
        """Collect the allowed tokens of the subtree, starting at a character boundary."""
        pending_nodes = [(node, state)]
        while pending_nodes:
            node, state = pending_nodes.pop()
            if node.tokens:
                tokens.extend(node.tokens)
            if node.partial_tokens:
                for partial, partial_tokens in node.partial_tokens.items():
                    if state.can_start_character(partial):
                        tokens.extend(partial_tokens)
            children = node.children
            if children:
                transitions = state.transitions
                for character, child in children.items():
                    next_state = transitions.get(character, _MISSING)
                    if next_state is _MISSING:
                        next_state = self.step(state, character)
                    if next_state is not None:
                        pending_nodes.append((child, next_state))

    def _collect_continuations(self, state: ParserState, pending: bytes, tokens: List[int]) -> None:
        """Collect the allowed tokens while the output ends inside a character."""
        size = utf8_sequence_length(pending[0])
        if size is None:
            return
        missing = size - len(pending)
        if missing <= 0:
            return
        for length in range(1, min(missing, 3) + 1):
            for continuation, node in self.index.continuations_by_length[length]:
                combined = pending + continuation
                if length < missing:
                    # The character is still incomplete, so the token can only be these bytes.
                    if node.tokens and state.can_start_character(combined):
                        tokens.extend(node.tokens)
                    continue
                character = decode_character(combined)
                if character is None:
                    continue
                next_state = self.step(state, character)
                if next_state is not None:
                    self._collect(node, next_state, tokens)

    # State keys

    def state_key(self, parser: CharacterLevelParser) -> Hashable:
        """A key that stands for everything about a parser state that affects what follows."""
        parser_type = type(parser)
        if parser_type is RegexParser:
            return ('regex', fsm_info(parser.context.pattern).serial, parser.current_state)
        if parser_type is JsonSchemaParser:
            return self._json_schema_key(parser)
        if parser_type is UnionParser:
            return ('union', frozenset(self.state_key(option) for option in parser.parsers))
        if parser_type is SequenceParser:
            return ('sequence', tuple(self.state_key(option) for option in parser.parsers))
        if parser_type is StringParser:
            return ('literal', parser.target_str)
        if parser_type is ForceStopParser:
            return ('stop', parser.allow_whitespace)
        if parser_type is JsonStringValueParser:
            return parser.byte_state_key()
        if parser_type is StringParsingState:
            return self._string_state_key(parser)
        if parser_type is ObjectParsingState:
            return ('object', self._identity(parser.schema_object), parser.current_stage,
                    frozenset(parser.existing_keys), parser.is_dictionary)
        if parser_type is ListParsingState:
            return ('list', self._identity(parser.list_member_type), parser.num_items_seen,
                    parser.seen_list_opener, parser.seen_list_closer, parser.min_items, parser.max_items)
        if parser_type is NumberParsingState:
            parsed = parser.parsed_string
            return ('number', parser.allow_floating_point, parsed[:2], parsed[-1:], min(len(parsed), 3),
                    parser.seen_decimal_point, parser.seen_whitespace_after_digits, parser.seen_exponent,
                    parser.seen_digit)
        # Unknown parsers (including subclasses of the known ones) get a state of their own.
        return (parser_type.__name__, self._identity(parser))

    def _json_schema_key(self, parser: JsonSchemaParser) -> Hashable:
        stack = parser.object_stack
        last_parsed_string = parser.last_parsed_string if _awaits_key_value_separator(stack) else None
        if _contains_list_state(stack):
            after_list_opener = parser.last_non_whitespace_character == '['
        else:
            after_list_opener = None
        return ('json',
                tuple(self.state_key(element) for element in stack),
                min(parser.num_consecutive_whitespaces, parser.config.max_consecutive_whitespaces),
                last_parsed_string,
                after_list_opener)

    def _string_state_key(self, parser: StringParsingState) -> Hashable:
        if parser.allowed_strings:
            parsed: Hashable = parser.parsed_string
        elif parser.regex_parser is not None:
            parsed = ('regex', parser.regex_parser.current_state, bool(parser.parsed_string))
        else:
            # Only the length matters, and only up to the point where the limits stop changing.
            interesting = max(parser.min_length or 0, parser.max_length or 0)
            parsed = ('length', min(len(parser.parsed_string), interesting), bool(parser.parsed_string))
        return ('string_state',
                frozenset(parser.allowed_strings) if parser.allowed_strings else None,
                parsed,
                parser.seen_opening_quote,
                parser.seen_closing_quote,
                parser.require_opening_quote,
                parser.require_closing_quote,
                parser.min_length,
                parser.max_length)
