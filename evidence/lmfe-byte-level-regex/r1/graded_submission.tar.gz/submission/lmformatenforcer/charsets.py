"""Sets of unicode scalar values, stored as sorted code point ranges.

The byte level token enforcer needs to talk about sets like "every character except a
comma", which cannot be represented as a string of allowed characters without listing a
million code points. A `CharSet` holds the same information as a few integer ranges, and
also knows which code points can start / continue a UTF-8 byte sequence, which is what
decides whether a token that ends in the middle of a character is allowed.
"""
from bisect import bisect_right
from typing import Dict, Iterable, List, Optional, Tuple

MAX_CODE_POINT = 0x10FFFF
_SURROGATE_FIRST = 0xD800
_SURROGATE_LAST = 0xDFFF
_UTF8_LENGTH_RANGES = {1: (0x0, 0x7F), 2: (0x80, 0x7FF), 3: (0x800, 0xFFFF), 4: (0x10000, MAX_CODE_POINT)}
_SMALL_SET_SIZE = 256
"""Up to this many code points, a CharSet also keeps a python set for fast lookups."""


def _normalize(ranges: Iterable[Tuple[int, int]]) -> Tuple[Tuple[int, int], ...]:
    """Sort, clip and merge (first, last) code point ranges."""
    clipped = []
    for first, last in ranges:
        first = max(first, 0)
        last = min(last, MAX_CODE_POINT)
        if first <= last:
            clipped.append((first, last))
    if not clipped:
        return ()
    clipped.sort()
    merged: List[List[int]] = [list(clipped[0])]
    for first, last in clipped[1:]:
        if first <= merged[-1][1] + 1:
            if last > merged[-1][1]:
                merged[-1][1] = last
        else:
            merged.append([first, last])
    return tuple((first, last) for first, last in merged)


class CharSet:
    """An immutable set of unicode scalar values."""

    __slots__ = ('ranges', '_firsts', '_size', '_members', '_string')

    def __init__(self, ranges: Tuple[Tuple[int, int], ...]):
        self.ranges = ranges
        self._firsts = [first for first, _ in ranges]
        self._size = sum(last - first + 1 for first, last in ranges)
        self._members: Optional[frozenset] = None
        self._string: Optional[str] = None
        if self._size <= _SMALL_SET_SIZE:
            self._members = frozenset(
                chr(code_point) for first, last in ranges for code_point in range(first, last + 1))

    @staticmethod
    def from_ranges(ranges: Iterable[Tuple[int, int]]) -> 'CharSet':
        return CharSet(_normalize(ranges))

    @staticmethod
    def from_chars(characters: Iterable[str]) -> 'CharSet':
        code_points = set()
        for character in characters:
            for single in character:
                code_points.add(ord(single))
        return CharSet(_normalize((code_point, code_point) for code_point in code_points))

    def __bool__(self) -> bool:
        return bool(self.ranges)

    def __len__(self) -> int:
        return self._size

    def __contains__(self, character: str) -> bool:
        members = self._members
        if members is not None:
            return character in members
        return self.contains_code_point(ord(character))

    def contains_code_point(self, code_point: int) -> bool:
        index = bisect_right(self._firsts, code_point) - 1
        return index >= 0 and code_point <= self.ranges[index][1]

    def intersects_range(self, first: int, last: int) -> bool:
        if first > last:
            return False
        index = bisect_right(self._firsts, last) - 1
        return index >= 0 and self.ranges[index][1] >= first

    def union(self, other: 'CharSet') -> 'CharSet':
        if not self.ranges:
            return other
        if not other.ranges:
            return self
        return CharSet(_normalize(self.ranges + other.ranges))

    def intersection(self, other: 'CharSet') -> 'CharSet':
        if not self.ranges or not other.ranges:
            return EMPTY_CHAR_SET
        result = []
        for first, last in self.ranges:
            index = max(bisect_right(other._firsts, first) - 1, 0)
            for other_first, other_last in other.ranges[index:]:
                if other_first > last:
                    break
                overlap_first = max(first, other_first)
                overlap_last = min(last, other_last)
                if overlap_first <= overlap_last:
                    result.append((overlap_first, overlap_last))
        return CharSet(tuple(result))

    def difference(self, other: 'CharSet') -> 'CharSet':
        if not self.ranges or not other.ranges:
            return self
        result = []
        for first, last in self.ranges:
            cursor = first
            index = max(bisect_right(other._firsts, first) - 1, 0)
            for other_first, other_last in other.ranges[index:]:
                if other_first > last:
                    break
                if other_last < cursor:
                    continue
                if other_first > cursor:
                    result.append((cursor, other_first - 1))
                cursor = max(cursor, other_last + 1)
                if cursor > last:
                    break
            if cursor <= last:
                result.append((cursor, last))
        return CharSet(tuple(result))

    def clip(self, first: int, last: int) -> 'CharSet':
        """The part of the set inside the (inclusive) code point range."""
        return self.intersection(CharSet(((first, last),)))

    def to_string(self) -> str:
        """The set as a string of allowed characters, as CharacterLevelParser expects."""
        if self._string is None:
            self._string = "".join(
                chr(code_point) for first, last in self.ranges for code_point in range(first, last + 1))
        return self._string

    def __repr__(self) -> str:
        parts = ", ".join(f"{first:04X}-{last:04X}" if first != last else f"{first:04X}"
                          for first, last in self.ranges[:8])
        suffix = ", ..." if len(self.ranges) > 8 else ""
        return f"CharSet({parts}{suffix})"


EMPTY_CHAR_SET = CharSet(())
SURROGATES = CharSet(((_SURROGATE_FIRST, _SURROGATE_LAST),))
ALL_CHARACTERS = CharSet(((0, _SURROGATE_FIRST - 1), (_SURROGATE_LAST + 1, MAX_CODE_POINT)))
"""Every unicode scalar value."""


def char_set(characters: str) -> CharSet:
    return CharSet.from_chars(characters)


def utf8_sequence_length(first_byte: int) -> Optional[int]:
    """How many bytes a UTF-8 character starting with this byte has, or None if it cannot start one."""
    if first_byte < 0x80:
        return 1
    if first_byte < 0xC0:
        return None  # Continuation byte
    if first_byte < 0xE0:
        return 2
    if first_byte < 0xF0:
        return 3
    if first_byte < 0xF8:
        return 4
    return None


_prefix_cache: Dict[bytes, CharSet] = {}


def characters_starting_with(prefix: bytes) -> CharSet:
    """Every scalar value whose UTF-8 encoding starts with `prefix` (which must be incomplete)."""
    cached = _prefix_cache.get(prefix)
    if cached is not None:
        return cached
    result = _characters_starting_with(prefix)
    _prefix_cache[prefix] = result
    return result


def _characters_starting_with(prefix: bytes) -> CharSet:
    if not prefix:
        return ALL_CHARACTERS
    length = utf8_sequence_length(prefix[0])
    if length is None or len(prefix) > length:
        return EMPTY_CHAR_SET
    if length == 1:
        return CharSet(((prefix[0], prefix[0]),))
    bits = prefix[0] & (0x1F if length == 2 else 0x0F if length == 3 else 0x07)
    for byte in prefix[1:]:
        if not 0x80 <= byte < 0xC0:
            return EMPTY_CHAR_SET
        bits = (bits << 6) | (byte & 0x3F)
    missing_bits = 6 * (length - len(prefix))
    first = bits << missing_bits
    last = first | ((1 << missing_bits) - 1)
    valid_first, valid_last = _UTF8_LENGTH_RANGES[length]
    return CharSet.from_ranges(((max(first, valid_first), min(last, valid_last)),)).difference(SURROGATES)


def decode_character(data: bytes) -> Optional[str]:
    """The single character encoded by `data`, or None if it is not exactly one valid character."""
    try:
        decoded = data.decode('utf-8')
    except UnicodeDecodeError:
        return None
    return decoded if len(decoded) == 1 else None


def split_token_bytes(data: bytes) -> Optional[Tuple[bytes, str, bytes]]:
    """Split token bytes into (continuation bytes, whole characters, trailing partial character).

    Returns None if the bytes can never appear in a strict UTF-8 prefix, no matter what came
    before them: a leading run of continuation bytes longer than any character needs, an
    invalid byte, an overlong or surrogate encoding, or a trailing piece that cannot be
    completed into a character.
    """
    index = 0
    while index < len(data) and 0x80 <= data[index] < 0xC0:
        index += 1
    lead = data[:index]
    if len(lead) > 3:
        return None
    characters: List[str] = []
    while index < len(data):
        length = utf8_sequence_length(data[index])
        if length is None:
            return None
        chunk = data[index:index + length]
        if len(chunk) < length:
            if not characters_starting_with(chunk):
                return None
            return lead, "".join(characters), chunk
        character = decode_character(chunk)
        if character is None:
            return None
        characters.append(character)
        index += length
    return lead, "".join(characters), b''


def code_units_for_characters(allowed: CharSet) -> CharSet:
    """The UTF-16 code units a `\\uXXXX` escape may encode so that the character it starts is allowed.

    Non surrogate code units stand for themselves; a high surrogate is allowed when some low
    surrogate completes it into an allowed supplementary character.
    """
    ranges: List[Tuple[int, int]] = list(allowed.clip(0, 0xFFFF).ranges)
    for first, last in allowed.ranges:
        if last < 0x10000:
            continue
        first = max(first, 0x10000)
        ranges.append((_SURROGATE_FIRST + ((first - 0x10000) >> 10),
                       _SURROGATE_FIRST + ((last - 0x10000) >> 10)))
    return CharSet.from_ranges(ranges)


def low_surrogates_for_high(allowed: CharSet, high_surrogate: int) -> CharSet:
    """The low surrogates that complete `high_surrogate` into a character in `allowed`."""
    base = 0x10000 + ((high_surrogate - _SURROGATE_FIRST) << 10)
    block = allowed.clip(base, base + 0x3FF)
    return CharSet.from_ranges((0xDC00 + first - base, 0xDC00 + last - base) for first, last in block.ranges)


_HEX_DIGITS = '0123456789abcdefABCDEF'
_HEX_VALUES = {digit: int(digit, 16) for digit in _HEX_DIGITS}


def hex_digit_value(digit: str) -> int:
    return _HEX_VALUES[digit]


def allowed_hex_digits(targets: CharSet, digits_so_far: int, value_so_far: int) -> CharSet:
    """Which hex digits may come next in a four digit escape whose value must land in `targets`."""
    if not targets:
        return EMPTY_CHAR_SET
    missing_bits = 4 * (4 - digits_so_far - 1)
    allowed = []
    for digit in '0123456789abcdef':
        candidate = (value_so_far << 4) | _HEX_VALUES[digit]
        first = candidate << missing_bits
        if targets.intersects_range(first, first | ((1 << missing_bits) - 1)):
            allowed.append(digit)
            if digit.isalpha():
                allowed.append(digit.upper())
    return CharSet.from_chars(allowed)
