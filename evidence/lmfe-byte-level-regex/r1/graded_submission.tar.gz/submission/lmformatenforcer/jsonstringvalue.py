"""JSON string values for the byte level token enforcer.

A string value in a JSON document is written with JSON's own string syntax: raw characters,
short escapes and `\\uXXXX` escapes, with supplementary characters written as surrogate
pairs. The schema constraints (`enum`, `const`, `pattern`, `minLength`, `maxLength`) apply to
the *decoded* value, so `"\\u6771\\u4eac"` and `"東京"` are the same value. This module
implements that: the parser tracks where it is in the JSON string syntax while the constraint
objects track the decoded value, and a character is allowed exactly when some completion of
the value satisfies the constraint.
"""
from typing import Dict, Hashable, Optional, Sequence, Tuple

from .charsets import (ALL_CHARACTERS, EMPTY_CHAR_SET, CharSet, allowed_hex_digits, char_set,
                       code_units_for_characters, hex_digit_value, low_surrogates_for_high)
from .characterlevelparser import CharacterLevelParser
from .consts import WHITESPACE_CHARACTERS
from .exceptions import LMFormatEnforcerException
from .regexfsm import RegexFsmInfo, fsm_info
from .regexparser import RegexParser

SHORT_ESCAPES = {'"': '"', '\\': '\\', '/': '/', 'b': '\b', 'f': '\f', 'n': '\n', 'r': '\r', 't': '\t'}

_WHITESPACE = char_set(WHITESPACE_CHARACTERS)
_QUOTE_OR_WHITESPACE = char_set('"' + WHITESPACE_CHARACTERS)
_QUOTE = char_set('"')
_BACKSLASH = char_set('\\')
_UNICODE_ESCAPE_LETTER = char_set('u')
_NOT_RAW = char_set('"\\').union(CharSet(((0x00, 0x1F),)))
"""Characters that a JSON string cannot contain as themselves."""

_BEFORE_QUOTE, _INSIDE, _AFTER_QUOTE = 0, 1, 2
_AFTER_BACKSLASH, _IN_UNICODE, _AFTER_HIGH, _AFTER_HIGH_BACKSLASH, _IN_LOW_UNICODE = 1, 2, 3, 4, 5


class StringValueConstraint:
    """A constraint on the decoded characters of a JSON string value."""

    key: Hashable

    def initial_state(self) -> Hashable:
        raise NotImplementedError()

    def viable_characters(self, state) -> CharSet:
        """The characters that may be appended to the decoded value so far."""
        raise NotImplementedError()

    def feed(self, state, character: str):
        raise NotImplementedError()

    def can_close(self, state) -> bool:
        """Whether the decoded value so far is a complete value."""
        raise NotImplementedError()

    def state_key(self, state) -> Hashable:
        return state


class FreeTextConstraint(StringValueConstraint):
    """Any text, optionally with a minimum and maximum number of decoded characters."""

    def __init__(self, min_length: Optional[int], max_length: Optional[int]):
        self.min_length = min_length or 0
        self.max_length = max_length
        self.key = ('free', self.min_length, self.max_length)
        # Past this length the state no longer changes what is allowed, so states can be shared.
        self._interesting_length = max(self.min_length, self.max_length or 0)

    def initial_state(self) -> int:
        return 0

    def viable_characters(self, state: int) -> CharSet:
        if self.max_length is not None and state >= self.max_length:
            return EMPTY_CHAR_SET
        return ALL_CHARACTERS

    def feed(self, state: int, character: str) -> int:
        return state + 1

    def can_close(self, state: int) -> bool:
        return state >= self.min_length

    def state_key(self, state: int) -> Hashable:
        return min(state, self._interesting_length)


class EnumConstraint(StringValueConstraint):
    """One of a list of exact values, as `enum` and `const` require."""

    def __init__(self, values: Sequence[str]):
        self.values = tuple(sorted(set(values)))
        self.key = ('enum', self.values)

    def initial_state(self) -> Tuple[str, ...]:
        return self.values

    def viable_characters(self, state: Tuple[str, ...]) -> CharSet:
        return CharSet.from_chars(suffix[0] for suffix in state if suffix)

    def feed(self, state: Tuple[str, ...], character: str) -> Tuple[str, ...]:
        return tuple(suffix[1:] for suffix in state if suffix[:1] == character)

    def can_close(self, state: Tuple[str, ...]) -> bool:
        return '' in state


class PatternConstraint(StringValueConstraint):
    """A value that the pattern must match in full."""

    def __init__(self, info: RegexFsmInfo, pattern: str):
        self.info = info
        self.key = ('pattern', pattern)

    def initial_state(self) -> int:
        return self.info.fsm.initial

    def viable_characters(self, state: int) -> CharSet:
        return self.info.allowed_characters(state)

    def feed(self, state: int, character: str) -> int:
        next_state = self.info.step(state, character)
        return _DEAD_PATTERN_STATE if next_state is None else next_state

    def can_close(self, state: int) -> bool:
        return self.info.can_end(state)


_DEAD_PATTERN_STATE = -2


_constraints: Dict[Hashable, StringValueConstraint] = {}


def _intern(constraint: StringValueConstraint) -> StringValueConstraint:
    """Share constraints with equal keys, so that equal parser states compare equal."""
    return _constraints.setdefault(constraint.key, constraint)


def make_constraint(allowed_strings: Optional[Sequence[str]],
                    min_length: Optional[int],
                    max_length: Optional[int],
                    pattern: Optional[str],
                    pattern_fsm_owner: Optional[CharacterLevelParser] = None) -> StringValueConstraint:
    if allowed_strings:
        return _intern(EnumConstraint(allowed_strings))
    if pattern:
        if min_length or max_length:
            raise LMFormatEnforcerException(
                "String schema contains both a pattern and a min/max length, which is not currently supported")
        # We implicitly match the entire value, so leading ^ and trailing $ are redundant.
        stripped = pattern[1:] if pattern.startswith('^') else pattern
        if stripped.endswith('$'):
            stripped = stripped[:-1]
        existing = _constraints.get(('pattern', stripped))
        if existing is not None:
            return existing  # Building the state machine of a pattern is not cheap
        regex_parser = RegexParser(stripped)
        return _intern(PatternConstraint(fsm_info(regex_parser.context.pattern), stripped))
    return _intern(FreeTextConstraint(min_length, max_length))


class JsonStringValueParser(CharacterLevelParser):
    """A JSON string value, parsed with JSON's string syntax and constrained after decoding."""

    def __init__(self,
                 constraint: StringValueConstraint,
                 require_opening_quote: bool = True,
                 require_closing_quote: bool = True,
                 stage: int = _BEFORE_QUOTE,
                 constraint_state=None,
                 escape: Optional[tuple] = None):
        super().__init__()
        self.constraint = constraint
        self.require_opening_quote = require_opening_quote
        self.require_closing_quote = require_closing_quote
        self.stage = _INSIDE if not require_opening_quote and stage == _BEFORE_QUOTE else stage
        self.constraint_state = constraint.initial_state() if constraint_state is None else constraint_state
        self.escape = escape
        self._allowed: Optional[CharSet] = None

    def _derive(self, stage: Optional[int] = None, constraint_state=None, escape: Optional[tuple] = None,
                keep_escape: bool = False) -> 'JsonStringValueParser':
        return JsonStringValueParser(
            self.constraint,
            self.require_opening_quote,
            self.require_closing_quote,
            self.stage if stage is None else stage,
            self.constraint_state if constraint_state is None else constraint_state,
            self.escape if keep_escape else escape)

    def byte_allowed_characters(self) -> CharSet:
        """The JSON source characters that may come next."""
        if self._allowed is None:
            self._allowed = self._compute_allowed()
        return self._allowed

    def _compute_allowed(self) -> CharSet:
        if self.stage == _BEFORE_QUOTE:
            return _QUOTE_OR_WHITESPACE
        if self.stage == _AFTER_QUOTE:
            return _WHITESPACE
        constraint, state = self.constraint, self.constraint_state
        viable = constraint.viable_characters(state)
        escape = self.escape
        if escape is None:
            allowed = viable.difference(_NOT_RAW)
            if viable:
                allowed = allowed.union(_BACKSLASH)
            if constraint.can_close(state):
                allowed = allowed.union(_QUOTE)
            return allowed
        kind = escape[0]
        if kind == _AFTER_BACKSLASH:
            letters = [letter for letter, decoded in SHORT_ESCAPES.items() if decoded in viable]
            if viable:
                letters.append('u')
            return CharSet.from_chars(letters)
        if kind == _IN_UNICODE:
            return allowed_hex_digits(code_units_for_characters(viable), escape[1], escape[2])
        if kind == _AFTER_HIGH:
            return _BACKSLASH
        if kind == _AFTER_HIGH_BACKSLASH:
            return _UNICODE_ESCAPE_LETTER
        return allowed_hex_digits(low_surrogates_for_high(viable, escape[1]), escape[2], escape[3])

    def byte_advance(self, character: str) -> 'JsonStringValueParser':
        """The state after `character`, which must be in byte_allowed_characters()."""
        if self.stage == _BEFORE_QUOTE:
            return self._derive(stage=_INSIDE) if character == '"' else self
        if self.stage == _AFTER_QUOTE:
            return self
        escape = self.escape
        if escape is None:
            if character == '"':
                return self._derive(stage=_AFTER_QUOTE)
            if character == '\\':
                return self._derive(escape=(_AFTER_BACKSLASH,))
            return self._decoded(character)
        kind = escape[0]
        if kind == _AFTER_BACKSLASH:
            if character == 'u':
                return self._derive(escape=(_IN_UNICODE, 0, 0))
            return self._decoded(SHORT_ESCAPES[character])
        if kind == _IN_UNICODE:
            digits = escape[1] + 1
            value = (escape[2] << 4) | hex_digit_value(character)
            if digits < 4:
                return self._derive(escape=(_IN_UNICODE, digits, value))
            if 0xD800 <= value <= 0xDBFF:
                return self._derive(escape=(_AFTER_HIGH, value))
            return self._decoded(chr(value))
        if kind == _AFTER_HIGH:
            return self._derive(escape=(_AFTER_HIGH_BACKSLASH, escape[1]))
        if kind == _AFTER_HIGH_BACKSLASH:
            return self._derive(escape=(_IN_LOW_UNICODE, escape[1], 0, 0))
        digits = escape[2] + 1
        value = (escape[3] << 4) | hex_digit_value(character)
        if digits < 4:
            return self._derive(escape=(_IN_LOW_UNICODE, escape[1], digits, value))
        return self._decoded(chr(0x10000 + ((escape[1] - 0xD800) << 10) + (value - 0xDC00)))

    def _decoded(self, character: str) -> 'JsonStringValueParser':
        return self._derive(constraint_state=self.constraint.feed(self.constraint_state, character), escape=None)

    def byte_state_key(self) -> Hashable:
        if self.stage != _INSIDE:
            return ('json_string', self.constraint.key, self.stage, self.require_closing_quote)
        return ('json_string', self.constraint.key, self.stage, self.require_closing_quote,
                self.constraint.state_key(self.constraint_state), self.escape)

    def can_end(self) -> bool:
        if self.require_closing_quote:
            return self.stage == _AFTER_QUOTE
        if self.stage == _AFTER_QUOTE:
            return True
        return self.stage == _INSIDE and self.escape is None and self.constraint.can_close(self.constraint_state)

    def get_allowed_characters(self) -> str:
        return self.byte_allowed_characters().to_string()

    def add_character(self, new_character: str) -> CharacterLevelParser:
        if new_character not in self.byte_allowed_characters():
            raise ValueError(f"Character '{new_character}' is not allowed in this JSON string value")
        return self.byte_advance(new_character)

    def __repr__(self) -> str:
        return (f"JsonStringValueParser({self.constraint.key}, stage={self.stage}, "
                f"state={self.constraint_state!r}, escape={self.escape!r})")
