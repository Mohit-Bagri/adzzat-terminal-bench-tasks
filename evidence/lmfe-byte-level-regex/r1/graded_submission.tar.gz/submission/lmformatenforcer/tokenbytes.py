"""The exact bytes of every token of a `tokenizers.Tokenizer` vocabulary.

`TokenEnforcerTokenizerData(..., token_bytes=...)` needs to know which bytes each token adds
to the generated output. Decoding tokens one by one does not answer that for byte level
vocabularies, because a token can hold a part of a character, which decodes to a replacement
character. The two vocabulary families below write the bytes in their pieces instead, so the
bytes can be read back from the vocabulary:

* byte level BPE (GPT-2 style), where every byte is written as one printable character, and
* BPE with byte fallback (SentencePiece style), where bytes that are not valid UTF-8 on their
  own are written as `<0xNN>` pieces and `▁` stands for a space.
"""
import json
from functools import lru_cache
from typing import Any, Dict, List, Set

_BYTE_FALLBACK_PREFIX = '<0x'
_SENTENCEPIECE_SPACE = '▁'


@lru_cache(maxsize=1)
def byte_to_unicode() -> Dict[int, str]:
    """The byte level BPE table: one printable character per byte value."""
    printable = (list(range(ord('!'), ord('~') + 1)) + list(range(ord('¡'), ord('¬') + 1)) +
                 list(range(ord('®'), ord('ÿ') + 1)))
    code_points = list(printable)
    extra = 0
    for byte in range(256):
        if byte not in printable:
            printable.append(byte)
            code_points.append(256 + extra)
            extra += 1
    return {byte: chr(code_point) for byte, code_point in zip(printable, code_points)}


@lru_cache(maxsize=1)
def unicode_to_byte() -> Dict[str, int]:
    """The inverse of the byte level BPE table."""
    return {character: byte for byte, character in byte_to_unicode().items()}


def _tokenizer_config(tokenizer: Any) -> Dict[str, Any]:
    try:
        return json.loads(tokenizer.to_str())
    except Exception:
        return {}


def _decoder_types(decoder: Any) -> List[str]:
    """The names of the decoders in a (possibly nested) decoder description."""
    if isinstance(decoder, dict):
        types = [decoder['type']] if isinstance(decoder.get('type'), str) else []
        for key in ('decoders', 'sequence'):
            for inner in decoder.get(key) or []:
                types.extend(_decoder_types(inner))
        return types
    if decoder is None:
        return []
    # A decoder object from the tokenizers package.
    types = [type(decoder).__name__]
    for key in ('decoders', 'sequence'):
        for inner in getattr(decoder, key, None) or []:
            types.extend(_decoder_types(inner))
    return types


def _is_byte_level(config: Dict[str, Any], tokenizer: Any) -> bool:
    if 'decoder' in config:
        decoder_types = _decoder_types(config['decoder'])
    else:
        decoder_types = _decoder_types(getattr(tokenizer, 'decoder', None))
    if 'ByteLevel' in decoder_types:
        return True
    if decoder_types:
        return False
    # No decoder at all: a byte level pre tokenizer still means byte level pieces.
    pre_tokenizer = config.get('pre_tokenizer') if 'pre_tokenizer' in config \
        else getattr(tokenizer, 'pre_tokenizer', None)
    return 'ByteLevel' in _decoder_types(pre_tokenizer)


def _has_byte_fallback(config: Dict[str, Any]) -> bool:
    model = config.get('model') or {}
    return bool(model.get('byte_fallback'))


def _special_token_ids(tokenizer: Any, config: Dict[str, Any]) -> Set[int]:
    special: Set[int] = set()
    try:
        added = tokenizer.get_added_tokens_decoder()
    except Exception:
        added = None
    if added:
        for token_id, added_token in added.items():
            if getattr(added_token, 'special', False):
                special.add(int(token_id))
        return special
    for added_token in config.get('added_tokens') or []:
        if added_token.get('special'):
            special.add(int(added_token['id']))
    return special


def byte_fallback_piece_bytes(piece: str) -> bytes:
    """The bytes of one SentencePiece style piece."""
    if len(piece) == 6 and piece.startswith(_BYTE_FALLBACK_PREFIX) and piece.endswith('>'):
        try:
            return bytes([int(piece[3:5], 16)])
        except ValueError:
            pass
    return piece.replace(_SENTENCEPIECE_SPACE, ' ').encode('utf-8')


def byte_level_piece_bytes(piece: str) -> bytes:
    """The bytes of one byte level BPE piece."""
    table = unicode_to_byte()
    try:
        return bytes(table[character] for character in piece)
    except KeyError as error:
        raise ValueError(f"'{piece}' is not a byte level BPE token: {error} is not a byte") from error


def token_bytes_from_tokenizer(tokenizer: Any) -> Dict[int, bytes]:
    """The exact bytes that every regular token of `tokenizer` adds to the generated output.

    :param tokenizer: A `tokenizers.Tokenizer` of a byte level BPE vocabulary (its decoder is
    ByteLevel, alone or inside a Sequence) or of a SentencePiece style BPE vocabulary with byte
    fallback (its model sets byte_fallback).
    :return: A mapping from token id to bytes, for every token of the vocabulary except the
    special added tokens. It can be passed to TokenEnforcerTokenizerData as token_bytes.
    :raises ValueError: If the vocabulary is of any other kind.
    """
    config = _tokenizer_config(tokenizer)
    vocabulary: Dict[str, int] = tokenizer.get_vocab(with_added_tokens=False)
    special_token_ids = _special_token_ids(tokenizer, config)
    if _is_byte_level(config, tokenizer):
        piece_bytes = byte_level_piece_bytes
    elif _has_byte_fallback(config):
        piece_bytes = byte_fallback_piece_bytes
    else:
        raise ValueError(
            "Only byte level BPE vocabularies (ByteLevel decoder) and SentencePiece style BPE "
            "vocabularies with byte fallback are supported by token_bytes_from_tokenizer()")
    return {token_id: piece_bytes(piece)
            for piece, token_id in vocabulary.items() if token_id not in special_token_ids}
