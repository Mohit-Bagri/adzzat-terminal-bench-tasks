"""Code point range view over the finite state machine of a RegexParser.

`RegexParser.get_allowed_characters()` has to spell out every allowed character, so it can
only offer the characters of the configured alphabet. The byte level token enforcer instead
asks for the allowed code point *ranges* of an FSM state, which lets `.` and negated classes
mean every scalar value they describe. States from which no final state can be reached are
dropped, so a state is reachable here only if some full match continues from it.
"""
from typing import Dict, Optional

from interegular.fsm import FSM, anything_else

from .charsets import ALL_CHARACTERS, EMPTY_CHAR_SET, CharSet


class RegexFsmInfo:
    """Cached range level information about one interegular FSM."""

    _next_serial = 0

    def __init__(self, fsm: FSM):
        self.fsm = fsm
        self.serial = RegexFsmInfo._next_serial
        RegexFsmInfo._next_serial += 1
        self.finals = fsm.finals
        explicit = [symbol for symbol in fsm.alphabet.keys() if symbol != anything_else]
        self.anything_else_characters = ALL_CHARACTERS.difference(CharSet.from_chars(explicit))
        self.live_states = self._live_states(fsm)
        self._state_characters: Dict[int, CharSet] = {}

    @staticmethod
    def _live_states(fsm: FSM) -> frozenset:
        """The states from which some final state is reachable."""
        incoming: Dict[int, set] = {}
        for state, transitions in fsm.map.items():
            for destination in transitions.values():
                incoming.setdefault(destination, set()).add(state)
        live = set(fsm.finals)
        pending = list(fsm.finals)
        while pending:
            for previous in incoming.get(pending.pop(), ()):
                if previous not in live:
                    live.add(previous)
                    pending.append(previous)
        return frozenset(live)

    def allowed_characters(self, state: int) -> CharSet:
        """The characters that continue a full match from `state`."""
        if state not in self.live_states:
            return EMPTY_CHAR_SET
        cached = self._state_characters.get(state)
        if cached is not None:
            return cached
        fsm = self.fsm
        by_transition = fsm.alphabet.by_transition
        result = EMPTY_CHAR_SET
        singles = []
        for transition, destination in fsm.map.get(state, {}).items():
            if destination not in self.live_states:
                continue
            for symbol in by_transition[transition]:
                if symbol == anything_else:
                    result = result.union(self.anything_else_characters)
                else:
                    singles.append(symbol)
        if singles:
            result = result.union(CharSet.from_chars(singles))
        self._state_characters[state] = result
        return result

    def step(self, state: int, character: str) -> Optional[int]:
        """The state after `character`, or None if no full match continues through it."""
        transition = self.fsm.alphabet[character]
        if transition is None:
            return None
        destination = self.fsm.map.get(state, {}).get(transition)
        if destination is None or destination not in self.live_states:
            return None
        return destination

    def can_end(self, state: int) -> bool:
        return state in self.finals


_infos: Dict[int, RegexFsmInfo] = {}


def fsm_info(fsm: FSM) -> RegexFsmInfo:
    """The cached RegexFsmInfo of an FSM. The info keeps the FSM alive, so its id stays valid."""
    info = _infos.get(id(fsm))
    if info is None or info.fsm is not fsm:
        info = RegexFsmInfo(fsm)
        _infos[id(fsm)] = info
    return info
