"""
OpenAI Responses API Handler for Unified Guardrails

This module provides a class-based handler for OpenAI Responses API format.
The class methods can be overridden for custom behavior.

Pattern Overview:
-----------------
1. Extract text content from input/output (both string and list formats)
2. Create async tasks to apply guardrails to each text segment
3. Track mappings to know where each response belongs
4. Apply guardrail responses back to the original structure

Responses API Format:
---------------------
Input: Union[str, List[Dict]] where each dict has:
  - role: str
  - content: Union[str, List[Dict]] (can have text items)
  - type: str (e.g., "message")

Output: response.output is List[GenericResponseOutputItem] where each has:
  - type: str (e.g., "message")
  - id: str
  - status: str
  - role: str
  - content: List[OutputText] where OutputText has:
    - type: str (e.g., "output_text")
    - text: str
"""

import copy
import time
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from itertools import accumulate, chain, repeat
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, NamedTuple, Union, cast

from pydantic import BaseModel, ConfigDict, TypeAdapter, ValidationError
from typing_extensions import ReadOnly, TypedDict

from litellm._logging import verbose_proxy_logger
from litellm.completion_extras.litellm_responses_transformation.transformation import (
    LiteLLMResponsesTransformationHandler,
    OpenAiResponsesToChatCompletionStreamIterator,
    tool_call_dict_from_output_item,
)
from litellm.llms.base_llm.guardrail_translation.base_translation import (
    BaseTranslation,
    StreamingScanKey,
    StreamTransformSink,
)
from litellm.llms.base_llm.guardrail_translation.utils import (
    blocked_responses_stream_usage,
    effective_skip_system_message_for_guardrail,
    merge_guardrailed_scoped_messages,
    role_out_of_guardrail_scope,
    scoped_structured_message_indices,
    stream_item_field,
    stream_item_fingerprint,
    stream_item_items,
    unappliable_request_rewrite,
)
from litellm.llms.openai.responses.guardrail_translation.tool_merge import merge_guardrailed_tools
from litellm.responses.litellm_completion_transformation.transformation import (
    LiteLLMCompletionResponsesConfig,
)
from litellm.types.llms.openai import (
    AllMessageValues,
    BaseLiteLLMOpenAIResponseObject,
    ChatCompletionToolCallChunk,
    ChatCompletionToolParam,
    ContentPartAddedEvent,
    ContentPartDoneEvent,
    ContentPartDonePartOutputText,
    ErrorEvent,
    ErrorEventError,
    OutputItemAddedEvent,
    OutputItemDoneEvent,
    OutputTextDeltaEvent,
    OutputTextDoneEvent,
    ResponseAPIUsage,
    ResponseCompletedEvent,
    ResponsesAPIOptionalRequestParams,
    ResponsesAPIResponse,
    ResponsesAPIStreamEvents,
    ResponsesAPIStreamingResponse,
)
from litellm.types.responses.main import (
    GenericResponseOutputItem,
    OutputText,
)
from litellm.types.utils import GenericGuardrailAPIInputs

if TYPE_CHECKING:
    from fastapi import HTTPException

    from litellm.integrations.custom_guardrail import (
        CustomGuardrail,
        ModifyResponseException,
    )
    from litellm.litellm_core_utils.litellm_logging import Logging as LiteLLMLoggingObj
    from litellm.proxy._types import UserAPIKeyAuth
    from litellm.types.llms.openai import ResponseInputParam


class _ToolCallShape(NamedTuple):
    name: str | None
    arguments: str


class _ToolCallFunctionFields(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str | None = None
    arguments: str = ""


class _ToolCallFields(BaseModel):
    model_config = ConfigDict(frozen=True)

    function: _ToolCallFunctionFields


def _tool_call_shapes(tool_calls: Sequence[ChatCompletionToolCallChunk]) -> tuple[_ToolCallShape, ...]:
    return tuple(
        _ToolCallShape(name=tool_call["function"].get("name"), arguments=tool_call["function"].get("arguments", ""))
        for tool_call in tool_calls
    )


def _returned_tool_call_shape(tool_call: object) -> _ToolCallShape | None:
    payload: Final = tool_call.model_dump() if isinstance(tool_call, BaseModel) else tool_call
    try:
        fields: Final = _ToolCallFields.model_validate(payload)
    except ValidationError:
        return None
    return _ToolCallShape(name=fields.function.name, arguments=fields.function.arguments)


def _post_guardrail_tool_call_shapes(
    returned_tool_calls: Sequence[object] | None,
    pre_guardrail_tool_calls: tuple[_ToolCallShape, ...],
    guardrail_name: str | None,
) -> tuple[_ToolCallShape, ...]:
    if not pre_guardrail_tool_calls:
        return pre_guardrail_tool_calls
    if returned_tool_calls is None or len(returned_tool_calls) != len(pre_guardrail_tool_calls):
        verbose_proxy_logger.warning(
            "OpenAI Responses API: guardrail %s returned %s tool calls for the %d scanned, "
            "leaving the tool call output items unchanged",
            guardrail_name,
            "no" if returned_tool_calls is None else len(returned_tool_calls),
            len(pre_guardrail_tool_calls),
        )
        return pre_guardrail_tool_calls
    returned_shapes: Final = tuple(_returned_tool_call_shape(tool_call) for tool_call in returned_tool_calls)
    validated_shapes: Final = tuple(shape for shape in returned_shapes if shape is not None)
    if len(validated_shapes) != len(returned_shapes):
        verbose_proxy_logger.warning(
            "OpenAI Responses API: guardrail %s returned tool calls without a function name and arguments, "
            "leaving the tool call output items unchanged",
            guardrail_name,
        )
        return pre_guardrail_tool_calls
    return validated_shapes


def _tool_call_rewrite(before: _ToolCallShape, after: _ToolCallShape) -> _ToolCallShape:
    return _ToolCallShape(name=after.name if after.name != before.name else None, arguments=after.arguments)


def _undeliverable_tool_call_rewrite_reason(
    call_ids: Sequence[str],
    tool_call_item_count: int,
    post_guardrail_tool_call_count: int,
    unresolved_argument_event: bool,
    rewritten_call_ids: frozenset[str],
    event_call_ids: frozenset[str],
) -> str | None:
    if len(call_ids) != tool_call_item_count:
        return (
            f"{tool_call_item_count - len(call_ids)} of the stream's {tool_call_item_count} tool call items "
            "carry no call_id"
        )
    if len(frozenset(call_ids)) != len(call_ids):
        return "the stream's tool call items repeat a call_id"
    if len(call_ids) != post_guardrail_tool_call_count:
        return (
            f"the guardrail returned {post_guardrail_tool_call_count} tool calls for the stream's "
            f"{len(call_ids)} tool call items"
        )
    if unresolved_argument_event:
        return "a tool call argument event names an item_id that no output_item event introduced"
    missing_call_ids: Final = sorted(rewritten_call_ids - event_call_ids)
    if missing_call_ids:
        return f"no stream event carries the rewritten call_id {', '.join(missing_call_ids)}"
    return None


class ResponseOutputEnvelope(TypedDict, total=False):
    """Dict form of a Responses API response, as far as guardrail write-back reads it."""

    output: ReadOnly[Sequence[object]]
    model: ReadOnly[str | None]


class ResponsesStreamChunk(TypedDict, total=False):
    """Responses API streaming event, as far as the accumulated-stream helpers read it."""

    type: ReadOnly[str]
    text: ReadOnly[str]
    delta: ReadOnly[str]
    item_id: ReadOnly[str]
    output_index: ReadOnly[int]
    content_index: ReadOnly[int]


_TERMINAL_ENVELOPE_EVENT_TYPES: Final = frozenset(
    {
        ResponsesAPIStreamEvents.RESPONSE_COMPLETED.value,
        ResponsesAPIStreamEvents.RESPONSE_FAILED.value,
        ResponsesAPIStreamEvents.RESPONSE_INCOMPLETE.value,
    }
)


_TOOL_CALL_ITEM_TYPES: Final = frozenset({"function_call", "custom_tool_call"})
_TOOL_CALL_PAYLOAD_FIELDS: Final[Mapping[str, str]] = MappingProxyType(
    {"function_call": "arguments", "custom_tool_call": "input"}
)
_TOOL_CALL_PAYLOAD_DELTA_EVENT_TYPES: Final = frozenset(
    {"response.function_call_arguments.delta", "response.custom_tool_call_input.delta"}
)
_TOOL_CALL_PAYLOAD_DONE_EVENT_FIELDS: Final[Mapping[str, str]] = MappingProxyType(
    {"response.function_call_arguments.done": "arguments", "response.custom_tool_call_input.done": "input"}
)
_TOOL_CALL_PAYLOAD_EVENT_TYPES: Final = _TOOL_CALL_PAYLOAD_DELTA_EVENT_TYPES | frozenset(
    _TOOL_CALL_PAYLOAD_DONE_EVENT_FIELDS
)
_OUTPUT_ITEM_EVENT_TYPES: Final = frozenset({"response.output_item.added", "response.output_item.done"})
_OUTPUT_TEXT_EVENT_TYPES: Final = frozenset({"response.output_text.delta", "response.output_text.done"})
_PATCHABLE_ITEM_FIELDS: Final[Mapping[str, str]] = MappingProxyType(
    {"function_call_output": "output", "custom_tool_call_output": "output", "message": "content"}
)

_EMPTY_RESPONSES_REQUEST: Final[ResponsesAPIOptionalRequestParams] = {}


def _item_rewrite_field(item: Mapping[str, object]) -> str | None:
    item_type: Final = item.get("type")
    if item_type is None:
        return "content" if "content" in item else None
    if not isinstance(item_type, str):
        return None
    return _PATCHABLE_ITEM_FIELDS.get(item_type)


def _rewritten_input_item(item: Mapping[str, object], rewritten: object) -> Mapping[str, object] | None:
    field: Final = _item_rewrite_field(item)
    if field is None or not isinstance(rewritten, Mapping):
        return None
    rewritten_content: Final = rewritten.get("content")
    if isinstance(item.get(field), str) and isinstance(rewritten_content, str):
        return {**item, field: rewritten_content}
    rewritten_row: Final = cast("AllMessageValues", rewritten)  # cast-ok: guardrails hand back chat-shaped rows
    converted_items, _ = LiteLLMResponsesTransformationHandler().convert_chat_completion_messages_to_responses_api(
        [rewritten_row]
    )
    if len(converted_items) != 1 or not isinstance(converted_items[0], Mapping):
        return None
    first_converted: Final = cast("Mapping[str, object]", converted_items[0])  # cast-ok: isinstance-checked above
    converted_value: Final = first_converted.get(field)
    if converted_value is None:
        return None
    return {**item, field: converted_value}


def _is_tool_call_item(item: object) -> bool:
    return isinstance(item, Mapping) and item.get("type") in _TOOL_CALL_ITEM_TYPES


def _tool_call_output_item_mapping(item: object) -> Mapping[str, object] | None:
    if stream_item_field(item, "type") not in _TOOL_CALL_ITEM_TYPES:
        return None
    if isinstance(item, Mapping):
        return cast("Mapping[str, object]", item)  # cast-ok: output items are str-keyed JSON objects
    return item.model_dump() if isinstance(item, BaseModel) else None


def _is_tool_call_output_item(item: object) -> bool:
    return _tool_call_output_item_mapping(item) is not None


def _released_tool_call_payload(responses_so_far: Sequence[object], item_id: object) -> str | None:
    events: Final = tuple(event for event in responses_so_far if stream_item_field(event, "item_id") == item_id)
    finished: Final = tuple(
        payload
        for event in events
        if isinstance(event_type := stream_item_field(event, "type"), str)
        and event_type in _TOOL_CALL_PAYLOAD_DONE_EVENT_FIELDS
        and isinstance(payload := stream_item_field(event, _TOOL_CALL_PAYLOAD_DONE_EVENT_FIELDS[event_type]), str)
    )
    if finished:
        return finished[-1]
    deltas: Final = tuple(
        delta
        for event in events
        if stream_item_field(event, "type") in _TOOL_CALL_PAYLOAD_DELTA_EVENT_TYPES
        and isinstance(delta := stream_item_field(event, "delta"), str)
    )
    return "".join(deltas) if deltas else None


def _with_released_payload(item: Mapping[str, object], responses_so_far: Sequence[object]) -> Mapping[str, object]:
    field: Final = _TOOL_CALL_PAYLOAD_FIELDS[str(item.get("type"))]
    payload: Final = _released_tool_call_payload(responses_so_far, item.get("id"))
    return item if payload is None else {**item, field: payload}


def _released_message_item(text: str) -> Mapping[str, object]:
    content: Final = [{"type": "output_text", "text": text}]
    return {"type": "message", "role": "assistant", "content": content}


def _released_tool_call_items(responses_so_far: Sequence[object]) -> tuple[Mapping[str, object], ...]:
    announced: Final = tuple(
        item
        for item in (
            _tool_call_output_item_mapping(stream_item_field(event, "item"))
            for event in responses_so_far
            if stream_item_field(event, "type") in _OUTPUT_ITEM_EVENT_TYPES
        )
        if item is not None
    )
    latest_by_id: Final = MappingProxyType({item.get("id"): item for item in announced})
    return tuple(_with_released_payload(item, responses_so_far) for item in latest_by_id.values())


def _last_message_role(messages: Sequence[object]) -> str | None:
    if not messages:
        return None
    last: Final = messages[-1]
    role: Final = last.get("role") if isinstance(last, Mapping) else getattr(last, "role", None)
    return role if isinstance(role, str) else None


def _provenance_unit_bounds(
    raw_input: Sequence[object],
    solo_conversions: Sequence[Sequence[object]],
) -> tuple[tuple[int, int], ...]:
    trailing_roles: Final = tuple(
        accumulate(
            (_last_message_role(messages) for messages in solo_conversions),
            lambda previous, current: current if current is not None else previous,
        )
    )
    start_indexes: Final = tuple(
        index
        for index in range(len(raw_input))
        if index == 0 or not (_is_tool_call_item(raw_input[index]) and trailing_roles[index - 1] == "assistant")
    )
    return tuple(zip(start_indexes, (*start_indexes[1:], len(raw_input))))


def _input_item_provenance(
    raw_input: Sequence[object],
    expected_messages: Sequence[object],
) -> tuple[Mapping[int, int], frozenset[int]] | None:
    if not all(isinstance(item, Mapping) for item in raw_input):
        return None
    solo_conversions: Final = tuple(
        LiteLLMCompletionResponsesConfig.transform_responses_api_input_to_messages(
            input=cast("ResponseInputParam", [item]),  # cast-ok: items checked as Mappings above
            responses_api_request=_EMPTY_RESPONSES_REQUEST,
        )
        for item in raw_input
    )
    full_conversion: Final = tuple(
        LiteLLMCompletionResponsesConfig.transform_responses_api_input_to_messages(
            input=cast("ResponseInputParam", list(raw_input)),  # cast-ok: items checked as Mappings above
            responses_api_request=_EMPTY_RESPONSES_REQUEST,
        )
    )
    if full_conversion != tuple(expected_messages):
        return None
    units: Final = _provenance_unit_bounds(raw_input, solo_conversions)
    unit_messages: Final = tuple(
        tuple(solo_conversions[start])
        if end - start == 1
        else tuple(
            LiteLLMCompletionResponsesConfig.transform_responses_api_input_to_messages(
                input=cast("ResponseInputParam", list(raw_input[start:end])),  # cast-ok: checked as Mappings above
                responses_api_request=_EMPTY_RESPONSES_REQUEST,
            )
        )
        for start, end in units
    )
    if tuple(message for messages in unit_messages for message in messages) != full_conversion:
        return None
    boundaries: Final = tuple(accumulate((len(messages) for messages in unit_messages), initial=0))
    item_for_message: Final = MappingProxyType(
        {
            message_index: start
            for unit_index, (start, end) in enumerate(units)
            if end - start == 1
            for message_index in range(boundaries[unit_index], boundaries[unit_index + 1])
        }
    )
    tainted: Final = frozenset(
        message_index
        for unit_index, (start, end) in enumerate(units)
        if end - start > 1
        for message_index in range(boundaries[unit_index], boundaries[unit_index + 1])
    )
    return item_for_message, tainted


class _RequestFields(NamedTuple):
    input: tuple[object, ...]
    instructions: str | None


class _ExtractedInputs(NamedTuple):
    inputs: GenericGuardrailAPIInputs
    task_mappings: tuple[tuple[int, int | None], ...]
    instructions: str | None


def scannable_instructions(data: Mapping[str, object], *, skip_system: bool = False) -> str | None:
    instructions: Final = data.get("instructions")
    return instructions if isinstance(instructions, str) and instructions and not skip_system else None


def _input_item_role(item: object) -> str:
    role: Final = item.get("role") if isinstance(item, Mapping) else None
    return role.lower() if isinstance(role, str) else ""


def _patched_request_fields(
    raw_input: object,
    instructions: object,
    original_messages: Sequence[object],
    structured_messages: Sequence[object],
) -> _RequestFields | None:
    if not isinstance(raw_input, list) or len(original_messages) != len(structured_messages):
        return None
    offset: Final = 1 if instructions else 0
    provenance: Final = _input_item_provenance(raw_input, tuple(original_messages)[offset:])
    if provenance is None:
        return None
    item_for_message, tainted = provenance
    changed: Final = tuple(
        (index, rewritten)
        for index, (original, rewritten) in enumerate(zip(original_messages, structured_messages))
        if original != rewritten
    )
    instruction_rewrites: Final = tuple(rewritten for index, rewritten in changed if index < offset)
    rewritten_instructions: Final = (
        instruction_rewrites[0].get("content")
        if instruction_rewrites and isinstance(instruction_rewrites[0], Mapping)
        else instructions
    )
    instructions_value: Final = rewritten_instructions if isinstance(rewritten_instructions, str) else None
    if rewritten_instructions is not None and instructions_value is None:
        return None
    body_changes: Final = tuple((index - offset, rewritten) for index, rewritten in changed if index >= offset)
    if any(message_index in tainted or message_index not in item_for_message for message_index, _ in body_changes):
        return None
    replacements: Final = MappingProxyType(
        {
            item_for_message[message_index]: _rewritten_input_item(
                cast("Mapping[str, object]", raw_input[item_for_message[message_index]]),  # cast-ok: checked Mappings
                rewritten,
            )
            for message_index, rewritten in body_changes
        }
    )
    if len(replacements) != len(body_changes) or any(item is None for item in replacements.values()):
        return None
    return _RequestFields(
        input=tuple(replacements.get(index, item) for index, item in enumerate(raw_input)),
        instructions=instructions_value,
    )


def _patch_or_convert_request_fields(
    raw_input: object,
    instructions: object,
    original_messages: Sequence[object],
    structured_messages: Sequence[AllMessageValues],
) -> _RequestFields | None:
    if not isinstance(structured_messages, list):
        return None
    patched: Final = _patched_request_fields(raw_input, instructions, original_messages, structured_messages)
    if patched is not None:
        return patched
    input_items, converted_instructions = (
        LiteLLMResponsesTransformationHandler().convert_chat_completion_messages_to_responses_api(structured_messages)
    )
    return _RequestFields(input=tuple(input_items), instructions=converted_instructions)


def _next_stream_sequence_number(responses_so_far: Sequence[object] | None) -> int:
    sequence_numbers: Final = (
        item.get("sequence_number") if isinstance(item, dict) else getattr(item, "sequence_number", None)
        for item in reversed(responses_so_far or ())
    )
    return next((n + 1 for n in sequence_numbers if isinstance(n, int)), 0)


class OpenAIResponsesHandler(BaseTranslation):
    """
    Handler for processing OpenAI Responses API with guardrails.

    This class provides methods to:
    1. Process input (pre-call hook)
    2. Process output response (post-call hook)

    Methods can be overridden to customize behavior for different message formats.
    """

    delivers_ended_stream_rewrites = True
    assembles_streamed_response = True

    def get_structured_messages(self, data: dict) -> list[AllMessageValues] | None:
        """
        Convert Responses API request data to OpenAI-spec structured messages.

        Transforms `input` (string or ResponseInputParam) and optional
        `instructions` into chat completion messages.
        """
        input_data: Final = data.get("input")
        if input_data is None:
            return None
        messages: Final = LiteLLMCompletionResponsesConfig.transform_responses_api_input_to_messages(
            input=input_data,
            responses_api_request=data,
        )
        return cast(list[AllMessageValues], messages) if messages else None

    async def process_input_messages(
        self,
        data: dict,
        guardrail_to_apply: "CustomGuardrail",
        litellm_logging_obj: "LiteLLMLoggingObj | None" = None,
    ) -> dict[str, object]:
        """
        Process input by applying guardrails to text content.

        Handles both string input and list of message objects.
        """
        input_data: Final[str | ResponseInputParam | None] = data.get("input")
        if not isinstance(input_data, (str, list)):
            return data
        skip_system: Final = effective_skip_system_message_for_guardrail(guardrail_to_apply)
        structured_messages: Final = self.get_structured_messages(data)
        scoped_indices: Final = scoped_structured_message_indices(
            structured_messages or [], scan_only_tool_results=False, skip_system=skip_system, skip_tool=False
        )
        scoped_structured_messages: Final = (
            [structured_messages[index] for index in scoped_indices] if structured_messages else None
        )
        raw_tools: Final = data.get("tools")
        original_tools: Final[tuple[Mapping[str, object], ...]] = (
            tuple(raw_tools) if isinstance(raw_tools, list) else ()
        )
        flattened_tool_groups: Final = tuple(
            form.chat_tools for form in LiteLLMCompletionResponsesConfig.responses_tools_to_chat_forms(original_tools)
        )
        extracted: Final = self._extract_guardrail_inputs(
            data, input_data, flattened_tool_groups, skip_system=skip_system
        )
        if not extracted.inputs.get("texts"):
            return data
        if scoped_structured_messages:
            extracted.inputs["structured_messages"] = scoped_structured_messages
        guardrailed_inputs: Final = await guardrail_to_apply.apply_guardrail(
            inputs=extracted.inputs,
            request_data=data,
            input_type="request",
            logging_obj=litellm_logging_obj,
        )
        self._apply_guardrailed_tools_to_data(
            data, original_tools, flattened_tool_groups, guardrailed_inputs.get("tools")
        )
        written_back: Final = self._written_back_request_fields(
            data,
            structured_messages or (),
            scoped_indices,
            scoped_structured_messages,
            guardrail_to_apply,
            guardrailed_inputs,
        )
        if written_back is not None:
            data["input"] = list(written_back.input)
            if written_back.instructions is None:
                data.pop("instructions", None)
            else:
                data["instructions"] = written_back.instructions  # rebind-ok: data is an out-param
        else:
            await self._apply_guardrailed_texts(data, input_data, extracted, guardrail_to_apply, guardrailed_inputs)
        verbose_proxy_logger.debug("OpenAI Responses API: Processed input messages: %s", data.get("input"))
        return data

    async def _apply_guardrailed_texts(
        self,
        data: dict[str, object],
        input_data: "str | ResponseInputParam",
        extracted: _ExtractedInputs,
        guardrail_to_apply: "CustomGuardrail",
        guardrailed_inputs: GenericGuardrailAPIInputs,
    ) -> None:
        returned_texts: Final = guardrailed_inputs.get("texts")
        if not returned_texts:
            return
        rewritten_texts: Final = tuple(returned_texts)
        offset: Final = 0 if extracted.instructions is None else 1
        input_texts: Final = rewritten_texts[offset:]
        expected: Final = 1 if isinstance(input_data, str) else len(extracted.task_mappings)
        if len(rewritten_texts) != offset + expected:
            raise unappliable_request_rewrite(guardrail_to_apply.guardrail_name)
        if offset:
            data["instructions"] = rewritten_texts[0]  # rebind-ok: data is an out-param
        if isinstance(input_data, str):
            data["input"] = input_texts[0]  # rebind-ok: data is an out-param
            return
        await self._apply_guardrail_responses_to_input(
            messages=input_data,
            responses=input_texts,
            task_mappings=extracted.task_mappings,
        )

    def _extract_guardrail_inputs(
        self,
        data: Mapping[str, object],
        input_data: "str | ResponseInputParam",
        flattened_tool_groups: Sequence[Sequence[Mapping[str, object]]],
        *,
        skip_system: bool = False,
    ) -> _ExtractedInputs:
        instructions: Final = scannable_instructions(data, skip_system=skip_system)
        texts_to_check: Final[list[str]] = [] if instructions is None else [instructions]
        images_to_check: Final[list[str]] = []
        task_mappings: Final[list[tuple[int, int | None]]] = []
        tools_to_check: Final[list[ChatCompletionToolParam]] = list(  # mutable-ok: guardrail inputs want a list
            copy.deepcopy(
                tuple(
                    cast(ChatCompletionToolParam, tool)  # cast-ok: mcp tools ride along in the guardrail's tool list
                    for group in flattened_tool_groups
                    for tool in group
                )
            )
        )
        if isinstance(input_data, str):
            texts_to_check.append(input_data)
        else:
            for msg_idx, message in enumerate(input_data):
                if role_out_of_guardrail_scope(
                    _input_item_role(message), skip_system_message=skip_system, skip_tool_message=False
                ):
                    continue
                self._extract_input_text_and_images(
                    message=message,
                    msg_idx=msg_idx,
                    texts_to_check=texts_to_check,
                    images_to_check=images_to_check,
                    task_mappings=task_mappings,
                )
        inputs: Final = GenericGuardrailAPIInputs(texts=texts_to_check)
        if images_to_check:
            inputs["images"] = images_to_check
        if tools_to_check:
            inputs["tools"] = tools_to_check
        model: Final = data.get("model")
        if isinstance(model, str):
            inputs["model"] = model
        return _ExtractedInputs(inputs=inputs, task_mappings=tuple(task_mappings), instructions=instructions)

    @staticmethod
    def _written_back_request_fields(
        data: Mapping[str, object],
        structured_messages: Sequence[AllMessageValues],
        scoped_indices: Sequence[int],
        scoped_structured_messages: Sequence[AllMessageValues] | None,
        guardrail_to_apply: "CustomGuardrail",
        guardrailed_inputs: GenericGuardrailAPIInputs,
    ) -> _RequestFields | None:
        guardrailed: Final = guardrailed_inputs.get("structured_messages")
        if guardrailed is None or guardrailed is scoped_structured_messages:
            return None
        covers_full_request: Final = len(scoped_indices) == len(structured_messages) or (
            guardrail_to_apply.structured_messages_cover_full_request() and len(guardrailed) == len(structured_messages)
        )
        merged: Final = (
            guardrailed
            if covers_full_request
            else merge_guardrailed_scoped_messages(
                full_messages=structured_messages, scoped_indices=scoped_indices, guardrailed_scoped=guardrailed
            )
        )
        return _patch_or_convert_request_fields(
            data.get("input"), data.get("instructions"), structured_messages, merged
        )

    def extract_request_tool_names(self, data: dict) -> list[str]:
        """Extract tool names from Responses API request (tools[].name for function
        and custom, tools[].server_label for mcp)."""
        names: Final[list[str]] = []
        for tool in data.get("tools") or []:
            if not isinstance(tool, dict):
                continue
            if tool.get("type") in ("function", "custom") and tool.get("name"):
                names.append(str(tool["name"]))
            elif tool.get("type") == "mcp" and tool.get("server_label"):
                names.append(str(tool["server_label"]))
        return names

    def _apply_guardrailed_tools_to_data(
        self,
        data: dict,
        original_tools: Sequence[Mapping[str, object]],
        flattened_tool_groups: Sequence[Sequence[Mapping[str, object]]],
        guardrailed_tools: Sequence[ChatCompletionToolParam] | None,
    ) -> None:
        if guardrailed_tools is None:
            return
        data["tools"] = list(  # rebind-ok: in-place request rewrite
            merge_guardrailed_tools(original_tools, flattened_tool_groups, guardrailed_tools)
        )

    def _extract_input_text_and_images(
        self,
        message: Mapping[str, object],
        msg_idx: int,
        texts_to_check: list[str],
        images_to_check: list[str],
        task_mappings: list[tuple[int, int | None]],
    ) -> None:
        """
        Extract text content and images from an input message.

        Override this method to customize text/image extraction logic.
        """
        content: Final = message.get("content", None)
        if content is None:
            return

        if isinstance(content, str):
            # Simple string content
            texts_to_check.append(content)
            task_mappings.append((msg_idx, None))

        elif isinstance(content, list):
            # List content (e.g., multimodal with text and images)
            for content_idx, content_item in enumerate(content):
                if isinstance(content_item, dict):
                    # Extract text
                    text_str = content_item.get("text", None)
                    if text_str is not None:
                        texts_to_check.append(text_str)
                        task_mappings.append((msg_idx, int(content_idx)))

                    # Extract images
                    if content_item.get("type") == "image_url":
                        image_url = content_item.get("image_url", {})
                        if isinstance(image_url, dict):
                            url = image_url.get("url")
                            if url:
                                images_to_check.append(url)

    async def _apply_guardrail_responses_to_input(
        self,
        messages: Any,  # Can be List[Dict[str, Any]] or ResponseInputParam
        responses: Sequence[str],
        task_mappings: Sequence[tuple[int, int | None]],
    ) -> None:
        """
        Apply guardrail responses back to input messages.

        ``responses`` pairs positionally with ``task_mappings``; the caller rejects
        the request when the two disagree, so this never has to guess an alignment.

        Override this method to customize how responses are applied.
        """
        for guardrail_response, mapping in zip(responses, task_mappings):
            msg_idx = cast(int, mapping[0])
            content_idx_optional = cast(int | None, mapping[1])

            content = messages[msg_idx].get("content", None)
            if content is None:
                continue

            if isinstance(content, str) and content_idx_optional is None:
                # Replace string content with guardrail response
                messages[msg_idx]["content"] = guardrail_response

            elif isinstance(content, list) and content_idx_optional is not None:
                # Replace specific text item in list content
                if isinstance(messages[msg_idx]["content"][content_idx_optional], dict):
                    messages[msg_idx]["content"][content_idx_optional]["text"] = guardrail_response

    async def process_output_response(
        self,
        response: Union["ResponsesAPIResponse", ResponseOutputEnvelope],
        guardrail_to_apply: "CustomGuardrail",
        litellm_logging_obj: "LiteLLMLoggingObj | None" = None,
        user_api_key_dict: "UserAPIKeyAuth | None" = None,
        request_data: dict | None = None,
    ) -> Union["ResponsesAPIResponse", ResponseOutputEnvelope]:
        """
        Process output response by applying guardrails to text content and tool calls.

        Args:
            response: LiteLLM ResponsesAPIResponse object
            guardrail_to_apply: The guardrail instance to apply
            litellm_logging_obj: Optional logging object
            user_api_key_dict: User API key metadata to pass to guardrails

        Returns:
            Modified response with guardrail applied to content

        Response Format Support:
            - response.output is a list of output items
            - Each output item can be:
              * GenericResponseOutputItem with a content list of OutputText objects
              * ResponseFunctionToolCall or CustomToolCallOutputItem with tool call data
            - Each OutputText object has a text field
        """

        texts_to_check: Final[list[str]] = []
        images_to_check: Final[list[str]] = []
        tool_calls_to_check: Final[list[ChatCompletionToolCallChunk]] = []
        task_mappings: Final[list[tuple[int, int]]] = []
        # Track (output_item_index, content_index) for each text

        # Handle both dict and Pydantic object responses
        response_output: Sequence[object]
        if isinstance(response, dict):
            response_output = response.get("output", [])
        elif hasattr(response, "output"):
            response_output = response.output or []
        else:
            verbose_proxy_logger.debug("OpenAI Responses API: No output found in response")
            return response

        if not response_output:
            verbose_proxy_logger.debug("OpenAI Responses API: Empty output in response")
            return response

        # Step 1: Extract all text content and tool calls from response output
        for output_idx, output_item in enumerate(response_output):
            self._extract_output_text_and_images(
                output_item=output_item,
                output_idx=output_idx,
                texts_to_check=texts_to_check,
                images_to_check=images_to_check,
                task_mappings=task_mappings,
                tool_calls_to_check=tool_calls_to_check,
            )

        # Step 2: Apply guardrail to all texts in batch
        if texts_to_check or tool_calls_to_check:
            # Use the real request_data if provided (proxy path), otherwise
            # create a standalone dict (SDK / direct-call path).
            if request_data is None:
                request_data = {"response": response}
            else:
                if "response" not in request_data:
                    request_data["response"] = response

            # Add user API key metadata with prefixed keys
            if "litellm_metadata" not in request_data:
                user_metadata: Final = self.transform_user_api_key_dict_to_metadata(user_api_key_dict)
                if user_metadata:
                    request_data["litellm_metadata"] = user_metadata

            inputs: Final = GenericGuardrailAPIInputs(texts=texts_to_check)
            if images_to_check:
                inputs["images"] = images_to_check
            if tool_calls_to_check:
                inputs["tool_calls"] = tool_calls_to_check
            # Include model information from the response if available
            response_model: str | None = None
            if isinstance(response, dict):
                response_model = response.get("model")
            elif hasattr(response, "model"):
                response_model = getattr(response, "model", None)
            if response_model:
                inputs["model"] = response_model

            pre_guardrail_tool_calls: Final = _tool_call_shapes(tool_calls_to_check)
            guardrailed_inputs: Final = await guardrail_to_apply.apply_guardrail(
                inputs=inputs,
                request_data=request_data,
                input_type="response",
                logging_obj=litellm_logging_obj,
            )

            guardrailed_texts: Final = guardrailed_inputs.get("texts", [])
            post_guardrail_tool_calls: Final = _post_guardrail_tool_call_shapes(
                returned_tool_calls=guardrailed_inputs.get("tool_calls"),
                pre_guardrail_tool_calls=pre_guardrail_tool_calls,
                guardrail_name=guardrail_to_apply.guardrail_name,
            )

            # Step 3: Map guardrail responses back to original response structure
            await self._apply_guardrail_responses_to_output(
                response=response,
                responses=guardrailed_texts,
                task_mappings=task_mappings,
            )
            self._write_tool_call_rewrites_to_output(
                tool_call_items=tuple(item for item in response_output if _is_tool_call_output_item(item)),
                pre_guardrail_tool_calls=pre_guardrail_tool_calls,
                post_guardrail_tool_calls=post_guardrail_tool_calls,
            )

        verbose_proxy_logger.debug("OpenAI Responses API: Processed output response: %s", response)

        return response

    async def process_output_streaming_response(
        self,
        responses_so_far: list[Any],
        guardrail_to_apply: "CustomGuardrail",
        litellm_logging_obj: "LiteLLMLoggingObj | None" = None,
        user_api_key_dict: "UserAPIKeyAuth | None" = None,
        request_data: dict | None = None,
        stream_transform_sink: StreamTransformSink | None = None,
        deliver_ended_stream_rewrites: bool = False,
    ) -> list[Any]:
        """
        Process output streaming response by applying guardrails to text content.

        Mirrors the Chat Completions handler pattern: extract text from the final
        chunk, apply the guardrail, then write the result back in-place so the
        caller sees the modified content (e.g. PII tokens replaced).

        For terminal envelope events (``response.completed``, and equally
        ``response.incomplete`` / ``response.failed``, whose envelopes carry the
        partial output) we use the same per-item extraction + task-mapping
        approach as ``process_output_response`` so that unmasking / blocking
        works correctly for every output item. With
        ``deliver_ended_stream_rewrites`` the earlier text-carrying events
        (``response.output_text.delta`` / ``.done``,
        ``response.content_part.done``, ``response.output_item.done``) are synced
        to the rewritten envelope too, so a client reading deltas sees the
        rewrite instead of the raw model output; a stream with no envelope
        gets its rewrite spread over the buffered text events, and a rewrite
        observed where no write-back is possible is reported as undeliverable,
        so the pipeline executor discards it and releases the original events.
        """
        if not responses_so_far:
            return responses_so_far

        final_chunk: Final = responses_so_far[-1]
        # Accept both plain dicts and Pydantic models (BaseLiteLLMOpenAIResponseObject
        # exposes a .get() shim, so all the .get() calls below work for both).
        if not (isinstance(final_chunk, dict) or hasattr(final_chunk, "get")):
            return responses_so_far

        # ------------------------------------------------------------------ #
        # Case 1: terminal envelope events (completed/incomplete/failed).     #
        # the accumulated response is available in the final chunk; iterate   #
        # output items, apply guardrail, write back. Falls through to the     #
        # string fallback when the envelope yields nothing to check.          #
        # ------------------------------------------------------------------ #
        if final_chunk.get("type") in _TERMINAL_ENVELOPE_EVENT_TYPES:
            response_obj: Final[ResponseOutputEnvelope] = final_chunk.get("response") or {}
            outputs: Final[Sequence[object]] = (
                (response_obj.get("output") or []) if hasattr(response_obj, "get") else []
            )

            texts_to_check: Final[list[str]] = []
            tool_calls_to_check: Final[list[ChatCompletionToolCallChunk]] = []
            task_mappings: Final[list[tuple[int, int]]] = []

            for output_idx, output_item in enumerate(outputs):
                self._extract_output_text_and_images(
                    output_item=output_item,
                    output_idx=output_idx,
                    texts_to_check=texts_to_check,
                    images_to_check=[],
                    task_mappings=task_mappings,
                    tool_calls_to_check=tool_calls_to_check,
                )

            if texts_to_check or tool_calls_to_check:
                if request_data is None:
                    request_data = {}
                if "response" not in request_data:
                    request_data["response"] = response_obj
                if "litellm_metadata" not in request_data:
                    user_metadata: Final = self.transform_user_api_key_dict_to_metadata(user_api_key_dict)
                    if user_metadata:
                        request_data["litellm_metadata"] = user_metadata

                inputs = GenericGuardrailAPIInputs(texts=texts_to_check)
                if tool_calls_to_check:
                    inputs["tool_calls"] = cast(list[ChatCompletionToolCallChunk], tool_calls_to_check)
                response_model = response_obj.get("model")
                if response_model:
                    inputs["model"] = response_model

                pre_guardrail_tool_calls: Final = _tool_call_shapes(tool_calls_to_check)
                guardrailed_inputs: Final = await guardrail_to_apply.apply_guardrail(
                    inputs=inputs,
                    request_data=request_data,
                    input_type="response",
                    logging_obj=litellm_logging_obj,
                )

                guardrailed_texts: Final = guardrailed_inputs.get("texts", [])
                post_guardrail_tool_calls: Final = _post_guardrail_tool_call_shapes(
                    returned_tool_calls=guardrailed_inputs.get("tool_calls"),
                    pre_guardrail_tool_calls=pre_guardrail_tool_calls,
                    guardrail_name=guardrail_to_apply.guardrail_name,
                )

                # Write guardrailed texts back into the output items in-place.
                # final_chunk is a reference into responses_so_far so this
                # mutates the list that the caller holds.
                await self._apply_guardrail_responses_to_output(
                    response=response_obj,
                    responses=guardrailed_texts,
                    task_mappings=task_mappings,
                )
                if deliver_ended_stream_rewrites:
                    rewrites_by_position: Final = MappingProxyType(
                        {
                            task_mappings[task_idx]: rewritten
                            for task_idx, rewritten in enumerate(guardrailed_texts)
                            if task_idx < len(texts_to_check) and rewritten != texts_to_check[task_idx]
                        }
                    )
                    if rewrites_by_position:
                        self._sync_stream_events_with_rewrites(
                            stream_events=responses_so_far[:-1],
                            rewrites_by_position=rewrites_by_position,
                        )
                    self._deliver_ended_stream_tool_call_rewrites(
                        responses_so_far=responses_so_far,
                        outputs=outputs,
                        pre_guardrail_tool_calls=pre_guardrail_tool_calls,
                        post_guardrail_tool_calls=post_guardrail_tool_calls,
                        guardrail_name=guardrail_to_apply.guardrail_name or "unknown",
                    )
                return responses_so_far

        # ------------------------------------------------------------------ #
        # Case 2: response.output_item.done — extract tool calls only, then  #
        # fall through to the text fallback when a caller expects rewrites   #
        # delivered, so a truncated buffer still reports text undeliverable. #
        # ------------------------------------------------------------------ #
        if final_chunk.get("type") == "response.output_item.done":
            model_response_stream: Final = (
                OpenAiResponsesToChatCompletionStreamIterator.translate_responses_chunk_to_openai_stream(final_chunk)
            )
            tool_calls: Final = model_response_stream.choices[0].delta.tool_calls
            if tool_calls:
                inputs = GenericGuardrailAPIInputs()
                inputs["tool_calls"] = cast(list[ChatCompletionToolCallChunk], tool_calls)
                if hasattr(model_response_stream, "model") and model_response_stream.model:
                    inputs["model"] = model_response_stream.model
                await guardrail_to_apply.apply_guardrail(
                    inputs=inputs,
                    request_data=request_data if request_data is not None else {},
                    input_type="response",
                    logging_obj=litellm_logging_obj,
                )
            if not deliver_ended_stream_rewrites:
                return responses_so_far

        # ------------------------------------------------------------------ #
        # Fallback: apply guardrail to the accumulated text string. With no   #
        # envelope to rewrite, a rewrite a caller expects delivered is spread #
        # over the buffered text events instead.                              #
        # ------------------------------------------------------------------ #
        string_so_far: Final = self.get_streaming_string_so_far(responses_so_far)
        if string_so_far:
            fallback_inputs: Final = GenericGuardrailAPIInputs(texts=[string_so_far])
            response_model = (
                final_chunk.get("response", {}).get("model") if isinstance(final_chunk.get("response"), dict) else None
            )
            if response_model:
                fallback_inputs["model"] = response_model
            fallback_outputs: Final = await guardrail_to_apply.apply_guardrail(
                inputs=fallback_inputs,
                request_data=request_data if request_data is not None else {},
                input_type="response",
                logging_obj=litellm_logging_obj,
            )
            fallback_texts: Final = fallback_outputs.get("texts")
            if deliver_ended_stream_rewrites and fallback_texts and tuple(fallback_texts) != (string_so_far,):
                self._spread_text_rewrite_over_stream_events(
                    stream_events=responses_so_far,
                    rewritten_text=fallback_texts[0],
                    guardrail_name=guardrail_to_apply.guardrail_name or "unknown",
                )
        return responses_so_far

    def _spread_text_rewrite_over_stream_events(
        self,
        stream_events: Sequence[object],
        rewritten_text: str,
        guardrail_name: str,
    ) -> None:
        """Deliver a text rewrite on a stream with no completed envelope by
        spreading it over the text parts the guardrail scanned, in stream
        order: the whole rewrite on the first part and every later part
        blanked, through the same sync the envelope path uses. A scanned
        event the sync cannot place (one that is not an ``output_text`` delta
        or done, or lacks integer ``output_index`` / ``content_index``) makes
        the rewrite undeliverable, so the pipeline executor discards it and
        releases the original events."""
        scanned_events: Final = tuple(
            event
            for event in stream_events
            if isinstance(stream_item_field(event, "text"), str) or isinstance(stream_item_field(event, "delta"), str)
        )
        scanned_positions: Final = tuple(
            dict.fromkeys(
                (stream_item_field(event, "output_index"), stream_item_field(event, "content_index"))
                for event in scanned_events
            )
        )
        placeable_positions: Final = tuple(
            (output_index, content_index)
            for output_index, content_index in scanned_positions
            if isinstance(output_index, int) and isinstance(content_index, int)
        )
        if len(placeable_positions) != len(scanned_positions) or any(
            stream_item_field(event, "type") not in _OUTPUT_TEXT_EVENT_TYPES for event in scanned_events
        ):
            from litellm.proxy.policy_engine.pipeline_executor import UndeliverableStreamRewrite

            raise UndeliverableStreamRewrite(
                guardrail_name,
                "the scanned text events are not all output_text deltas with an integer output_index and "
                "content_index, so the text rewrite has nowhere to land",
            )
        self._sync_stream_events_with_rewrites(
            stream_events=stream_events,
            rewrites_by_position=MappingProxyType(dict(zip(placeable_positions, chain((rewritten_text,), repeat(""))))),
        )

    @staticmethod
    def _write_event_field(event: object, field: str, value: str) -> None:
        if isinstance(event, dict):
            event[field] = value  # rebind-ok: delivering the rewrite means editing the buffered event in place
        else:
            setattr(event, field, value)

    def _sync_stream_events_with_rewrites(
        self,
        stream_events: Sequence[Any],
        rewrites_by_position: Mapping[tuple[int, int], str],
    ) -> None:
        """Sync pre-completion stream events with the rewritten completed
        response, keyed by ``(output_index, content_index)``: the first
        ``output_text.delta`` for a rewritten item carries the full rewritten
        text and the rest are blanked, while ``output_text.done``,
        ``content_part.done``, and ``output_item.done`` events carry the full
        rewritten text, so every event a client may read agrees with the
        rewritten ``response.completed`` payload."""
        delta_replacements: Final = MappingProxyType(
            {position: chain((rewritten,), repeat("")) for position, rewritten in rewrites_by_position.items()}
        )
        for event in stream_events:
            if not (isinstance(event, dict) or hasattr(event, "get")):
                continue
            event_type = event.get("type")
            output_index = event.get("output_index")
            content_index = event.get("content_index")
            if event_type == "response.output_item.done" and isinstance(output_index, int):
                self._sync_output_item_done_event(event.get("item"), output_index, rewrites_by_position)
                continue
            if not isinstance(output_index, int) or not isinstance(content_index, int):
                continue
            position = (output_index, content_index)
            if event_type == "response.output_text.delta" and position in delta_replacements:
                self._write_event_field(event, "delta", next(delta_replacements[position]))
            elif event_type == "response.output_text.done" and position in rewrites_by_position:
                self._write_event_field(event, "text", rewrites_by_position[position])
            elif event_type == "response.content_part.done" and position in rewrites_by_position:
                part = event.get("part")
                if isinstance(part, dict) or hasattr(part, "text"):
                    self._write_event_field(part, "text", rewrites_by_position[position])

    @staticmethod
    def _sync_output_item_done_event(
        item: object,
        output_index: int,
        rewrites_by_position: Mapping[tuple[int, int], str],
    ) -> None:
        content: Final = item.get("content") if isinstance(item, dict) else getattr(item, "content", None)
        if not isinstance(content, list):
            return
        for (item_idx, content_idx), rewritten in rewrites_by_position.items():
            if item_idx != output_index or content_idx >= len(content):
                continue
            OpenAIResponsesHandler._write_event_field(content[content_idx], "text", rewritten)

    def _deliver_ended_stream_tool_call_rewrites(
        self,
        responses_so_far: Sequence[object],
        outputs: Sequence[object],
        pre_guardrail_tool_calls: tuple[_ToolCallShape, ...],
        post_guardrail_tool_calls: tuple[_ToolCallShape, ...],
        guardrail_name: str,
    ) -> None:
        """Write ended-stream guardrail tool-call rewrites into the completed
        envelope's ``function_call`` and ``custom_tool_call`` items and sync the
        earlier stream events, keyed by ``call_id``. The guardrail sees the
        envelope's tool calls in output order, which is how a rewritten call
        finds its ``call_id``; the stream events find their call through the
        ``call_id`` on ``output_item`` events and the ``item_id`` on argument
        and custom-input events, since an
        event's ``output_index`` need not match the envelope's (the chat bridge
        numbers tool calls from 1 while the envelope lists them after the
        message). A rewrite whose calls do not line up with the envelope, or
        whose events cannot be found, is reported as undeliverable, so the
        pipeline executor discards it and releases the original events."""
        if post_guardrail_tool_calls == pre_guardrail_tool_calls:
            return
        tool_call_items: Final = tuple(output_item for output_item in outputs if _is_tool_call_output_item(output_item))
        call_ids: Final = tuple(
            call_id
            for output_item in tool_call_items
            if isinstance(call_id := stream_item_field(output_item, "call_id"), str) and call_id
        )
        stream_events: Final = responses_so_far[:-1]
        call_id_by_item_id: Final = self._tool_call_ids_by_item_id(stream_events)
        event_call_ids: Final = tuple(
            self._tool_call_event_call_id(event, call_id_by_item_id) for event in stream_events
        )
        rewrites_by_call_id: Final = MappingProxyType(
            {
                call_id: _tool_call_rewrite(before, after)
                for call_id, before, after in zip(call_ids, pre_guardrail_tool_calls, post_guardrail_tool_calls)
                if after != before
            }
        )
        unresolved_argument_event: Final = any(
            call_id is None and stream_item_field(event, "type") in _TOOL_CALL_PAYLOAD_EVENT_TYPES
            for event, call_id in zip(stream_events, event_call_ids)
        )
        undeliverable_reason: Final = _undeliverable_tool_call_rewrite_reason(
            call_ids=call_ids,
            tool_call_item_count=len(tool_call_items),
            post_guardrail_tool_call_count=len(post_guardrail_tool_calls),
            unresolved_argument_event=unresolved_argument_event,
            rewritten_call_ids=frozenset(rewrites_by_call_id),
            event_call_ids=frozenset(call_id for call_id in event_call_ids if call_id is not None),
        )
        if undeliverable_reason is not None:
            from litellm.proxy.policy_engine.pipeline_executor import UndeliverableStreamRewrite

            raise UndeliverableStreamRewrite(guardrail_name, undeliverable_reason)
        for output_item, rewrite in (
            (output_item, rewrites_by_call_id[call_id])
            for output_item, call_id in zip(tool_call_items, call_ids)
            if call_id in rewrites_by_call_id
        ):
            self._write_tool_call_item(output_item, rewrite.name, rewrite.arguments)
        delta_replacements: Final = MappingProxyType(
            {call_id: chain((rewrite.arguments,), repeat("")) for call_id, rewrite in rewrites_by_call_id.items()}
        )
        for event, call_id in zip(stream_events, event_call_ids):
            if call_id not in rewrites_by_call_id:
                continue
            match stream_item_field(event, "type"):
                case str() as event_type if event_type in _TOOL_CALL_PAYLOAD_DELTA_EVENT_TYPES:
                    self._write_event_field(event, "delta", next(delta_replacements[call_id]))
                case str() as event_type if event_type in _TOOL_CALL_PAYLOAD_DONE_EVENT_FIELDS:
                    self._write_event_field(
                        event, _TOOL_CALL_PAYLOAD_DONE_EVENT_FIELDS[event_type], rewrites_by_call_id[call_id].arguments
                    )
                case "response.output_item.added":
                    self._write_tool_call_item(
                        stream_item_field(event, "item"), rewrites_by_call_id[call_id].name, None
                    )
                case "response.output_item.done":
                    self._write_tool_call_item(
                        stream_item_field(event, "item"),
                        rewrites_by_call_id[call_id].name,
                        rewrites_by_call_id[call_id].arguments,
                    )
                case _:
                    pass

    def _write_tool_call_rewrites_to_output(
        self,
        tool_call_items: Sequence[object],
        pre_guardrail_tool_calls: tuple[_ToolCallShape, ...],
        post_guardrail_tool_calls: tuple[_ToolCallShape, ...],
    ) -> None:
        if len(tool_call_items) != len(post_guardrail_tool_calls):
            return
        for output_item, rewrite in (
            (output_item, _tool_call_rewrite(before, after))
            for output_item, before, after in zip(tool_call_items, pre_guardrail_tool_calls, post_guardrail_tool_calls)
            if after != before
        ):
            self._write_tool_call_item(output_item, rewrite.name, rewrite.arguments)

    @staticmethod
    def _tool_call_ids_by_item_id(stream_events: Sequence[object]) -> Mapping[str, str]:
        items: Final = tuple(
            stream_item_field(event, "item")
            for event in stream_events
            if stream_item_field(event, "type") in _OUTPUT_ITEM_EVENT_TYPES
        )
        return MappingProxyType(
            {
                item_id: call_id
                for item in items
                if stream_item_field(item, "type") in _TOOL_CALL_ITEM_TYPES
                and isinstance(item_id := stream_item_field(item, "id"), str)
                and isinstance(call_id := stream_item_field(item, "call_id"), str)
            }
        )

    @staticmethod
    def _tool_call_event_call_id(event: object, call_id_by_item_id: Mapping[str, str]) -> str | None:
        event_type: Final = stream_item_field(event, "type")
        if event_type in _TOOL_CALL_PAYLOAD_EVENT_TYPES:
            item_id: Final = stream_item_field(event, "item_id")
            return call_id_by_item_id.get(item_id) if isinstance(item_id, str) else None
        if event_type not in _OUTPUT_ITEM_EVENT_TYPES:
            return None
        item: Final = stream_item_field(event, "item")
        call_id: Final = stream_item_field(item, "call_id")
        return (
            call_id if stream_item_field(item, "type") in _TOOL_CALL_ITEM_TYPES and isinstance(call_id, str) else None
        )

    @staticmethod
    def _write_tool_call_item(item: object, name: str | None, payload: str | None) -> None:
        if item is None:
            return
        if name is not None:
            OpenAIResponsesHandler._write_event_field(item, "name", name)
        item_type: Final = stream_item_field(item, "type")
        if payload is not None and isinstance(item_type, str) and item_type in _TOOL_CALL_PAYLOAD_FIELDS:
            OpenAIResponsesHandler._write_event_field(item, _TOOL_CALL_PAYLOAD_FIELDS[item_type], payload)

    def _check_streaming_has_ended(self, responses_so_far: Sequence[object]) -> bool:
        """
        Check if the streaming has ended.
        """
        if not responses_so_far:
            return False
        return stream_item_field(responses_so_far[-1], "type") in _TERMINAL_ENVELOPE_EVENT_TYPES

    def get_streaming_scan_key(self, responses_so_far: Sequence[object]) -> StreamingScanKey | None:
        if not responses_so_far or not hasattr(responses_so_far[-1], "get"):
            return None
        last_event: Final = responses_so_far[-1]
        last_event_type: Final = stream_item_field(last_event, "type")
        if last_event_type == ResponsesAPIStreamEvents.OUTPUT_ITEM_DONE.value:
            return None
        if last_event_type in _TERMINAL_ENVELOPE_EVENT_TYPES:
            return self._completed_response_scan_key(stream_item_field(last_event, "response"))
        return StreamingScanKey(
            texts=(self.get_streaming_string_so_far(responses_so_far),),
            tool_calls_in_flight=self._has_streamed_tool_call_events(responses_so_far),
        )

    def released_stream_as_ended(self, responses_so_far: Sequence[object]) -> tuple[object, ...]:
        if self._check_streaming_has_ended(responses_so_far):
            return tuple(responses_so_far)
        ends_on_finished_item: Final = (
            bool(responses_so_far)
            and stream_item_field(responses_so_far[-1], "type") == ResponsesAPIStreamEvents.OUTPUT_ITEM_DONE.value
        )
        if not ends_on_finished_item and not self._has_streamed_tool_call_events(responses_so_far):
            return tuple(responses_so_far)
        text_events: Final = tuple(
            event for event in responses_so_far if stream_item_field(event, "type") in _OUTPUT_TEXT_EVENT_TYPES
        )
        released_text: Final = self.get_streaming_string_so_far(text_events)
        message_items: Final = (_released_message_item(released_text),) if released_text else ()
        tool_items: Final = _released_tool_call_items(responses_so_far)
        output: Final = [*message_items, *tool_items]
        response: Final = {"status": "incomplete", "output": output}
        incomplete: Final = ResponsesAPIStreamEvents.RESPONSE_INCOMPLETE.value
        envelope: Final = {"type": incomplete, "response": response}
        return (*responses_so_far, envelope)

    @staticmethod
    def _has_streamed_tool_call_events(responses_so_far: Sequence[object]) -> bool:
        return any(
            stream_item_field(event, "type") in _TOOL_CALL_PAYLOAD_EVENT_TYPES
            or (
                stream_item_field(event, "type") in _OUTPUT_ITEM_EVENT_TYPES
                and stream_item_field(stream_item_field(event, "item"), "type") in _TOOL_CALL_ITEM_TYPES
            )
            for event in responses_so_far
        )

    @staticmethod
    def _completed_response_scan_key(response: object) -> StreamingScanKey:
        output_items: Final = stream_item_items(response, "output")
        message_items: Final = tuple(
            item for item in output_items if stream_item_field(item, "type") not in _TOOL_CALL_ITEM_TYPES
        )
        return StreamingScanKey(
            texts=tuple(
                text
                for item in message_items
                for part in stream_item_items(item, "content")
                if isinstance(text := stream_item_field(part, "text"), str) and text
            ),
            tool_calls=tuple(
                stream_item_fingerprint(item)
                for item in output_items
                if stream_item_field(item, "type") in _TOOL_CALL_ITEM_TYPES
            ),
            stream_ended=True,
        )

    def build_stream_error_items(
        self,
        exc: "HTTPException",
        responses_so_far: Sequence[object] | None = None,
    ) -> Sequence[object] | None:
        from litellm.proxy.common_request_processing import (
            serialize_http_exception_detail,
        )

        message, _ = serialize_http_exception_detail(exc.detail)
        return (
            ErrorEvent(
                type=ResponsesAPIStreamEvents.ERROR,
                sequence_number=_next_stream_sequence_number(responses_so_far),
                error=ErrorEventError(
                    type="guardrail_error",
                    code=str(exc.status_code),
                    message=message,
                    param=None,
                ),
            ),
        )

    def get_streaming_string_so_far(self, responses_so_far: Sequence[object]) -> str:
        """
        Get the string so far from the responses so far.

        ``response.output_text.done`` events carry the whole part in ``text``, while
        ``response.output_text.delta`` events carry fragments in ``delta``. A stream
        that dies before its done event (``response.failed`` / ``response.incomplete``)
        has text only in deltas, so per content part the done text wins when present
        and the joined deltas fill in otherwise, never both.
        """
        keyed_events: Final = tuple(
            (
                (
                    stream_item_field(event, "item_id"),
                    stream_item_field(event, "output_index"),
                    stream_item_field(event, "content_index"),
                ),
                stream_item_field(event, "text"),
                stream_item_field(event, "delta"),
            )
            for event in responses_so_far
            if isinstance(stream_item_field(event, "text"), str) or isinstance(stream_item_field(event, "delta"), str)
        )

        def part_text(part_key: tuple[object, object, object]) -> str:
            done_texts: Final = tuple(
                text for key, text, _ in keyed_events if key == part_key and isinstance(text, str)
            )
            if done_texts:
                return done_texts[-1]
            return "".join(delta for key, _, delta in keyed_events if key == part_key and isinstance(delta, str))

        return "".join(part_text(key) for key in dict.fromkeys(key for key, _, _ in keyed_events))

    def _has_text_content(self, response: "ResponsesAPIResponse") -> bool:
        """
        Check if response has any text content to process.

        Override this method to customize text content detection.
        """
        if not hasattr(response, "output") or response.output is None:
            return False

        for output_item in response.output:
            if isinstance(output_item, BaseModel):
                try:
                    generic_response_output_item = GenericResponseOutputItem.model_validate(output_item.model_dump())
                    if generic_response_output_item.content:
                        output_item = generic_response_output_item
                except Exception:
                    continue
            if isinstance(output_item, (GenericResponseOutputItem, dict)):
                content = (
                    output_item.content
                    if isinstance(output_item, GenericResponseOutputItem)
                    else output_item.get("content", [])
                )
                if content:
                    for content_item in content:
                        # Check if it's an OutputText with text
                        if isinstance(content_item, OutputText):
                            if content_item.text:
                                return True
                        elif isinstance(content_item, dict):
                            if content_item.get("text"):
                                return True
        return False

    def _extract_output_text_and_images(
        self,
        output_item: object,
        output_idx: int,
        texts_to_check: list[str],
        images_to_check: list[str],
        task_mappings: list[tuple[int, int]],
        tool_calls_to_check: list[ChatCompletionToolCallChunk] | None = None,
    ) -> None:
        """
        Extract text content, images, and tool calls from a response output item.

        Override this method to customize text/image/tool extraction logic.
        """

        tool_call_item: Final = _tool_call_output_item_mapping(output_item)
        if tool_call_item is not None:
            if tool_calls_to_check is not None:
                tool_calls_to_check.append(tool_call_dict_from_output_item(tool_call_item, output_idx))
            return

        # Handle both GenericResponseOutputItem and dict
        content: list[OutputText] | list[dict] | None = None
        if isinstance(output_item, BaseModel):
            try:
                output_item_dump: Final = output_item.model_dump()
                generic_response_output_item: Final = GenericResponseOutputItem.model_validate(output_item_dump)
                if generic_response_output_item.content:
                    content = generic_response_output_item.content
            except Exception:
                # Try to extract content directly from output_item if validation fails
                if hasattr(output_item, "content") and output_item.content:
                    content = output_item.content
                else:
                    return
        elif isinstance(output_item, dict):
            content = output_item.get("content", [])
        else:
            return

        if not content:
            return

        verbose_proxy_logger.debug("OpenAI Responses API: Processing output item: %s", output_item)

        # Iterate through content items (list of OutputText objects)
        for content_idx, content_item in enumerate(content):
            # Handle both OutputText objects and dicts
            if isinstance(content_item, OutputText):
                text_content = content_item.text
            elif isinstance(content_item, dict):
                text_content = content_item.get("text")
            else:
                continue

            if text_content:
                texts_to_check.append(text_content)
                task_mappings.append((output_idx, int(content_idx)))

    async def _apply_guardrail_responses_to_output(
        self,
        response: Union["ResponsesAPIResponse", ResponseOutputEnvelope],
        responses: list[str],
        task_mappings: list[tuple[int, int]],
    ) -> None:
        """
        Apply guardrail responses back to output response.

        Override this method to customize how responses are applied.
        """
        # Handle both dict and Pydantic object responses
        if isinstance(response, dict):
            response_output = response.get("output", [])
        elif hasattr(response, "output"):
            response_output = response.output or []
        else:
            return

        for task_idx, guardrail_response in enumerate(responses):
            mapping = task_mappings[task_idx]
            output_idx = cast(int, mapping[0])
            content_idx = cast(int, mapping[1])

            if output_idx >= len(response_output):
                continue

            output_item = response_output[output_idx]

            # Handle both GenericResponseOutputItem, BaseModel, and dict
            if isinstance(output_item, GenericResponseOutputItem):
                if output_item.content and content_idx < len(output_item.content):
                    content_item = output_item.content[content_idx]
                    if isinstance(content_item, OutputText):
                        content_item.text = guardrail_response
                    elif isinstance(content_item, dict):
                        content_item["text"] = guardrail_response
            elif isinstance(output_item, BaseModel):
                # Handle other Pydantic models by converting to GenericResponseOutputItem
                try:
                    generic_item = GenericResponseOutputItem.model_validate(output_item.model_dump())
                    if generic_item.content and content_idx < len(generic_item.content):
                        content_item = generic_item.content[content_idx]
                        if isinstance(content_item, OutputText):
                            content_item.text = guardrail_response
                            # Update the original response output
                            if hasattr(output_item, "content") and output_item.content:
                                original_content = output_item.content[content_idx]
                                if hasattr(original_content, "text"):
                                    original_content.text = guardrail_response
                except Exception:
                    pass
            elif isinstance(output_item, dict):
                content = output_item.get("content", [])
                if content and content_idx < len(content):
                    if isinstance(content[content_idx], dict):
                        content[content_idx]["text"] = guardrail_response
                    elif hasattr(content[content_idx], "text"):
                        content[content_idx].text = guardrail_response

    def build_block_sse_chunks(
        self,
        exc: "ModifyResponseException",
        stream_started: bool = False,
        responses_so_far: Sequence[object] | None = None,
    ) -> Sequence[bytes]:
        """
        Build Responses API SSE events that deliver the guardrail block message
        and terminate the stream cleanly, mirroring the non-streaming block
        response: a completed response whose only output is the violation text,
        with the real usage the upstream call consumed.

        - ``stream_started`` False (buffered / pre-stream): nothing has been
          sent, so emit the full synthetic sequence (``response.created``
          through ``response.completed``).
        - ``stream_started`` True (sampling / mid-stream): events already
          reached the client, so continue the in-progress response: close the
          output item still open on the wire, deliver the block message as a
          new output item under the same response id, and close with a
          ``response.completed`` carrying only the replacement item.

        The proxy's data generator appends ``data: [DONE]`` itself.
        """
        events: Final = (
            self._block_continuation_events(exc, responses_so_far or ())
            if stream_started
            else self._standalone_block_events(exc)
        )
        return tuple(
            f"data: {event.model_dump_json(exclude_none=True, exclude_unset=True, serialize_as_any=True)}\n\n".encode()
            for event in events
        )

    @staticmethod
    def _standalone_block_events(exc: "ModifyResponseException") -> Sequence[ResponsesAPIStreamingResponse]:
        from litellm.responses.streaming_iterator import build_synthetic_response_events

        return build_synthetic_response_events(
            transformed=build_blocked_response(exc),
            logging_obj=None,
            chunk_size=max(len(exc.message), 1),
        )

    @staticmethod
    def _block_continuation_events(
        exc: "ModifyResponseException", responses_so_far: Sequence[object]
    ) -> Sequence[ResponsesAPIStreamingResponse]:
        response_id, model, output_index = _continuation_identity(exc, responses_so_far)
        item: Final = _blocked_output_item(exc)
        item_id: Final = item.id
        part: Final[_BlockedContentPart] = {"type": "output_text", "text": exc.message, "annotations": ()}
        done_part: Final[_BlockedDoneContentPart] = {
            "type": "output_text",
            "text": exc.message,
            "annotations": (),
            "logprobs": None,
        }
        return (
            *_open_item_closing_events(responses_so_far),
            OutputItemAddedEvent(
                type=ResponsesAPIStreamEvents.OUTPUT_ITEM_ADDED,
                output_index=output_index,
                item=item,
            ),
            ContentPartAddedEvent(
                type=ResponsesAPIStreamEvents.CONTENT_PART_ADDED,
                item_id=item_id,
                output_index=output_index,
                content_index=0,
                part=BaseLiteLLMOpenAIResponseObject.model_validate(part),
            ),
            OutputTextDeltaEvent(
                type=ResponsesAPIStreamEvents.OUTPUT_TEXT_DELTA,
                item_id=item_id,
                output_index=output_index,
                content_index=0,
                delta=exc.message,
            ),
            OutputTextDoneEvent(
                type=ResponsesAPIStreamEvents.OUTPUT_TEXT_DONE,
                item_id=item_id,
                output_index=output_index,
                content_index=0,
                text=exc.message,
            ),
            ContentPartDoneEvent(
                type=ResponsesAPIStreamEvents.CONTENT_PART_DONE,
                item_id=item_id,
                output_index=output_index,
                content_index=0,
                part=ContentPartDonePartOutputText.model_validate(done_part),
            ),
            OutputItemDoneEvent(
                type=ResponsesAPIStreamEvents.OUTPUT_ITEM_DONE,
                output_index=output_index,
                item=item,
            ),
            ResponseCompletedEvent(
                type=ResponsesAPIStreamEvents.RESPONSE_COMPLETED,
                response=_blocked_response(exc, response_id=response_id, model=model, output_item=item),
            ),
        )


class _BlockedContentPart(TypedDict):
    type: ReadOnly[str]
    text: ReadOnly[str]
    annotations: ReadOnly[tuple[object, ...]]


class _BlockedDoneContentPart(TypedDict):
    type: ReadOnly[str]
    text: ReadOnly[str]
    annotations: ReadOnly[tuple[object, ...]]
    logprobs: ReadOnly[None]


class _BlockedItemPayload(TypedDict):
    type: ReadOnly[str]
    id: ReadOnly[str]
    status: ReadOnly[str]
    role: ReadOnly[str]
    content: ReadOnly[tuple[_BlockedContentPart, ...]]


class _BlockedResponsePayload(TypedDict):
    id: ReadOnly[str]
    object: ReadOnly[str]
    created_at: ReadOnly[int]
    model: ReadOnly[str]
    output: ReadOnly[tuple[GenericResponseOutputItem, ...]]
    status: ReadOnly[str]
    usage: ReadOnly[ResponseAPIUsage]


def _blocked_output_item(exc: "ModifyResponseException") -> GenericResponseOutputItem:
    payload: Final[_BlockedItemPayload] = {
        "type": "message",
        "id": f"msg_{uuid.uuid4()}",
        "status": "completed",
        "role": "assistant",
        "content": ({"type": "output_text", "text": exc.message, "annotations": ()},),
    }
    return GenericResponseOutputItem.model_validate(payload)


def build_blocked_response(exc: "ModifyResponseException") -> ResponsesAPIResponse:
    return _blocked_response(exc, response_id=f"resp_{uuid.uuid4()}", model=exc.model)


def _blocked_response(
    exc: "ModifyResponseException",
    response_id: str,
    model: str,
    output_item: GenericResponseOutputItem | None = None,
) -> ResponsesAPIResponse:
    payload: Final[_BlockedResponsePayload] = {
        "id": response_id,
        "object": "response",
        "created_at": int(time.time()),
        "model": model,
        "output": (output_item if output_item is not None else _blocked_output_item(exc),),
        "status": "completed",
        "usage": blocked_responses_stream_usage(exc.original_response),
    }
    return ResponsesAPIResponse.model_validate(payload)


def _continuation_identity(exc: "ModifyResponseException", responses_so_far: Sequence[object]) -> tuple[str, str, int]:
    responses: Final = tuple(
        response for item in responses_so_far if (response := stream_item_field(item, "response")) is not None
    )
    response_id: Final = next(
        (rid for response in responses if isinstance(rid := stream_item_field(response, "id"), str) and rid),
        f"resp_{uuid.uuid4()}",
    )
    model: Final = next(
        (m for response in responses if isinstance(m := stream_item_field(response, "model"), str) and m),
        exc.model,
    )
    indices: Final = tuple(
        index for item in responses_so_far if isinstance(index := stream_item_field(item, "output_index"), int)
    )
    return response_id, model, max(indices) + 1 if indices else 0


@dataclass(frozen=True, slots=True)
class _OpenItemState:
    item_id: str
    item_type: str
    role: str
    output_index: int
    content_index: int
    text: str
    part_open: bool
    payload: object


def _open_item_state(responses_so_far: Sequence[object]) -> _OpenItemState | None:
    typed: Final = tuple((stream_item_field(event, "type"), event) for event in responses_so_far)
    added: Final = tuple(
        (added_index, stream_item_field(event, "item"))
        for event_type, event in typed
        if event_type == "response.output_item.added"
        and isinstance(added_index := stream_item_field(event, "output_index"), int)
    )
    done_indices: Final = frozenset(
        done_index
        for event_type, event in typed
        if event_type == "response.output_item.done"
        and isinstance(done_index := stream_item_field(event, "output_index"), int)
    )
    open_added: Final = tuple((index, payload) for index, payload in added if index not in done_indices)
    if not open_added:
        return None
    output_index, item_payload = open_added[-1]
    if item_payload is None:
        return None
    item_id: Final = stream_item_field(item_payload, "id")
    if not isinstance(item_id, str) or not item_id:
        return None
    raw_type: Final = stream_item_field(item_payload, "type")
    raw_role: Final = stream_item_field(item_payload, "role")
    part_added: Final = tuple(
        part_index
        for event_type, event in typed
        if event_type == "response.content_part.added"
        and stream_item_field(event, "item_id") == item_id
        and isinstance(part_index := stream_item_field(event, "content_index"), int)
    )
    part_done: Final = frozenset(
        part_done_index
        for event_type, event in typed
        if event_type == "response.content_part.done"
        and stream_item_field(event, "item_id") == item_id
        and isinstance(part_done_index := stream_item_field(event, "content_index"), int)
    )
    open_parts: Final = tuple(index for index in part_added if index not in part_done)
    text: Final = "".join(
        delta
        for event_type, event in typed
        if event_type == "response.output_text.delta"
        and stream_item_field(event, "item_id") == item_id
        and isinstance(delta := stream_item_field(event, "delta"), str)
    )
    return _OpenItemState(
        item_id=item_id,
        item_type=raw_type if isinstance(raw_type, str) and raw_type else "message",
        role=raw_role if isinstance(raw_role, str) and raw_role else "assistant",
        output_index=output_index,
        content_index=open_parts[-1] if open_parts else 0,
        text=text,
        part_open=bool(open_parts),
        payload=item_payload,
    )


_item_fields_adapter: Final = TypeAdapter(Mapping[str, object])
_no_item_fields: Final[Mapping[str, object]] = MappingProxyType({})


def _incomplete_item_fields(payload: object) -> Mapping[str, object]:
    raw: Final = payload.model_dump() if isinstance(payload, BaseModel) else payload
    if not isinstance(raw, dict):
        return _no_item_fields
    return _item_fields_adapter.validate_python(raw)


def _open_item_closing_events(responses_so_far: Sequence[object]) -> Sequence[ResponsesAPIStreamingResponse]:
    """Close the output item still in progress on the relayed stream before the
    block item is appended: strict Responses clients reject a
    ``response.completed`` that arrives while an earlier ``output_item.added``
    was never closed. A message item closes ``completed`` with exactly the text
    the client has received so far; any other item type (a function call the
    guardrail rejected, for instance) closes ``incomplete`` so the synthetic
    done event can never authorize acting on it."""
    open_item: Final = _open_item_state(responses_so_far)
    if open_item is None:
        return ()
    if open_item.item_type != "message":
        return (
            OutputItemDoneEvent(
                type=ResponsesAPIStreamEvents.OUTPUT_ITEM_DONE,
                output_index=open_item.output_index,
                item=BaseLiteLLMOpenAIResponseObject.model_validate(
                    MappingProxyType({**_incomplete_item_fields(open_item.payload), "status": "incomplete"})
                ),
            ),
        )
    partial_part: Final[_BlockedContentPart] = {
        "type": "output_text",
        "text": open_item.text,
        "annotations": (),
    }
    closed_payload: Final[_BlockedItemPayload] = {
        "type": open_item.item_type,
        "id": open_item.item_id,
        "status": "completed",
        "role": open_item.role,
        "content": (partial_part,),
    }
    item_done: Final = OutputItemDoneEvent(
        type=ResponsesAPIStreamEvents.OUTPUT_ITEM_DONE,
        output_index=open_item.output_index,
        item=GenericResponseOutputItem.model_validate(closed_payload),
    )
    if not open_item.part_open:
        return (item_done,)
    partial_done_part: Final[_BlockedDoneContentPart] = {
        "type": "output_text",
        "text": open_item.text,
        "annotations": (),
        "logprobs": None,
    }
    return (
        OutputTextDoneEvent(
            type=ResponsesAPIStreamEvents.OUTPUT_TEXT_DONE,
            item_id=open_item.item_id,
            output_index=open_item.output_index,
            content_index=open_item.content_index,
            text=open_item.text,
        ),
        ContentPartDoneEvent(
            type=ResponsesAPIStreamEvents.CONTENT_PART_DONE,
            item_id=open_item.item_id,
            output_index=open_item.output_index,
            content_index=open_item.content_index,
            part=ContentPartDonePartOutputText.model_validate(partial_done_part),
        ),
        item_done,
    )
