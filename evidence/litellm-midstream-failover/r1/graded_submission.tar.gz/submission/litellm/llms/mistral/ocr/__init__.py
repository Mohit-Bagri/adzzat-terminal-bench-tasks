"""Mistral OCR transformation module."""
